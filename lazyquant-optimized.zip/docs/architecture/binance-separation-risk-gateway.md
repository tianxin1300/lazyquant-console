# Binance Spot / Futures 分离与硬风控网关架构

> 状态：设计基线 v1.0  
> 适用范围：LazyQuant 研究控制台、独立海外执行服务  
> 本文只定义架构与安全边界，不启用真实下单、不改动现有页面 UI。

## 1. 设计结论

Spot 和 USDⓈ-M Futures 必须被视为两个不同的交易域。它们不能共用同一套账户状态、持仓模型、API 客户端、订单状态机、风险额度或对账流程。

硬风控网关必须是所有“开仓、加仓、反向开仓、保护性退出、紧急平仓”订单的唯一入口。策略只能产生 `OrderIntent`，不能直接调用 Binance 下单 API。任何策略、QuantPilot、回测器或 UI 都不能绕过网关。

安全默认值为：`paper → testnet/demo → 小额 canary → live`。每次升级都必须通过前一阶段的验收；没有账户同步、订单同步或风险状态同步时，系统只能进入 `PROTECTIVE_ONLY` 或 `HALTED`，不能新开仓。

## 2. Binance 官方边界

Binance Spot 与 USDⓈ-M Futures 使用不同的 REST 基地址和不同的账户事件模型。Spot 的交易规则来自 `exchangeInfo`，其中包含 `PRICE_FILTER`、`LOT_SIZE`、`MIN_NOTIONAL` 等过滤器；下单前必须按交易所返回的规则做价格、数量和名义金额校验。[1] [2]

USDⓈ-M Futures 的生产 REST 基地址是 `https://fapi.binance.com`，官方文档列出的测试环境 REST 基地址为 `https://demo-fapi.binance.com`，测试 WebSocket 基地址为 `wss://demo-fstream.binance.com`。[3] Futures 订单还拥有 `positionSide`、`reduceOnly`、`closePosition`、`workingType`、`newClientOrderId` 等 Spot 不具备或含义不同的字段，因此不能通过一个通用订单对象直接混用。[4]

Futures 用户数据流需要维护 listen key。官方文档说明 listen key 有效期为 60 分钟，需要续期；单条连接最长约 24 小时，需要主动重连。账户和订单状态应优先使用用户数据流同步，不能只依赖高波动时可能延迟的 REST 查询。[5]

Binance 对 Futures 的 `503 Unknown error` 有特殊语义：请求可能已经被交易所接受，但客户端没有拿到响应，不能直接重试，否则可能重复下单。正确动作是先查询订单或等待用户数据流确认，并将订单置为 `UNKNOWN`。官方文档还说明，`429` 后必须退避，持续违反可能导致 `418` IP ban；部分 reduce-only / close-position 请求在系统过载时具有不同的处理优先级。[3]

## 3. 逻辑分层

```mermaid
flowchart LR
  UI[控制台 / QuantPilot] --> S[Strategy Runtime]
  S --> I[OrderIntent]
  I --> G[Hard Risk Gateway]
  G --> D{Market Domain}
  D --> SP[Spot Adapter]
  D --> FU[USDT-M Futures Adapter]
  SP --> SE[Spot REST + Spot User Stream]
  FU --> FE[Futures REST + Futures User Stream]
  SE --> L[Domain Ledger]
  FE --> L
  L --> R[Reconciliation]
  R --> G
  G --> A[Structured Audit + Metrics + Alerts]
```

### 3.1 Strategy Runtime

策略只负责读取已确认的市场数据、计算指标和生成意图。策略输出必须包含：

- `strategyId`
- `strategyVersion`
- `venue`
- `marketType: SPOT | USD_M_FUTURES`
- `symbol`
- `signalId`
- `candleCloseTime`
- `side`
- `intentType: OPEN | ADD | CLOSE | REDUCE | EMERGENCY_CLOSE`
- `quantity` 或 `notional`
- `reduceOnly`
- `positionSide`（Futures 必填，Spot 禁用）
- `reasonCodes`
- `indicatorSnapshot`

策略不允许携带 API key、secret、签名、原始请求参数或直接调用交易所 SDK。

### 3.2 Domain Router

路由器只按显式 `marketType` 分流，不根据 symbol 猜测市场。推荐使用两个不可互换的适配器：

```text
execution/
  domain/
    spot/
      SpotClient
      SpotMarketRules
      SpotAccountLedger
      SpotOrderStateMachine
      SpotReconciler
    usdm_futures/
      UsdmFuturesClient
      UsdmFuturesMarketRules
      FuturesAccountLedger
      FuturesPositionLedger
      FuturesOrderStateMachine
      FuturesReconciler
  risk/
    HardRiskGateway
    ExposureCalculator
    LossGuard
    EmergencyController
```

每个域独立维护：

- REST base URL
- WebSocket base URL
- API credential reference
- rate limiter
- exchangeInfo 缓存
- 订单 ID / clientOrderId 命名空间
- 账户余额和仓位账本
- 对账任务
- 错误映射
- 允许的订单字段

## 4. Spot 与 Futures 数据模型隔离

### Spot

Spot 账户以资产余额为中心：`free`、`locked`、资产余额变化、订单成交和手续费。Spot 不使用 Futures 的 `positionSide`、杠杆、保证金率和强平价格。

Spot 风控重点是：可用余额、冻结余额、单品种持仓、卖出可用数量、订单名义金额、价格和数量过滤器、交易权限和流动性。

### USDⓈ-M Futures

Futures 账户以仓位和保证金为中心：

- `positionAmt`
- `positionSide`
- `entryPrice`
- `markPrice`
- `unRealizedProfit`
- `isolatedWallet`
- `leverage`
- `marginType`
- `liquidationPrice`
- `maintMargin`
- `reduceOnly`

第一版建议固定：

- 单向持仓 `ONE-WAY / BOTH`
- 杠杆 `1x`
- 禁止自动加仓
- 禁止自动反向翻仓
- 只允许 `OPEN` 或 `REDUCE/CLOSE` 的明确意图
- 止损触发价优先使用 `MARK_PRICE`
- 不允许策略层更改 leverage、margin type 或 position mode

如果未来开放 Hedge Mode，必须作为独立版本开发，不能在同一版本中动态切换。

## 5. 硬风控网关

### 5.1 唯一入口

所有交易请求必须经过以下调用链：

```text
Strategy Signal
  → OrderIntentValidator
  → Domain Compatibility Check
  → Account Sync Check
  → Market Rules Check
  → Exposure & Loss Check
  → Idempotency Check
  → Rate Limit Check
  → Risk Decision
  → Adapter Submit
  → Order State Machine
```

只要任意一项失败，默认拒绝。风险网关采用 fail-closed，而不是 fail-open。

### 5.2 不可运行时放宽的硬上限

硬上限写在执行服务代码中，配置只能把额度调得更小，不能覆盖代码上限：

```text
MAX_SINGLE_ENTRY_NOTIONAL
MAX_TOTAL_EXPOSURE
MAX_SYMBOL_EXPOSURE
MAX_DAILY_LOSS
MAX_TOTAL_LOSS
MAX_DRAWDOWN
MAX_CONSECUTIVE_LOSSES
MAX_SLIPPAGE_BPS
MAX_ORDER_RETRIES
MAX_ORDER_AGE_SECONDS
MIN_NOTIONAL
```

每个域单独保存一份额度。Spot 的余额风险和 Futures 的保证金/仓位风险不能合并成一个数字。

### 5.3 开仓前检查

`OPEN` 和 `ADD` 必须依次满足：

1. 系统不是 `HALTED`、`RECONCILIATION_REQUIRED` 或 `EMERGENCY_CLOSING`。
2. 交易域、交易对、策略版本与 API credential profile 一致。
3. 行情时间未过期，K 线已闭合，服务器时钟偏移在允许范围内。
4. 账户、订单和仓位最近一次对账成功。
5. 当前日亏损、总亏损、回撤、连续亏损没有越过硬阈值。
6. 下单后总敞口、品种敞口、策略敞口不超过硬上限。
7. 数量、价格、名义金额和精度通过对应域的 exchangeInfo 过滤器。
8. 预估滑点和订单簿深度通过阈值。
9. `signalId + strategyVersion + candleCloseTime + intentType` 尚未使用。
10. 订单速率未超限，且没有同一策略的未决未知订单。

### 5.4 退出优先级

风控网关的优先级固定为：

```text
EMERGENCY_CLOSE
  > REDUCE_ONLY_PROTECTIVE_EXIT
  > HARD_STOP
  > ACCOUNT_DRAWDOWN_STOP
  > STRATEGY_EXIT
  > TAKE_PROFIT
  > NORMAL_ENTRY
```

当系统进入保护模式时，只允许减少风险的请求。普通策略出场可以继续，开仓和加仓必须拒绝。紧急平仓路径不应被单笔风险额度阻挡，但仍必须经过域适配器、幂等、审计和结果确认。

## 6. 状态机

### 6.1 执行服务状态

```text
DISCONNECTED
  → CONNECTING
  → SYNCING
  → READY
  → RUNNING
  → PROTECTIVE_ONLY
  → HALTED
  → RECONCILIATION_REQUIRED
  → EMERGENCY_CLOSING
```

状态转移规则：

- 启动后先 `SYNCING`，完成余额、订单、仓位和交易规则加载后才允许 `READY`。
- 任何账户/订单/仓位对账差异进入 `RECONCILIATION_REQUIRED`。
- 行情断流、用户流过期、时钟漂移、REST 认证失败进入 `PROTECTIVE_ONLY` 或 `HALTED`。
- 硬亏损或回撤阈值触发 `PROTECTIVE_ONLY`。
- 紧急总平仓触发 `EMERGENCY_CLOSING`，直到仓位为零且订单对账通过。
- 自动恢复禁止发生，恢复需要人工确认和新的对账结果。

### 6.2 订单状态

```text
INTENT
  → RISK_REJECTED
  → SUBMITTING
  → ACKNOWLEDGED
  → PARTIALLY_FILLED
  → FILLED
  → CANCELED
  → EXPIRED
  → UNKNOWN
  → RECONCILIATION_REQUIRED
```

`UNKNOWN` 不是失败。特别是 Futures 出现 503 Unknown 时，先用 `newClientOrderId`、订单查询和用户数据流确认；确认前禁止再次提交同一意图。

## 7. 凭证与权限隔离

建议至少使用两套 API credential profile：

```text
BINANCE_SPOT_DEMO
BINANCE_USDM_FUTURES_DEMO
```

生产阶段再分别创建：

```text
BINANCE_SPOT_LIVE
BINANCE_USDM_FUTURES_LIVE
```

每个 profile 只属于一个 market domain。Spot key 不得请求 Futures endpoint；Futures key 不得被 Spot adapter 使用。统一密钥库只保存加密引用，不把解密后的 secret 传到策略进程。

权限建议：

- 禁止 Withdraw
- 禁止资金划转，除非用户明确开启独立的人工资金流程
- 只开放所需交易和用户数据权限
- 绑定独立执行服务器 IP
- Spot 与 Futures 使用不同 API key
- Paper/Testnet/Live 使用不同 API key
- 日志禁止输出 key、secret、签名、完整请求体

## 8. 对账设计

### 启动对账

执行服务启动后，按以下顺序同步：

1. 服务器时间和本地时钟偏移。
2. 交易规则和精度。
3. 账户余额。
4. 未完成订单。
5. 当前持仓（Futures）。
6. 最近成交和手续费。
7. 本地事件日志 offset。

本地账本与交易所快照不一致时，不允许进入 `RUNNING`。

### 持续对账

- 用户数据流是主事件源。
- REST 是周期性校验源。
- Spot 关注 `executionReport` 和 `outboundAccountPosition`。[6]
- Futures 关注 `ORDER_TRADE_UPDATE` 和 `ACCOUNT_UPDATE`；还要处理 `MARGIN_CALL`、`ACCOUNT_CONFIG_UPDATE`、`listenKeyExpired`。[5]
- 每次重连、用户流过期、订单状态未知、进程重启后立即触发专项对账。

## 9. 可观测性和审计

每个订单意图、风控决定和交易所回报都使用结构化事件，并携带：

```text
requestId
runId
entryPoint
strategyId
strategyVersion
marketType
symbol
signalId
candleCloseTime
riskDecision
riskRule
orderId
clientOrderId
exchangeEventTime
```

绝不记录 API key、secret、签名和完整订单请求体。建议至少建立以下指标：

- `risk_decision_total{market_type,decision,rule}`
- `order_submit_total{market_type,status}`
- `order_unknown_total{market_type}`
- `reconciliation_mismatch_total{market_type}`
- `user_stream_disconnect_total{market_type}`
- `market_data_staleness_seconds{market_type,symbol}`
- `order_ack_latency_seconds{market_type}`
- `protective_mode_total{market_type,reason}`

告警只保留两级：

- **Page**：可能造成资金风险，立即停止新开仓或执行紧急处置。
- **Ticket**：系统降级但风险已被隔离，需要在工作日处理。

每个告警必须附有 runbook，至少写清楚含义、第一条检查命令和升级路径。

## 10. 分阶段实现顺序

### Phase A：只做隔离和模拟

- 建立 Spot/Futures 两个 domain adapter 接口。
- 建立两个独立的账户、订单、仓位 ledger。
- 实现 `OrderIntent` 和 `RiskDecision` 类型。
- 所有请求只能进入 paper adapter。
- 加入状态机和结构化审计事件。

验收：同一个 symbol 在 Spot 和 Futures 下不会共享订单、余额、仓位或风险额度。

### Phase B：Spot Testnet / Demo

- 接入 Spot exchangeInfo、用户数据流、订单状态机。
- 验证过滤器、幂等、部分成交和对账。
- 触发网络断开、REST 429、未知订单、重复信号和重启恢复演练。

验收：连续运行期间无重复订单，任何对账差异都会阻止新开仓。

### Phase C：USDⓈ-M Futures Demo

- 接入 Futures exchangeInfo、账户、订单、持仓和用户数据流。
- 固定单向持仓、1x、禁止加仓。
- 明确 mark price、reduce-only、close-position、positionSide 的使用方式。
- 演练 503 Unknown、429、listenKey 过期、部分成交、强平风险和资金费率入账。

验收：订单状态最终一致；未知状态不会重复提交；保护性退出优先于普通策略动作。

### Phase D：小额实盘审批

只有当 A-C 全部通过，才允许创建 Live profile。Live 不是代码中的默认值，而是部署级环境变量、命令行显式开关和人工审批三重条件同时满足。

## 11. 当前项目落地建议

当前 LazyQuant 仍以研究/Demo 为主，建议下一次代码实现只先做 Phase A：类型、domain adapter 接口、RiskDecision、状态机和 paper adapter。不要同时接入实盘 API。

现有页面上的静态 Demo 订单、持仓和收益数据应继续明确标注为演示数据。Spot/Futures 连接卡片在真正接入前，不应显示为“真实运行中”。

## References

[1]: https://developers.binance.com/en/docs/catalog/core-trading-spot-trading/api/rest-api/general "Binance Spot REST API General Information"
[2]: https://developers.binance.com/en/docs/products/spot/filters "Binance Spot Symbol and Exchange Filters"
[3]: https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/general-info "Binance USDⓈ-M Futures General Information"
[4]: https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/trade "Binance USDⓈ-M Futures Trade API"
[5]: https://developers.binance.com/en/docs/products/derivatives-trading-usds-futures/user-data-streams "Binance USDⓈ-M Futures User Data Streams"
[6]: https://developers.binance.com/en/docs/products/spot/testnet/user-data-stream "Binance Spot User Data Stream Events"
