import {
  calculateAtr, calculateBoll, calculateEma, calculateKdj, calculateMacd, calculateObv, calculateRsi,
  calculateStochRsi, calculateSuper, calculateWr,
  type Candle, type IndicatorKind,
} from "./indicators";

export type Condition = { id: string; indicator: IndicatorKind; operator: string; value: number; action: "入场" | "出场" };
export type BacktestResult = { trades: number; winRate: number; returnPct: number; maxDrawdown: number; profitFactor: number; equity: number[]; warnings: string[] };
export type OptimizationResult = { bestValue: number; inSample: BacktestResult; outOfSample: BacktestResult };
export type IndicatorParams = Partial<Record<IndicatorKind, Record<string, number>>>;
export type BacktestOptions = { initialCash?: number; feeRate?: number; params?: IndicatorParams };

type Series = Array<number | null>;
/** primary 与阈值比较；pair 是用于"金叉/死叉"的第二条线（不存在则这两个算子不可用）。 */
type Lines = { primary: Series; pair?: Series };

const P = (params: IndicatorParams | undefined, kind: IndicatorKind, key: string, fallback: number) => params?.[kind]?.[key] ?? fallback;

/** 把指标计算结果统一成 primary/pair 两条线；参数来自指标群组，而不是写死默认值。 */
export function indicatorLines(kind: IndicatorKind, candles: Candle[], params?: IndicatorParams): Lines {
  const closes: Series = candles.map((candle) => candle.close);
  switch (kind) {
    case "RSI": return { primary: calculateRsi(candles, P(params, "RSI", "period", 14)).map((p) => p.value) };
    case "MACD": { const m = calculateMacd(candles, P(params, "MACD", "fast", 12), P(params, "MACD", "slow", 26), P(params, "MACD", "signal", 9)); return { primary: m.map((p) => p.dif), pair: m.map((p) => p.dea) }; }
    case "KDJ": { const k = calculateKdj(candles, P(params, "KDJ", "period", 9), P(params, "KDJ", "k", 3), P(params, "KDJ", "d", 3)); return { primary: k.map((p) => p.k), pair: k.map((p) => p.d) }; }
    case "StochRSI": { const s = calculateStochRsi(candles, P(params, "StochRSI", "rsi", 14), P(params, "StochRSI", "stoch", 14), P(params, "StochRSI", "k", 3), P(params, "StochRSI", "d", 3)); return { primary: s.map((p) => p.k), pair: s.map((p) => p.d) }; }
    case "OBV": { const o = calculateObv(candles, P(params, "OBV", "signal", 20)); return { primary: o.map((p) => p.value), pair: o.map((p) => p.signal) }; }
    case "EMA": return { primary: calculateEma(candles, P(params, "EMA", "period", 20)).map((p) => p.value), pair: closes };
    case "BOLL": return { primary: calculateBoll(candles, P(params, "BOLL", "period", 20), P(params, "BOLL", "multiplier", 2)).map((p) => p.middle), pair: closes };
    case "SUPER": return { primary: calculateSuper(candles, P(params, "SUPER", "period", 10), P(params, "SUPER", "multiplier", 3)).map((p) => p.value), pair: closes };
    case "ATR": return { primary: calculateAtr(candles, P(params, "ATR", "period", 14)).map((p) => p.value) };
    case "WR": return { primary: calculateWr(candles, P(params, "WR", "period", 14)).map((p) => p.value) };
  }
}

/**
 * 在第 i 根已收盘 K 线上判断一个条件。
 * 金叉/死叉：primary 上穿/下穿 pair（对 EMA/BOLL/SUPER 来说是"价格 vs 指标线"，此时 primary 是指标线、pair 是价格，所以方向取反）。
 */
function holds(condition: Condition, lines: Lines, index: number): boolean | null {
  const cur = lines.primary[index]; const prev = index > 0 ? lines.primary[index - 1] : null;
  const priceVsLine = condition.indicator === "EMA" || condition.indicator === "BOLL" || condition.indicator === "SUPER";
  switch (condition.operator) {
    case "低于": return cur === null ? null : cur < condition.value;
    case "高于": return cur === null ? null : cur > condition.value;
    case "上穿": return cur === null || prev === null ? null : prev <= condition.value && cur > condition.value;
    case "下穿": return cur === null || prev === null ? null : prev >= condition.value && cur < condition.value;
    case "金叉":
    case "死叉": {
      if (!lines.pair) return null;
      const a = priceVsLine ? lines.pair : lines.primary; const b = priceVsLine ? lines.primary : lines.pair;
      const ca = a[index]; const cb = b[index]; const pa = index > 0 ? a[index - 1] : null; const pb = index > 0 ? b[index - 1] : null;
      if (ca === null || cb === null || pa === null || pb === null) return null;
      return condition.operator === "金叉" ? pa <= pb && ca > cb : pa >= pb && ca < cb;
    }
    default: return null;
  }
}

/**
 * 基础回测（做多、单仓位、全仓）。
 * 与旧版的区别：
 *  - 入场条件按 AND 全部满足才开仓；出场条件任一满足即平仓（旧版只读第一个入场/出场条件，且只认 RSI/MACD，其余全被静默忽略）；
 *  - 信号在已收盘 K 线 i 上产生，下一根 K 线开盘价成交（旧版用信号 K 线自己的收盘价成交，带前视偏差）；
 *  - 手续费按成交额双边各 0.1% 计；指标周期取自指标群组参数；
 *  - 条件不可用（指标未就绪、算子不适用）会进入 warnings，而不是悄悄当作"不触发"。
 */
export function backtest(candles: Candle[], conditions: Condition[], options: BacktestOptions = {}): BacktestResult {
  const initial = options.initialCash ?? 10_000; const fee = options.feeRate ?? 0.001;
  const entries = conditions.filter((c) => c.action === "入场"); const exits = conditions.filter((c) => c.action === "出场");
  const warnings: string[] = [];
  if (!entries.length) warnings.push("没有入场条件，回测不会开仓");
  if (!exits.length) warnings.push("没有出场条件，开仓后将持有到回测结束");
  const cache = new Map<IndicatorKind, Lines>();
  const lines = (kind: IndicatorKind) => { let value = cache.get(kind); if (!value) { value = indicatorLines(kind, candles, options.params); cache.set(kind, value); } return value; };
  for (const c of [...entries, ...exits]) if (["金叉", "死叉"].includes(c.operator) && !lines(c.indicator).pair) warnings.push(`${c.indicator} 不支持「${c.operator}」，该条件永不触发`);

  let cash = initial; let units = 0; let entryCash = 0; let pending: "enter" | "exit" | null = null;
  let wins = 0; let losses = 0; let grossWin = 0; let grossLoss = 0; const equity: number[] = [];
  candles.forEach((candle, index) => {
    if (pending === "enter" && !units) { entryCash = cash; units = cash * (1 - fee) / candle.open; cash = 0; }
    else if (pending === "exit" && units) {
      cash = units * candle.open * (1 - fee); units = 0;
      const pnl = cash - entryCash; if (pnl >= 0) { wins++; grossWin += pnl; } else { losses++; grossLoss -= pnl; }
    }
    pending = null;
    equity.push(units ? units * candle.close : cash);
    if (index === candles.length - 1) return; // 最后一根没有下一根开盘可成交
    if (!units) { if (entries.length && entries.every((c) => holds(c, lines(c.indicator), index) === true)) pending = "enter"; }
    else if (exits.some((c) => holds(c, lines(c.indicator), index) === true)) pending = "exit";
  });

  let peak = initial; let maxDrawdown = 0;
  for (const value of equity) { peak = Math.max(peak, value); maxDrawdown = Math.max(maxDrawdown, (peak - value) / peak * 100); }
  const final = equity.at(-1) ?? initial; const trades = wins + losses;
  return { trades, winRate: trades ? wins / trades * 100 : 0, returnPct: (final / initial - 1) * 100, maxDrawdown, profitFactor: grossLoss ? grossWin / grossLoss : grossWin ? 99 : 0, equity, warnings };
}

/**
 * RSI 入场阈值网格优化，带样本外检验：前 70% 选最优阈值，后 30% 单独回测。
 * 旧版在全部数据上挑"收益最高"的阈值并直接展示，这是典型的过拟合；展示样本外结果才有参考意义。
 */
export function optimizeRsiEntry(candles: Candle[], conditions: Condition[], options: BacktestOptions = {}, grid = [25, 30, 35, 40, 45]): OptimizationResult | null {
  const split = Math.floor(candles.length * 0.7);
  if (split < 50 || candles.length - split < 30) return null;
  const train = candles.slice(0, split); const test = candles.slice(split);
  const withThreshold = (value: number) => conditions.map((c) => c.indicator === "RSI" && c.action === "入场" ? { ...c, value } : c);
  const scored = grid.map((value) => ({ value, result: backtest(train, withThreshold(value), options) })).sort((a, b) => b.result.returnPct - a.result.returnPct)[0];
  return { bestValue: scored.value, inSample: scored.result, outOfSample: backtest(test, withThreshold(scored.value), options) };
}
