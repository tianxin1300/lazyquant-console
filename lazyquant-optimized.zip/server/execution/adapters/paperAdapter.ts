import { randomUUID } from "node:crypto";
import type { AccountSnapshot, NormalizedOrder, OrderStatus, SpotAdapter, SpotOrderIntent, UserDataStream } from "./types";

/** 只在本地内存中记录意图，不访问 Binance；用于 Phase A 和单元测试。 */
export class PaperSpotAdapter implements SpotAdapter {
  readonly marketType = "SPOT" as const;
  readonly mode = "paper" as const;
  private readonly orders = new Map<string, NormalizedOrder>();

  async getExchangeInfo() { return { source: "paper", symbols: [] }; }
  async getAccountSnapshot(): Promise<AccountSnapshot> { return { marketType: "SPOT", fetchedAt: Date.now(), balances: [], positions: [], canTrade: true, raw: { source: "paper" } }; }

  async createOrder(intent: SpotOrderIntent): Promise<NormalizedOrder> {
    if (intent.marketType !== "SPOT") throw new Error("Paper Spot adapter rejects non-Spot intent");
    const order: NormalizedOrder = { marketType: "SPOT", symbol: intent.symbol, orderId: `paper-${randomUUID()}`, clientOrderId: intent.clientOrderId, status: "NEW", side: intent.side, type: intent.type, origQty: intent.quantity, price: intent.price, stopPrice: intent.stopPrice, raw: { source: "paper", intent } };
    this.orders.set(order.clientOrderId, order); return order;
  }

  async queryOrder(_symbol: string, orderId?: string, clientOrderId?: string) { return this.find(orderId, clientOrderId); }
  async cancelOrder(_symbol: string, orderId?: string, clientOrderId?: string) { const order = this.find(orderId, clientOrderId); const canceled = { ...order, status: "CANCELED" as OrderStatus }; this.orders.set(canceled.clientOrderId, canceled); return canceled; }
  async createUserDataStream(): Promise<UserDataStream> { return { marketType: "SPOT", listenKey: `paper-${randomUUID()}`, wsUrl: "ws://paper.invalid", expiresAt: Date.now() + 60 * 60 * 1000 }; }
  async keepAliveUserDataStream(_listenKey: string) {}
  async closeUserDataStream(_listenKey: string) {}

  private find(orderId?: string, clientOrderId?: string) {
    const order = [...this.orders.values()].find((item) => item.orderId === orderId || item.clientOrderId === clientOrderId);
    if (!order) throw new Error("Paper order not found");
    return order;
  }
}
