import { AdapterRequestError } from "./types";

/**
 * 轻量级进程内权重限速器。Spot 与 Futures 各自持有实例；
 * 它不是交易所额度的替代品，429/418 仍必须进入上层保护流程。
 */
export class BinanceRateLimiter {
  private windowStartedAt = Date.now();
  private usedWeight = 0;

  constructor(private readonly maxWeightPerMinute = 1_200) {}

  async wait(weight = 1) {
    if (!Number.isInteger(weight) || weight < 1) throw new AdapterRequestError("Invalid Binance request weight", "INVALID_REQUEST_WEIGHT");
    if (weight > this.maxWeightPerMinute) throw new AdapterRequestError("Request weight exceeds local limiter capacity", "REQUEST_WEIGHT_TOO_LARGE");
    while (true) {
      const elapsed = Date.now() - this.windowStartedAt;
      if (elapsed >= 60_000) { this.windowStartedAt = Date.now(); this.usedWeight = 0; }
      if (this.usedWeight + weight <= this.maxWeightPerMinute) { this.usedWeight += weight; return; }
      await new Promise((resolve) => setTimeout(resolve, Math.max(50, 60_000 - elapsed)));
    }
  }
}
