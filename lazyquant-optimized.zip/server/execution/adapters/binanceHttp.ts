import { createHmac, randomUUID } from "node:crypto";
import { AdapterConfigurationError, AdapterRequestError, type AdapterConfig, type ExecutionMode } from "./types";
import { BinanceRateLimiter } from "./rateLimiter";

export const LIVE_CONFIRMATION = "I_UNDERSTAND_LIVE_TRADING";

export type BinanceRequestOptions = {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  path: string;
  params?: Record<string, string | number | boolean | undefined>;
  signed?: boolean;
  apiKeyOnly?: boolean;
  tradeWrite?: boolean;
  weight?: number;
};

function defaultBaseUrl(domain: "SPOT" | "USD_M_FUTURES", mode: ExecutionMode) {
  if (domain === "SPOT") return mode === "testnet" || mode === "demo" ? "https://testnet.binance.vision" : "https://api.binance.com";
  return mode === "testnet" || mode === "demo" ? "https://demo-fapi.binance.com" : "https://fapi.binance.com";
}

function defaultWsBaseUrl(domain: "SPOT" | "USD_M_FUTURES", mode: ExecutionMode) {
  if (domain === "SPOT") return mode === "testnet" || mode === "demo" ? "wss://stream.binance.vision/ws" : "wss://stream.binance.com:9443/ws";
  return mode === "testnet" || mode === "demo" ? "wss://demo-fstream.binance.com/ws" : "wss://fstream.binance.com/ws";
}

export class BinanceHttpClient {
  readonly baseUrl: string;
  readonly wsBaseUrl: string;
  readonly mode: ExecutionMode;
  private readonly timeoutMs: number;
  private readonly recvWindowMs: number;
  private readonly rateLimiter: BinanceRateLimiter;

  constructor(
    private readonly domain: "SPOT" | "USD_M_FUTURES",
    private readonly config: AdapterConfig,
  ) {
    this.mode = config.mode;
    this.baseUrl = (config.baseUrl ?? defaultBaseUrl(domain, config.mode)).replace(/\/$/, "");
    this.wsBaseUrl = (config.wsBaseUrl ?? defaultWsBaseUrl(domain, config.mode)).replace(/\/$/, "");
    this.timeoutMs = config.timeoutMs ?? 8_000;
    this.recvWindowMs = config.recvWindowMs ?? 5_000;
    this.rateLimiter = new BinanceRateLimiter(config.requestWeightLimitPerMinute ?? 1_200);
  }

  async request<T>(options: BinanceRequestOptions): Promise<T> {
    await this.rateLimiter.wait(options.weight ?? 1);
    if (options.tradeWrite) this.assertTradeEnabled();
    if ((options.signed || options.apiKeyOnly) && !this.config.apiKey) {
      throw new AdapterConfigurationError(`${this.domain} API key is required for this request`);
    }
    if (options.signed && !this.config.apiSecret) {
      throw new AdapterConfigurationError(`${this.domain} API secret is required for signed requests`);
    }

    const params: Record<string, string> = {};
    Object.entries(options.params ?? {}).forEach(([key, value]) => {
      if (value !== undefined) params[key] = String(value);
    });
    if (options.signed) {
      params.timestamp = String(Date.now());
      params.recvWindow = String(this.recvWindowMs);
      const query = new URLSearchParams(params).toString();
      params.signature = createHmac("sha256", this.config.apiSecret!).update(query).digest("hex");
    }

    const method = options.method ?? "GET";
    const url = new URL(`${this.baseUrl}${options.path}`);
    const query = new URLSearchParams(params).toString();
    const init: RequestInit = { method, headers: { accept: "application/json" } };
    if (this.config.apiKey) (init.headers as Record<string, string>)["X-MBX-APIKEY"] = this.config.apiKey;
    if (method === "GET" || method === "DELETE") url.search = query;
    else {
      (init.headers as Record<string, string>)["content-type"] = "application/x-www-form-urlencoded";
      init.body = query;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    const requestId = randomUUID();
    try {
      const response = await fetch(url, { ...init, signal: controller.signal });
      const raw = await response.text();
      let payload: unknown = null;
      try { payload = raw ? JSON.parse(raw) : null; } catch { payload = raw; }
      if (!response.ok) throw this.toRequestError(response.status, payload, requestId);
      return payload as T;
    } catch (error) {
      if (error instanceof AdapterRequestError) throw error;
      if (error instanceof Error && error.name === "AbortError") {
        throw new AdapterRequestError(`${this.domain} request timed out`, "TIMEOUT", 408, true);
      }
      throw new AdapterRequestError(`${this.domain} request failed`, "NETWORK_ERROR", undefined, true);
    } finally {
      clearTimeout(timeout);
    }
  }

  assertTradeEnabled() {
    if (this.mode === "paper") throw new AdapterConfigurationError(`${this.domain} paper mode cannot call Binance trade endpoints`);
    if (!this.config.apiKey || !this.config.apiSecret) throw new AdapterConfigurationError(`${this.domain} trade requests require API credentials`);
    if (this.mode === "live" && (this.config.allowLiveTrading !== true || this.config.liveConfirmation !== LIVE_CONFIRMATION)) {
      throw new AdapterConfigurationError(`${this.domain} live trading is locked; explicit live confirmation is required`);
    }
  }

  private toRequestError(status: number, payload: unknown, requestId: string) {
    const body = typeof payload === "object" && payload !== null ? payload as { code?: number; msg?: string } : {};
    const message = typeof body.msg === "string" ? body.msg : `Binance request failed (${status})`;
    if (status === 503 && /unknown error|please check your request/i.test(message)) {
      return new AdapterRequestError(`Binance execution status unknown [${requestId}]`, "UNKNOWN_EXECUTION", status, false, true);
    }
    if (status === 429 || status === 418) return new AdapterRequestError(`Binance rate limit response [${requestId}]`, "RATE_LIMIT", status, true);
    if (status === 408) return new AdapterRequestError(`Binance timeout response [${requestId}]`, "TIMEOUT", status, true);
    return new AdapterRequestError(`Binance request rejected [${requestId}]`, `BINANCE_${body.code ?? status}`, status, status >= 500);
  }
}
