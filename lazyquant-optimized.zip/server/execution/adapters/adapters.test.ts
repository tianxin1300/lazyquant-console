import { describe, expect, it } from "vitest";
import { BinanceHttpClient, LIVE_CONFIRMATION } from "./binanceHttp";
import { PaperSpotAdapter } from "./paperAdapter";
import { BinanceSpotAdapter } from "./spotAdapter";
import { BinanceUsdmFuturesAdapter } from "./usdmFuturesAdapter";

describe("Binance domain adapters", () => {
  it("locks paper mode before any Binance trade request", () => {
    const client = new BinanceHttpClient("SPOT", { mode: "paper", apiKey: "k", apiSecret: "s" });
    expect(() => client.assertTradeEnabled()).toThrow(/paper mode/);
  });

  it("requires an explicit live confirmation", () => {
    const client = new BinanceHttpClient("USD_M_FUTURES", { mode: "live", apiKey: "k", apiSecret: "s", allowLiveTrading: true });
    expect(() => client.assertTradeEnabled()).toThrow(/live trading is locked/);
    const approved = new BinanceHttpClient("USD_M_FUTURES", { mode: "live", apiKey: "k", apiSecret: "s", allowLiveTrading: true, liveConfirmation: LIVE_CONFIRMATION });
    expect(() => approved.assertTradeEnabled()).not.toThrow();
  });

  it("keeps Spot from accepting Futures-only fields", async () => {
    const adapter = new BinanceSpotAdapter({ mode: "demo", apiKey: "k", apiSecret: "s" });
    await expect(adapter.createOrder({ marketType: "SPOT", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "0.001", clientOrderId: "spot-1", positionSide: "BOTH" } as never)).rejects.toThrow(/Futures-only/);
  });

  it("keeps Futures order rules explicit", async () => {
    const adapter = new BinanceUsdmFuturesAdapter({ mode: "demo", apiKey: "k", apiSecret: "s" });
    await expect(adapter.createOrder({ marketType: "USD_M_FUTURES", symbol: "BTCUSDT", side: "SELL", type: "STOP_MARKET", quantity: "0.001", closePosition: true, clientOrderId: "futures-1" })).rejects.toThrow(/cannot include quantity/);
  });

  it("uses paper storage without network access", async () => {
    const adapter = new PaperSpotAdapter();
    const created = await adapter.createOrder({ marketType: "SPOT", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "0.001", clientOrderId: "paper-1" });
    expect(created.status).toBe("NEW");
    const canceled = await adapter.cancelOrder("BTCUSDT", undefined, "paper-1");
    expect(canceled.status).toBe("CANCELED");
  });
});
