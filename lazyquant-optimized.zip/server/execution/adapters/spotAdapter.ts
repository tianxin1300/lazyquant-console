import { BinanceHttpClient } from "./binanceHttp";
import {
  type AccountBalance,
  type AccountSnapshot,
  type AdapterConfig,
  type NormalizedOrder,
  type SpotAdapter as SpotAdapterContract,
  type SpotOrderIntent,
  type UserDataStream,
} from "./types";

type SpotOrderResponse = {
  symbol: string; orderId: number; clientOrderId: string; transactTime?: number; price?: string; origQty?: string; executedQty?: string;
  cummulativeQuoteQty?: string; status: string; timeInForce?: string; type: string; side: "BUY" | "SELL"; updateTime?: number;
};

type SpotAccountResponse = { canTrade: boolean; balances: Array<{ asset: string; free: string; locked: string }> };

export class BinanceSpotAdapter implements SpotAdapterContract {
  readonly marketType = "SPOT" as const;
  readonly mode;
  private readonly http: BinanceHttpClient;

  constructor(config: AdapterConfig) {
    this.mode = config.mode;
    this.http = new BinanceHttpClient("SPOT", config);
  }

  getExchangeInfo(symbol?: string) {
    return this.http.request({ path: "/api/v3/exchangeInfo", params: symbol ? { symbol } : undefined });
  }

  async getAccountSnapshot(): Promise<AccountSnapshot> {
    const payload = await this.http.request<SpotAccountResponse>({ path: "/api/v3/account", signed: true });
    const balances: AccountBalance[] = payload.balances.map((balance) => ({ asset: balance.asset, free: balance.free, locked: balance.locked }));
    return { marketType: "SPOT", fetchedAt: Date.now(), balances, positions: [], canTrade: payload.canTrade, raw: payload };
  }

  async createOrder(intent: SpotOrderIntent): Promise<NormalizedOrder> {
    this.assertSpotIntent(intent);
    const payload = await this.http.request<SpotOrderResponse>({
      method: "POST", path: "/api/v3/order", signed: true, tradeWrite: true,
      params: {
        symbol: intent.symbol, side: intent.side, type: intent.type, quantity: intent.quantity, quoteOrderQty: intent.quoteOrderQty,
        price: intent.price, stopPrice: intent.stopPrice, timeInForce: intent.timeInForce,
        newClientOrderId: intent.clientOrderId, newOrderRespType: intent.newOrderRespType ?? "RESULT",
      },
    });
    return this.normalizeOrder(payload);
  }

  async queryOrder(symbol: string, orderId?: string, clientOrderId?: string) {
    const payload = await this.http.request<SpotOrderResponse>({ path: "/api/v3/order", signed: true, params: { symbol, orderId, origClientOrderId: clientOrderId } });
    return this.normalizeOrder(payload);
  }

  async cancelOrder(symbol: string, orderId?: string, clientOrderId?: string) {
    const payload = await this.http.request<SpotOrderResponse>({ method: "DELETE", path: "/api/v3/order", signed: true, tradeWrite: true, params: { symbol, orderId, origClientOrderId: clientOrderId } });
    return this.normalizeOrder(payload);
  }

  async createUserDataStream(): Promise<UserDataStream> {
    const payload = await this.http.request<{ listenKey: string }>({ method: "POST", path: "/api/v3/userDataStream", apiKeyOnly: true });
    return { marketType: "SPOT", listenKey: payload.listenKey, wsUrl: `${this.http.wsBaseUrl}/${payload.listenKey}`, expiresAt: Date.now() + 60 * 60 * 1000 };
  }

  async keepAliveUserDataStream(listenKey: string) {
    await this.http.request({ method: "PUT", path: "/api/v3/userDataStream", apiKeyOnly: true, params: { listenKey } });
  }

  async closeUserDataStream(listenKey: string) {
    await this.http.request({ method: "DELETE", path: "/api/v3/userDataStream", apiKeyOnly: true, params: { listenKey } });
  }

  private assertSpotIntent(intent: SpotOrderIntent) {
    if (intent.marketType !== "SPOT") throw new Error("Spot adapter rejects non-Spot order intent");
    if ("positionSide" in intent || "reduceOnly" in intent || "closePosition" in intent || "workingType" in intent) throw new Error("Spot adapter rejects Futures-only order fields");
    if (!intent.clientOrderId || !/^[.A-Z:/a-z0-9_-]{1,36}$/.test(intent.clientOrderId)) throw new Error("Invalid Spot clientOrderId");
    if (!intent.quantity && !intent.quoteOrderQty) throw new Error("Spot order requires quantity or quoteOrderQty");
  }

  private normalizeOrder(payload: SpotOrderResponse): NormalizedOrder {
    return { marketType: "SPOT", symbol: payload.symbol, orderId: String(payload.orderId), clientOrderId: payload.clientOrderId, status: payload.status as NormalizedOrder["status"], side: payload.side, type: payload.type as NormalizedOrder["type"], origQty: payload.origQty, executedQty: payload.executedQty, avgPrice: payload.executedQty && Number(payload.executedQty) > 0 && payload.cummulativeQuoteQty ? (Number(payload.cummulativeQuoteQty) / Number(payload.executedQty)).toString() : undefined, price: payload.price, updateTime: payload.updateTime ?? payload.transactTime, raw: payload };
  }
}
