# Binance Spot / USDⓈ-M Futures 适配器

这一层只负责交易所协议适配，不负责策略、仓位分配或硬风控。上层必须先通过 Hard Risk Gateway，再调用 `createOrder`、`cancelOrder` 或 `setLeverage`。

## 适配器边界

- `BinanceSpotAdapter` 只访问 Spot REST 与 Spot User Data Stream。
- `BinanceUsdmFuturesAdapter` 只访问 USDⓈ-M Futures REST 与 Futures User Data Stream。
- Spot 订单不能携带 `positionSide`、`reduceOnly`、`closePosition`、`workingType`。
- Futures 订单明确处理 `positionSide`、`reduceOnly`、`closePosition`、`workingType` 和 `newClientOrderId`。
- `PaperSpotAdapter` 不访问网络，只用于 Phase A 和单元测试。
- `createAdapter("USD_M_FUTURES", { mode: "paper" })` 会拒绝，因为当前没有伪造 Futures 仓位账本；不得把 Spot Paper 适配器冒充 Futures。

## 环境模式

```ts
import { BinanceSpotAdapter, BinanceUsdmFuturesAdapter } from "./server/execution/adapters";

const spot = new BinanceSpotAdapter({
  mode: "demo",
  apiKey: process.env.BINANCE_SPOT_API_KEY,
  apiSecret: process.env.BINANCE_SPOT_API_SECRET,
});

const futures = new BinanceUsdmFuturesAdapter({
  mode: "demo",
  apiKey: process.env.BINANCE_USDM_API_KEY,
  apiSecret: process.env.BINANCE_USDM_API_SECRET,
});
```

`demo` / `testnet` 使用测试环境基地址；`live` 使用生产基地址。真实交易还必须同时设置：

```text
allowLiveTrading: true
liveConfirmation: I_UNDERSTAND_LIVE_TRADING
```

如果没有这两个条件，适配器不会发出交易写请求。`paper` 模式不会访问 Binance 的交易写接口。

## 请求语义

- `503 Unknown` 映射为 `AdapterRequestError`，`executionUnknown=true`；上层必须先查询订单或等待 User Data Stream，禁止直接重试。
- `429` / `418` 映射为 `RATE_LIMIT`，上层必须退避并进入限速保护。
- 网络超时映射为 `TIMEOUT`；订单提交超时不能直接假定失败。
- API key、secret、签名和完整请求体不会写入适配器错误消息或日志。

## 用户数据流

`createUserDataStream()` 只负责申请 listen key 并返回 WebSocket URL。续期和重连由上层连接管理器负责，不能假定连接会永久有效。Futures 和 Spot 的 listen key、WebSocket 地址和事件解码器必须分别维护。

## 当前未包含

这一批没有把适配器接入现有页面，也没有把它接入实时执行循环或真实账户。下一步应先实现 `HardRiskGateway`、账户/订单/仓位账本、对账器和 User Data Stream 解码器，再进行 Binance Demo/Testnet 验证。
