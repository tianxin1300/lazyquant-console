export * from "./types";
export * from "./binanceHttp";
export * from "./rateLimiter";
export * from "./spotAdapter";
export * from "./usdmFuturesAdapter";
export * from "./paperAdapter";

import { BinanceSpotAdapter } from "./spotAdapter";
import { BinanceUsdmFuturesAdapter } from "./usdmFuturesAdapter";
import { PaperSpotAdapter } from "./paperAdapter";
import type { AdapterConfig, MarketType, SpotAdapter, UsdmFuturesAdapter } from "./types";

export function createAdapter(marketType: "SPOT", config: AdapterConfig): SpotAdapter;
export function createAdapter(marketType: "USD_M_FUTURES", config: AdapterConfig): UsdmFuturesAdapter;
export function createAdapter(marketType: MarketType, config: AdapterConfig): SpotAdapter | UsdmFuturesAdapter {
  if (config.mode === "paper") {
    if (marketType !== "SPOT") throw new Error("Paper Futures adapter is not implemented; use a Futures simulator explicitly");
    return new PaperSpotAdapter();
  }
  return marketType === "SPOT" ? new BinanceSpotAdapter(config) : new BinanceUsdmFuturesAdapter(config);
}
