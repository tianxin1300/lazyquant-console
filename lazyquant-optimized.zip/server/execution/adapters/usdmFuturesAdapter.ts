import { BinanceHttpClient } from "./binanceHttp";
import {
  type AccountBalance,
  type AccountSnapshot,
  type AdapterConfig,
  type FuturesOrderIntent,
  type NormalizedOrder,
  type PositionSnapshot,
  type UsdmFuturesAdapter as FuturesAdapterContract,
  type UserDataStream,
} from "./types";

type FuturesOrderResponse = {
  symbol: string; orderId: number; clientOrderId: string; price?: string; origQty?: string; executedQty?: string; avgPrice?: string;
  status: string; type: string; side: "BUY" | "SELL"; positionSide?: "BOTH" | "LONG" | "SHORT"; reduceOnly?: boolean; closePosition?: boolean; stopPrice?: string; updateTime?: number;
};
type FuturesAccountResponse = { canTrade: boolean; assets: Array<{ asset: string; walletBalance: string; availableBalance: string }>; positions: Array<{ symbol: string; positionAmt: string; positionSide: "BOTH" | "LONG" | "SHORT"; entryPrice: string; markPrice?: string; unRealizedProfit?: string; liquidationPrice?: string; leverage?: string; isolated?: boolean }> };
type FuturesPositionRiskResponse = Array<{ symbol: string; positionAmt: string; positionSide: "BOTH" | "LONG" | "SHORT"; entryPrice: string; markPrice: string; unRealizedProfit: string; liquidationPrice: string; leverage: string; isolated: boolean }>;

export class BinanceUsdmFuturesAdapter implements FuturesAdapterContract {
  readonly marketType = "USD_M_FUTURES" as const;
  readonly mode;
  private readonly http: BinanceHttpClient;

  constructor(config: AdapterConfig) {
    this.mode = config.mode;
    this.http = new BinanceHttpClient("USD_M_FUTURES", config);
  }

  getExchangeInfo(symbol?: string) {
    return this.http.request({ path: "/fapi/v1/exchangeInfo", params: symbol ? { symbol } : undefined });
  }

  async getAccountSnapshot(): Promise<AccountSnapshot> {
    const payload = await this.http.request<FuturesAccountResponse>({ path: "/fapi/v2/account", signed: true });
    const balances: AccountBalance[] = payload.assets.map((asset) => ({ asset: asset.asset, free: asset.availableBalance, locked: (Number(asset.walletBalance) - Number(asset.availableBalance)).toString(), walletBalance: asset.walletBalance, availableBalance: asset.availableBalance }));
    const positions = payload.positions.map((position) => this.normalizePosition(position));
    return { marketType: "USD_M_FUTURES", fetchedAt: Date.now(), balances, positions, canTrade: payload.canTrade, raw: payload };
  }

  async getPositionRisk(symbol?: string) {
    const payload = await this.http.request<FuturesPositionRiskResponse>({ path: "/fapi/v2/positionRisk", signed: true, params: symbol ? { symbol } : undefined });
    return payload.map((position) => this.normalizePosition(position));
  }

  async getLeverage(symbol: string) {
    const positions = await this.getPositionRisk(symbol);
    return positions.find((position) => position.symbol === symbol)?.leverage ? Number(positions.find((position) => position.symbol === symbol)!.leverage) : undefined;
  }

  async createOrder(intent: FuturesOrderIntent): Promise<NormalizedOrder> {
    this.assertFuturesIntent(intent);
    const payload = await this.http.request<FuturesOrderResponse>({
      method: "POST", path: "/fapi/v1/order", signed: true, tradeWrite: true,
      params: {
        symbol: intent.symbol, side: intent.side, type: intent.type, quantity: intent.quantity, price: intent.price, stopPrice: intent.stopPrice,
        timeInForce: intent.timeInForce, positionSide: intent.positionSide ?? "BOTH", reduceOnly: intent.reduceOnly, closePosition: intent.closePosition,
        workingType: intent.workingType ?? "MARK_PRICE", priceProtect: intent.priceProtect, newClientOrderId: intent.clientOrderId, newOrderRespType: intent.newOrderRespType ?? "RESULT",
      },
    });
    return this.normalizeOrder(payload);
  }

  async queryOrder(symbol: string, orderId?: string, clientOrderId?: string) {
    const payload = await this.http.request<FuturesOrderResponse>({ path: "/fapi/v1/order", signed: true, params: { symbol, orderId, origClientOrderId: clientOrderId } });
    return this.normalizeOrder(payload);
  }

  async cancelOrder(symbol: string, orderId?: string, clientOrderId?: string) {
    const payload = await this.http.request<FuturesOrderResponse>({ method: "DELETE", path: "/fapi/v1/order", signed: true, tradeWrite: true, params: { symbol, orderId, origClientOrderId: clientOrderId } });
    return this.normalizeOrder(payload);
  }

  async setLeverage(symbol: string, leverage: number) {
    if (!Number.isInteger(leverage) || leverage < 1 || leverage > 125) throw new Error("Invalid Futures leverage");
    const payload = await this.http.request<{ symbol: string; leverage: number; maxNotionalValue?: string }>({ method: "POST", path: "/fapi/v1/leverage", signed: true, tradeWrite: true, params: { symbol, leverage } });
    return { ...payload, raw: payload };
  }

  async createUserDataStream(): Promise<UserDataStream> {
    const payload = await this.http.request<{ listenKey: string }>({ method: "POST", path: "/fapi/v1/listenKey", apiKeyOnly: true });
    return { marketType: "USD_M_FUTURES", listenKey: payload.listenKey, wsUrl: `${this.http.wsBaseUrl}/${payload.listenKey}`, expiresAt: Date.now() + 60 * 60 * 1000 };
  }

  async keepAliveUserDataStream(listenKey: string) {
    await this.http.request({ method: "PUT", path: "/fapi/v1/listenKey", apiKeyOnly: true, params: { listenKey } });
  }

  async closeUserDataStream(listenKey: string) {
    await this.http.request({ method: "DELETE", path: "/fapi/v1/listenKey", apiKeyOnly: true, params: { listenKey } });
  }

  private assertFuturesIntent(intent: FuturesOrderIntent) {
    if (intent.marketType !== "USD_M_FUTURES") throw new Error("Futures adapter rejects non-Futures order intent");
    if (!intent.clientOrderId || !/^[.A-Z:/a-z0-9_-]{1,36}$/.test(intent.clientOrderId)) throw new Error("Invalid Futures clientOrderId");
    if (intent.type !== "STOP_MARKET" && intent.type !== "TAKE_PROFIT_MARKET" && !intent.quantity) throw new Error("Futures order requires quantity unless using a close-position market order");
    if (intent.closePosition && intent.type !== "STOP_MARKET" && intent.type !== "TAKE_PROFIT_MARKET") throw new Error("closePosition is only valid for Futures stop market orders");
    if (intent.closePosition && intent.quantity) throw new Error("closePosition order cannot include quantity");
    if (intent.positionSide && !["BOTH", "LONG", "SHORT"].includes(intent.positionSide)) throw new Error("Invalid Futures positionSide");
  }

  private normalizeOrder(payload: FuturesOrderResponse): NormalizedOrder {
    return { marketType: "USD_M_FUTURES", symbol: payload.symbol, orderId: String(payload.orderId), clientOrderId: payload.clientOrderId, status: payload.status as NormalizedOrder["status"], side: payload.side, type: payload.type as NormalizedOrder["type"], positionSide: payload.positionSide, reduceOnly: payload.reduceOnly, closePosition: payload.closePosition, origQty: payload.origQty, executedQty: payload.executedQty, avgPrice: payload.avgPrice, price: payload.price, stopPrice: payload.stopPrice, updateTime: payload.updateTime, raw: payload };
  }

  private normalizePosition(position: FuturesAccountResponse["positions"][number] | FuturesPositionRiskResponse[number]): PositionSnapshot {
    return { symbol: position.symbol, positionAmt: position.positionAmt, positionSide: position.positionSide, entryPrice: position.entryPrice, markPrice: position.markPrice, unrealizedPnl: position.unRealizedProfit, liquidationPrice: position.liquidationPrice, leverage: position.leverage, marginType: "isolated" in position && position.isolated ? "isolated" : "cross" };
  }
}
