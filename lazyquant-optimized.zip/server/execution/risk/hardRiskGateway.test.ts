import { describe, expect, it } from "vitest";
import { HardRiskGateway, RiskRejectedError, createRiskLimits } from "./hardRiskGateway";
import { PaperSpotAdapter } from "../adapters/paperAdapter";

const baseContext = (overrides: Partial<Parameters<HardRiskGateway["evaluate"]>[1]> = {}) => ({
  now: 1_000_000,
  marketDataAt: 1_000_000,
  candleClosed: true,
  accountSyncedAt: 1_000_000,
  reconciliationOk: true,
  serverTimeOffsetMs: 0,
  state: "RUNNING" as const,
  dailyPnl: 0,
  totalPnl: 0,
  drawdownPct: 0,
  consecutiveLosses: 0,
  totalExposure: 0,
  exposureBySymbol: {},
  exposureByStrategy: {},
  pendingUnknownOrder: false,
  referencePrice: 100,
  ...overrides,
});

describe("HardRiskGateway", () => {
  it("caps runtime limits instead of allowing a wider limit", () => {
    expect(createRiskLimits({ maxSingleEntryNotional: 999_999 }).maxSingleEntryNotional).toBe(500);
  });

  it("rejects Spot opening without signal id and enforces single-entry cap", () => {
    const gateway = new HardRiskGateway(new PaperSpotAdapter());
    const decision = gateway.evaluate({ marketType: "SPOT", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "10", clientOrderId: "spot-1", intentType: "OPEN" }, baseContext());
    expect(decision.allowed).toBe(false);
    expect(decision.reasons).toEqual(expect.arrayContaining(["OPENING_SIGNAL_ID_REQUIRED", "MAX_SINGLE_ENTRY_NOTIONAL"]));
  });

  it("allows a valid Spot opening once and rejects the duplicate signal", async () => {
    const gateway = new HardRiskGateway(new PaperSpotAdapter());
    const intent = { marketType: "SPOT" as const, symbol: "BTCUSDT", side: "BUY" as const, type: "MARKET" as const, quantity: "1", clientOrderId: "spot-2", signalId: "sig-1", strategyId: "s1", strategyVersion: "v1", intentType: "OPEN" as const };
    await expect(gateway.submit(intent, baseContext())).resolves.toMatchObject({ status: "NEW" });
    const duplicate = gateway.evaluate({ ...intent, clientOrderId: "spot-3" }, baseContext());
    expect(duplicate.reasons).toContain("DUPLICATE_SIGNAL");
  });

  it("blocks all new openings in protective-only mode but allows explicit reduction", () => {
    const gateway = new HardRiskGateway(new PaperSpotAdapter());
    gateway.enterProtectiveOnly();
    const opening = gateway.evaluate({ marketType: "SPOT", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "1", clientOrderId: "spot-4", signalId: "sig-2", strategyVersion: "v1", intentType: "OPEN" }, baseContext({ state: "PROTECTIVE_ONLY" }));
    expect(opening.allowed).toBe(false);
    expect(opening.reasons).toContain("PROTECTIVE_ONLY_BLOCKS_OPENING");
    const reduction = gateway.evaluate({ marketType: "SPOT", symbol: "BTCUSDT", side: "SELL", type: "MARKET", quantity: "1", clientOrderId: "spot-5", intentType: "REDUCE" }, baseContext({ state: "PROTECTIVE_ONLY" }));
    expect(reduction.allowed).toBe(true);
  });

  it("fails closed on stale market data, reconciliation mismatch, and unknown orders", () => {
    const gateway = new HardRiskGateway(new PaperSpotAdapter());
    const decision = gateway.evaluate({ marketType: "SPOT", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "1", clientOrderId: "spot-6", signalId: "sig-3", strategyVersion: "v1", intentType: "OPEN" }, baseContext({ marketDataAt: 0, reconciliationOk: false, pendingUnknownOrder: true }));
    expect(decision.allowed).toBe(false);
    expect(decision.reasons).toEqual(expect.arrayContaining(["MARKET_DATA_STALE", "RECONCILIATION_NOT_CONFIRMED", "PENDING_UNKNOWN_ORDER"]));
  });

  it("does not throw a generic error before returning a risk decision", () => {
    const gateway = new HardRiskGateway(new PaperSpotAdapter());
    expect(() => gateway.evaluate({ marketType: "USD_M_FUTURES", symbol: "BTCUSDT", side: "BUY", type: "MARKET", quantity: "1", clientOrderId: "f-1", intentType: "OPEN" } as never, baseContext())).not.toThrow(RiskRejectedError);
  });
});
