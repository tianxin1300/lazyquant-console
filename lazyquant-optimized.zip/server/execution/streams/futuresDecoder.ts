import type { AccountBalance, NormalizedOrder, OrderStatus, PositionSnapshot } from "../adapters/types";
import type { DecodedUserEvent, TradeFill } from "./types";

function asRecord(value: unknown): Record<string, unknown> | null { return typeof value === "object" && value !== null ? value as Record<string, unknown> : null; }
function text(value: unknown) { return typeof value === "string" || typeof value === "number" ? String(value) : undefined; }
function number(value: unknown, fallback = 0) { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : fallback; }
function status(value: unknown): OrderStatus { const candidate = text(value); return candidate === "NEW" || candidate === "PARTIALLY_FILLED" || candidate === "FILLED" || candidate === "CANCELED" || candidate === "EXPIRED" || candidate === "REJECTED" ? candidate : "UNKNOWN"; }

function normalizePosition(value: Record<string, unknown>): PositionSnapshot | null {
  const symbol = text(value.s); if (!symbol) return null;
  return { symbol, positionAmt: text(value.pa) ?? "0", positionSide: text(value.ps) === "LONG" || text(value.ps) === "SHORT" ? text(value.ps) as "LONG" | "SHORT" : "BOTH", entryPrice: text(value.ep) ?? "0", markPrice: text(value.mp), unrealizedPnl: text(value.up), liquidationPrice: text(value.l), leverage: text(value.leverage), marginType: text(value.mt) === "isolated" ? "isolated" : "cross" };
}

export function decodeFuturesUserEvent(input: string | unknown): DecodedUserEvent | null {
  let parsed: unknown = input;
  if (typeof input === "string") { try { parsed = JSON.parse(input); } catch { return null; } }
  const root = asRecord(parsed); const event = asRecord(root?.event) ?? root;
  if (!event) return null;
  const eventType = text(event.e) ?? "UNKNOWN"; const eventTime = number(event.E, Date.now());
  if (eventType === "ORDER_TRADE_UPDATE") {
    const payload = asRecord(event.o); if (!payload) return null;
    const symbol = text(payload.s) ?? ""; const orderId = text(payload.i); const clientOrderId = text(payload.c) ?? ""; const orderType = text(payload.o) as NormalizedOrder["type"];
    const order: NormalizedOrder = { marketType: "USD_M_FUTURES", symbol, orderId, clientOrderId, status: status(payload.X), side: text(payload.S) === "SELL" ? "SELL" : "BUY", type: orderType, positionSide: text(payload.ps) === "LONG" || text(payload.ps) === "SHORT" ? text(payload.ps) as "LONG" | "SHORT" : "BOTH", reduceOnly: payload.R === true || text(payload.R) === "true", closePosition: payload.cp === true || text(payload.cp) === "true", origQty: text(payload.q), executedQty: text(payload.z), avgPrice: text(payload.ap), price: text(payload.p), stopPrice: text(payload.sp), updateTime: number(payload.T, eventTime), raw: payload };
    const lastQty = text(payload.l) ?? "0"; const fill: TradeFill | undefined = Number(lastQty) > 0 ? { tradeId: text(payload.t), orderId, clientOrderId, symbol, side: order.side, quantity: lastQty, price: text(payload.L) ?? "0", commission: text(payload.n), commissionAsset: text(payload.N), realizedPnl: text(payload.rp), eventTime } : undefined;
    return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:order:${orderId}:${text(payload.x) ?? payload.X}:${text(payload.T) ?? eventTime}:${text(payload.t) ?? ""}`, order, fill, raw: parsed };
  }
  if (eventType === "ACCOUNT_UPDATE") {
    const account = asRecord(event.a); if (!account) return null;
    const balances: AccountBalance[] = Array.isArray(account.B) ? account.B.map((item) => { const balance = asRecord(item); return { asset: text(balance?.a) ?? "", free: text(balance?.cw) ?? text(balance?.wb) ?? "0", locked: "0", walletBalance: text(balance?.wb), availableBalance: text(balance?.cw) }; }).filter((item) => item.asset) : [];
    const positions = Array.isArray(account.P) ? account.P.map((item) => normalizePosition(asRecord(item) ?? {})).filter((item): item is PositionSnapshot => Boolean(item)) : [];
    return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:account:${text(event.T) ?? eventTime}:${text(account.m) ?? ""}`, balances, positions, raw: parsed };
  }
  if (eventType === "MARGIN_CALL") return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:margin-call:${eventTime}`, riskSignal: "MARGIN_CALL", raw: parsed };
  if (eventType === "listenKeyExpired") return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:listen-expired:${eventTime}`, riskSignal: "LISTEN_KEY_EXPIRED", raw: parsed };
  if (eventType === "ACCOUNT_CONFIG_UPDATE") return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:config:${eventTime}`, riskSignal: "RECONCILIATION_REQUIRED", raw: parsed };
  return { marketType: "USD_M_FUTURES", eventType, eventTime, eventKey: `futures:event:${eventType}:${eventTime}`, raw: parsed };
}
