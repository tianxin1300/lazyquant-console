import type { AccountBalance, NormalizedOrder, OrderStatus } from "../adapters/types";
import type { DecodedUserEvent, TradeFill } from "./types";

function asRecord(value: unknown): Record<string, unknown> | null { return typeof value === "object" && value !== null ? value as Record<string, unknown> : null; }
function text(value: unknown) { return typeof value === "string" || typeof value === "number" ? String(value) : undefined; }
function number(value: unknown, fallback = 0) { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : fallback; }
function status(value: unknown): OrderStatus { const candidate = text(value); return candidate === "NEW" || candidate === "PARTIALLY_FILLED" || candidate === "FILLED" || candidate === "CANCELED" || candidate === "EXPIRED" || candidate === "REJECTED" ? candidate : "UNKNOWN"; }

export function decodeSpotUserEvent(input: string | unknown): DecodedUserEvent | null {
  let parsed: unknown = input;
  if (typeof input === "string") { try { parsed = JSON.parse(input); } catch { return null; } }
  const root = asRecord(parsed); const event = asRecord(root?.event) ?? root;
  if (!event) return null;
  const eventType = text(event.e) ?? "UNKNOWN"; const eventTime = number(event.E, Date.now());
  if (eventType === "executionReport") {
    const symbol = text(event.s) ?? ""; const orderId = text(event.i); const clientOrderId = text(event.c) ?? ""; const executedQty = text(event.z) ?? "0"; const lastQty = text(event.l) ?? "0";
    const order: NormalizedOrder = { marketType: "SPOT", symbol, orderId, clientOrderId, status: status(event.X), side: text(event.S) === "SELL" ? "SELL" : "BUY", type: text(event.o) as NormalizedOrder["type"], origQty: text(event.q), executedQty, avgPrice: Number(executedQty) > 0 ? (number(event.Z) / Number(executedQty)).toString() : undefined, price: text(event.p), stopPrice: text(event.P), updateTime: number(event.T, event.E as number), raw: event };
    const fill: TradeFill | undefined = Number(lastQty) > 0 ? { tradeId: text(event.t), orderId, clientOrderId, symbol, side: order.side, quantity: lastQty, price: text(event.L) ?? "0", commission: text(event.n), commissionAsset: text(event.N), eventTime } : undefined;
    return { marketType: "SPOT", eventType, eventTime, eventKey: `spot:execution:${text(event.I) ?? `${orderId}:${event.X}:${event.T}`}`, order, fill, raw: parsed };
  }
  if (eventType === "outboundAccountPosition") {
    const balances = Array.isArray(event.B) ? event.B.map((item) => { const balance = asRecord(item); return { asset: text(balance?.a) ?? "", free: text(balance?.f) ?? "0", locked: text(balance?.l) ?? "0" }; }).filter((item) => item.asset) : [];
    return { marketType: "SPOT", eventType, eventTime, eventKey: `spot:balance:${text(event.u) ?? eventTime}`, balances, raw: parsed };
  }
  if (eventType === "balanceUpdate") {
    const asset = text(event.a) ?? ""; return { marketType: "SPOT", eventType, eventTime, eventKey: `spot:balance-delta:${asset}:${text(event.T) ?? eventTime}`, balanceDeltas: asset ? [{ asset, delta: text(event.d) ?? "0", eventTime }] : [], raw: parsed };
  }
  return { marketType: "SPOT", eventType, eventTime, eventKey: `spot:event:${eventType}:${eventTime}:${text(event.I) ?? ""}`, raw: parsed };
}
