import type { SpotAdapter, UsdmFuturesAdapter, UserDataStream } from "../adapters";
import type { HardRiskGateway } from "../risk";
import { AccountLedger } from "./ledger";
import { decodeFuturesUserEvent } from "./futuresDecoder";
import { decodeSpotUserEvent } from "./spotDecoder";
import type { DecodedUserEvent, WebSocketFactory, WebSocketLike } from "./types";

export type StreamAdapter = SpotAdapter | UsdmFuturesAdapter;
export type StreamDecoder = (input: string | unknown) => DecodedUserEvent | null;

export class UserDataStreamSynchronizer {
  private socket: WebSocketLike | undefined;
  private stream: UserDataStream | undefined;
  private keepAliveTimer: ReturnType<typeof setInterval> | undefined;
  private reconnectTimer: ReturnType<typeof setTimeout> | undefined;
  private stopped = true;
  private reconnectAttempt = 0;

  constructor(
    private readonly adapter: StreamAdapter,
    readonly ledger: AccountLedger,
    private readonly gateway: HardRiskGateway,
    private readonly decoder: StreamDecoder,
    private readonly webSocketFactory?: WebSocketFactory,
  ) {}

  async start() {
    this.stopped = false;
    await this.syncSnapshot();
    this.stream = await this.adapter.createUserDataStream();
    this.startKeepAlive();
    if (this.webSocketFactory) this.connectSocket(this.stream.wsUrl);
    else this.gateway.markReady();
    return this.stream;
  }

  async syncSnapshot() {
    try {
      const snapshot = await this.adapter.getAccountSnapshot();
      this.ledger.hydrate(snapshot);
      this.gateway.markReady();
      return snapshot;
    } catch (error) {
      this.ledger.markReconciliationRequired("INITIAL_SNAPSHOT_FAILED");
      this.gateway.requireReconciliation("INITIAL_SNAPSHOT_FAILED");
      throw error;
    }
  }

  handleRawMessage(raw: string | ArrayBuffer) {
    const text = typeof raw === "string" ? raw : new TextDecoder().decode(raw);
    const event = this.decoder(text);
    if (!event) return { applied: false, reason: "INVALID_EVENT" };
    return this.applyEvent(event);
  }

  applyEvent(event: DecodedUserEvent) {
    const result = this.ledger.apply(event);
    if (event.riskSignal === "MARGIN_CALL") this.gateway.enterProtectiveOnly("FUTURES_MARGIN_CALL");
    if (event.riskSignal === "LISTEN_KEY_EXPIRED") this.gateway.requireReconciliation("USER_STREAM_EXPIRED");
    if (result.reconciliationRequired) this.gateway.requireReconciliation(result.reason ?? "LEDGER_RECONCILIATION_REQUIRED");
    return result;
  }

  async stop() {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
    this.socket?.close();
    if (this.stream) await this.adapter.closeUserDataStream(this.stream.listenKey).catch(() => undefined);
    this.socket = undefined; this.stream = undefined;
  }

  private startKeepAlive() {
    if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
    this.keepAliveTimer = setInterval(() => {
      if (this.stream) void this.adapter.keepAliveUserDataStream(this.stream.listenKey).catch(() => this.gateway.requireReconciliation("USER_STREAM_KEEPALIVE_FAILED"));
    }, 30 * 60 * 1000);
  }

  private connectSocket(url: string) {
    if (!this.webSocketFactory || this.stopped) return;
    const socket = this.webSocketFactory(url); this.socket = socket;
    socket.onopen = () => { this.reconnectAttempt = 0; this.gateway.markReady(); };
    socket.onmessage = (message) => { this.handleRawMessage(message.data); };
    socket.onerror = () => { this.gateway.requireReconciliation("USER_STREAM_SOCKET_ERROR"); };
    socket.onclose = () => { this.gateway.requireReconciliation("USER_STREAM_DISCONNECTED"); this.scheduleReconnect(); };
  }

  private scheduleReconnect() {
    if (this.stopped || this.reconnectTimer) return;
    const delay = Math.min(30_000, 1_000 * 2 ** this.reconnectAttempt++);
    this.reconnectTimer = setTimeout(() => { this.reconnectTimer = undefined; void this.reconnect(); }, delay);
  }

  private async reconnect() {
    if (this.stopped) return;
    try {
      await this.syncSnapshot();
      this.stream = await this.adapter.createUserDataStream();
      this.startKeepAlive();
      if (this.stream && this.webSocketFactory) this.connectSocket(this.stream.wsUrl);
    } catch { this.scheduleReconnect(); }
  }
}

export function createDefaultWebSocketFactory(): WebSocketFactory {
  return (url) => {
    const WebSocketConstructor = (globalThis as unknown as { WebSocket?: new (url: string) => WebSocketLike }).WebSocket;
    if (!WebSocketConstructor) throw new Error("WebSocket is unavailable; inject a WebSocketFactory in this runtime");
    return new WebSocketConstructor(url);
  };
}

export function decoderFor(marketType: "SPOT" | "USD_M_FUTURES"): StreamDecoder {
  return marketType === "SPOT" ? decodeSpotUserEvent : decodeFuturesUserEvent;
}
