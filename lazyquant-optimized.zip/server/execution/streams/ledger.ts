import type { AccountSnapshot, NormalizedOrder, PositionSnapshot } from "../adapters/types";
import type { DecodedUserEvent, LedgerApplyResult, LedgerSnapshot, TradeFill } from "./types";

export class AccountLedger {
  private readonly balances = new Map<string, { asset: string; free: string; locked: string; walletBalance?: string; availableBalance?: string }>();
  private readonly orders = new Map<string, NormalizedOrder>();
  private readonly fills = new Map<string, TradeFill>();
  private readonly positions = new Map<string, PositionSnapshot>();
  private readonly seenEventKeys = new Set<string>();
  private lastEventTime = 0;
  private lastSnapshotAt: number | undefined;
  private requiresReconciliation = false;
  private reconciliationReason: string | undefined;

  constructor(readonly marketType: "SPOT" | "USD_M_FUTURES", private readonly maxSeenEvents = 20_000) {}

  hydrate(snapshot: AccountSnapshot) {
    if (snapshot.marketType !== this.marketType) throw new Error("Ledger market type mismatch");
    this.balances.clear(); this.positions.clear();
    for (const balance of snapshot.balances) this.balances.set(balance.asset, { ...balance });
    for (const position of snapshot.positions) this.positions.set(this.positionKey(position), { ...position });
    this.lastSnapshotAt = snapshot.fetchedAt;
    this.requiresReconciliation = false;
    this.reconciliationReason = undefined;
    this.lastEventTime = 0;
  }

  apply(event: DecodedUserEvent): LedgerApplyResult {
    if (event.marketType !== this.marketType) return { applied: false, duplicate: false, outOfOrder: false, reconciliationRequired: true, reason: "MARKET_TYPE_MISMATCH" };
    if (this.seenEventKeys.has(event.eventKey)) return { applied: false, duplicate: true, outOfOrder: false, reconciliationRequired: this.requiresReconciliation, reason: "DUPLICATE_EVENT" };
    const outOfOrder = this.lastEventTime > 0 && event.eventTime + 1_000 < this.lastEventTime;
    this.remember(event.eventKey);
    if (outOfOrder) this.markReconciliationRequired("OUT_OF_ORDER_EVENT");
    this.lastEventTime = Math.max(this.lastEventTime, event.eventTime);
    if (event.balances) for (const balance of event.balances) this.balances.set(balance.asset, { ...balance });
    if (event.balanceDeltas) for (const delta of event.balanceDeltas) this.applyBalanceDelta(delta.asset, delta.delta);
    if (event.positions) for (const position of event.positions) this.positions.set(this.positionKey(position), { ...position });
    if (event.order) this.orders.set(this.orderKey(event.order), { ...event.order });
    if (event.fill) this.fills.set(this.fillKey(event.fill), { ...event.fill });
    if (event.riskSignal === "LISTEN_KEY_EXPIRED" || event.riskSignal === "RECONCILIATION_REQUIRED") this.markReconciliationRequired(event.riskSignal);
    if (event.riskSignal === "MARGIN_CALL") this.markReconciliationRequired("MARGIN_CALL");
    return { applied: true, duplicate: false, outOfOrder, reconciliationRequired: this.requiresReconciliation, reason: outOfOrder ? "OUT_OF_ORDER_EVENT" : undefined };
  }

  markReconciliationRequired(reason: string) { this.requiresReconciliation = true; this.reconciliationReason = reason; }
  clearReconciliationAfterSnapshot() { this.requiresReconciliation = false; this.reconciliationReason = undefined; }
  get needsReconciliation() { return this.requiresReconciliation; }
  get lastEventAt() { return this.lastEventTime; }
  get snapshotAt() { return this.lastSnapshotAt; }

  snapshot(): LedgerSnapshot {
    return { marketType: this.marketType, balances: [...this.balances.values()].map((balance) => ({ ...balance })), orders: [...this.orders.values()].map((order) => ({ ...order })), fills: [...this.fills.values()].map((fill) => ({ ...fill })), positions: [...this.positions.values()].map((position) => ({ ...position })), lastEventTime: this.lastEventTime, lastSnapshotAt: this.lastSnapshotAt, requiresReconciliation: this.requiresReconciliation, reconciliationReason: this.reconciliationReason };
  }

  private applyBalanceDelta(asset: string, delta: string) {
    const existing = this.balances.get(asset) ?? { asset, free: "0", locked: "0" };
    existing.free = (Number(existing.free) + Number(delta)).toString();
    this.balances.set(asset, existing);
  }

  private remember(key: string) {
    this.seenEventKeys.add(key);
    if (this.seenEventKeys.size > this.maxSeenEvents) this.seenEventKeys.delete(this.seenEventKeys.values().next().value as string);
  }
  private orderKey(order: NormalizedOrder) { return order.orderId ? `${this.marketType}:order:${order.orderId}` : `${this.marketType}:client:${order.clientOrderId}`; }
  private fillKey(fill: TradeFill) { return `${this.marketType}:fill:${fill.tradeId ?? `${fill.orderId}:${fill.eventTime}:${fill.quantity}:${fill.price}`}`; }
  private positionKey(position: PositionSnapshot) { return `${position.symbol}:${position.positionSide}`; }
}
