import type { AccountBalance, MarketType, NormalizedOrder, PositionSnapshot } from "../adapters/types";

export type TradeFill = {
  tradeId?: string;
  orderId?: string;
  clientOrderId?: string;
  symbol: string;
  side: "BUY" | "SELL";
  quantity: string;
  price: string;
  commission?: string;
  commissionAsset?: string;
  realizedPnl?: string;
  eventTime: number;
};

export type BalanceDelta = { asset: string; delta: string; eventTime: number };

export type DecodedUserEvent = {
  marketType: MarketType;
  eventType: string;
  eventTime: number;
  eventKey: string;
  order?: NormalizedOrder;
  fill?: TradeFill;
  balances?: AccountBalance[];
  balanceDeltas?: BalanceDelta[];
  positions?: PositionSnapshot[];
  riskSignal?: "MARGIN_CALL" | "LISTEN_KEY_EXPIRED" | "RECONCILIATION_REQUIRED";
  raw: unknown;
};

export type LedgerApplyResult = {
  applied: boolean;
  duplicate: boolean;
  outOfOrder: boolean;
  reconciliationRequired: boolean;
  reason?: string;
};

export type LedgerSnapshot = {
  marketType: MarketType;
  balances: AccountBalance[];
  orders: NormalizedOrder[];
  fills: TradeFill[];
  positions: PositionSnapshot[];
  lastEventTime: number;
  lastSnapshotAt?: number;
  requiresReconciliation: boolean;
  reconciliationReason?: string;
};

export type WebSocketLike = {
  onopen: (() => void) | null;
  onmessage: ((event: { data: string | ArrayBuffer }) => void) | null;
  onerror: ((event: unknown) => void) | null;
  onclose: ((event: unknown) => void) | null;
  close: () => void;
};

export type WebSocketFactory = (url: string) => WebSocketLike;
