import { describe, expect, it } from "vitest";
import { decodeFuturesUserEvent } from "./futuresDecoder";
import { decodeSpotUserEvent } from "./spotDecoder";
import { AccountLedger } from "./ledger";

describe("User Data Stream decoders and ledger", () => {
  it("decodes Spot executionReport and deduplicates it", () => {
    const event = { e: "executionReport", E: 100, s: "BTCUSDT", c: "spot-1", S: "BUY", o: "MARKET", X: "FILLED", q: "0.01", z: "0.01", Z: "100", p: "0", l: "0.01", L: "100", n: "0.01", N: "USDT", i: 10, I: 11, t: 12, T: 100 };
    const decoded = decodeSpotUserEvent(JSON.stringify(event));
    expect(decoded?.order).toMatchObject({ marketType: "SPOT", symbol: "BTCUSDT", status: "FILLED" });
    const ledger = new AccountLedger("SPOT");
    const first = ledger.apply(decoded!); const second = ledger.apply(decoded!);
    expect(first.applied).toBe(true); expect(second.duplicate).toBe(true); expect(ledger.snapshot().fills).toHaveLength(1);
  });

  it("decodes Futures order and account updates separately", () => {
    const order = decodeFuturesUserEvent({ e: "ORDER_TRADE_UPDATE", E: 200, o: { s: "BTCUSDT", c: "f-1", S: "SELL", o: "MARKET", X: "FILLED", x: "TRADE", q: "0.01", z: "0.01", ap: "100", l: "0.01", L: "100", i: 22, t: 33, T: 200, ps: "BOTH", R: true } });
    const account = decodeFuturesUserEvent({ e: "ACCOUNT_UPDATE", E: 201, T: 201, a: { m: "ORDER", B: [{ a: "USDT", wb: "1000", cw: "1000" }], P: [{ s: "BTCUSDT", pa: "0.01", ep: "100", up: "0", ps: "BOTH", mt: "cross", liq: "0" }] } });
    expect(order?.order).toMatchObject({ marketType: "USD_M_FUTURES", reduceOnly: true, status: "FILLED" });
    const ledger = new AccountLedger("USD_M_FUTURES"); ledger.apply(order!); ledger.apply(account!);
    expect(ledger.snapshot().positions[0]).toMatchObject({ symbol: "BTCUSDT", positionAmt: "0.01" });
  });

  it("marks out-of-order events for reconciliation", () => {
    const ledger = new AccountLedger("SPOT");
    const first = decodeSpotUserEvent({ e: "balanceUpdate", E: 10, a: "USDT", d: "1", T: 10 });
    const late = decodeSpotUserEvent({ e: "balanceUpdate", E: 1, a: "USDT", d: "1", T: 1 });
    ledger.apply(first!); const result = ledger.apply(late!);
    expect(result.outOfOrder).toBe(true); expect(ledger.needsReconciliation).toBe(true);
  });

  it("marks Futures margin call and listen key expiry as risk events", () => {
    expect(decodeFuturesUserEvent({ e: "MARGIN_CALL", E: 1 })?.riskSignal).toBe("MARGIN_CALL");
    expect(decodeFuturesUserEvent({ e: "listenKeyExpired", E: 2 })?.riskSignal).toBe("LISTEN_KEY_EXPIRED");
  });
});
