import { and, desc, eq } from "drizzle-orm";
import { binanceCredentials, type InsertBinanceCredential } from "../drizzle/schema";
import { getDb } from "./db";
import { encryptSecret } from "./security/apiKeyVault";

export async function saveBinanceCredential(input: { userId: number; label: string; apiKey: string; secret: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (!input.apiKey || !input.secret) throw new Error("Binance API Key and Secret are required");
  const apiKey = encryptSecret(input.apiKey.trim());
  const secret = encryptSecret(input.secret.trim());
  const row: InsertBinanceCredential = {
    userId: input.userId,
    label: input.label.trim().slice(0, 80) || "Binance Demo",
    apiKeyCiphertext: apiKey.ciphertext,
    apiKeyIv: apiKey.iv,
    apiKeyAuthTag: apiKey.authTag,
    secretCiphertext: secret.ciphertext,
    secretIv: secret.iv,
    secretAuthTag: secret.authTag,
    apiKeyLast4: input.apiKey.trim().slice(-4),
    permissions: "read_trade",
  };
  await db.insert(binanceCredentials).values(row);
  return { saved: true as const };
}

export async function listBinanceCredentials(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: binanceCredentials.id, label: binanceCredentials.label, apiKeyLast4: binanceCredentials.apiKeyLast4, permissions: binanceCredentials.permissions, createdAt: binanceCredentials.createdAt, updatedAt: binanceCredentials.updatedAt }).from(binanceCredentials).where(eq(binanceCredentials.userId, userId)).orderBy(desc(binanceCredentials.updatedAt));
}

export async function deleteBinanceCredential(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(binanceCredentials).where(and(eq(binanceCredentials.id, id), eq(binanceCredentials.userId, userId)));
  return { deleted: true as const };
}
