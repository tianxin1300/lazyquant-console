import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { deleteBinanceCredential, listBinanceCredentials, saveBinanceCredential } from "./binanceCredentials";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  binanceCredentials: router({
    list: protectedProcedure.query(({ ctx }) => listBinanceCredentials(ctx.user.id)),
    save: protectedProcedure.input(z.object({
      label: z.string().trim().min(1).max(80),
      apiKey: z.string().min(8).max(256),
      secret: z.string().min(8).max(256),
      confirmNoWithdraw: z.literal(true),
    })).mutation(({ ctx, input }) => saveBinanceCredential({ userId: ctx.user.id, ...input })),
    remove: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ ctx, input }) => deleteBinanceCredential(ctx.user.id, input.id)),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
