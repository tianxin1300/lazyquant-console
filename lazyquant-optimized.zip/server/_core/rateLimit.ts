import type { NextFunction, Request, Response } from "express";

/**
 * 轻量级进程内固定窗口限流（单实例够用；多实例部署请换成 Redis 等共享存储）。
 * 用于保护未登录即可访问、且会消耗外部额度的接口（Binance 公共行情、LLM）。
 */
export function rateLimit(options: { windowMs: number; max: number; name: string }) {
  const hits = new Map<string, { count: number; resetAt: number }>();
  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of hits) if (entry.resetAt <= now) hits.delete(key);
  }, options.windowMs);
  sweep.unref();

  return (req: Request, res: Response, next: NextFunction) => {
    const now = Date.now();
    const key = req.ip ?? "unknown";
    const entry = hits.get(key);
    if (!entry || entry.resetAt <= now) {
      hits.set(key, { count: 1, resetAt: now + options.windowMs });
      return next();
    }
    entry.count += 1;
    if (entry.count > options.max) {
      res.set("Retry-After", String(Math.ceil((entry.resetAt - now) / 1000)));
      return res.status(429).json({ error: `请求过于频繁（${options.name}），请稍后再试` });
    }
    next();
  };
}
