import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { invokeLLM } from "./llm";
import { KLINE_INTERVALS, KLINE_MAX_LIMIT, KLINE_SYMBOLS, MarketDataError, fetchClosedKlines } from "./marketData";
import { rateLimit } from "./rateLimit";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // 平台网关之后部署：信任一层代理，req.ip 才是真实客户端 IP（限流依赖它）
  app.set("trust proxy", 1);
  // 本应用没有经 JSON/表单上传大文件的接口（存储走 /manus-storage 代理），50mb 会放大被滥用的风险
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ limit: "1mb", extended: true }));
  const klineLimiter = rateLimit({ name: "K线", windowMs: 60_000, max: 60 });
  // QuantPilot 未登录即可调用并消耗 LLM 额度，限制更严
  const quantPilotLimiter = rateLimit({ name: "QuantPilot", windowMs: 60_000, max: 8 });
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/binance/klines", klineLimiter, async (req, res) => {
    const symbol = String(req.query.symbol ?? "BTCUSDT").toUpperCase();
    const interval = String(req.query.interval ?? "1h");
    const parsedLimit = Number(req.query.limit ?? 180);
    const limit = Number.isInteger(parsedLimit) ? Math.min(Math.max(parsedLimit, 50), KLINE_MAX_LIMIT) : 180;

    if (!KLINE_SYMBOLS.has(symbol) || !KLINE_INTERVALS.has(interval)) {
      return res.status(400).json({ error: "Unsupported Binance Spot symbol or interval" });
    }
    try {
      const candles = await fetchClosedKlines(symbol, interval, limit);
      res.set("Cache-Control", "no-store").json({ source: "binance-spot-public", symbol, interval, closedOnly: true, candles });
    } catch (error) {
      const status = error instanceof MarketDataError ? error.status : 502;
      res.status(status).json({ error: error instanceof MarketDataError ? error.message : "Binance Spot market data unavailable" });
    }
  });
  app.post("/api/quantpilot", quantPilotLimiter, async (req, res) => {
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.slice(0, 4000) : "";
    const context = typeof req.body?.context === "string" ? req.body.context.slice(0, 8000) : "";
    if (!prompt) return res.status(400).json({ error: "QuantPilot prompt is required" });
    try {
      const result = await invokeLLM({
        messages: [
          { role: "system", content: "你是 QuantPilot，一个只做研究的 Binance Spot 量化策略助手。只能生成结构化研究草案、信号条件、回测建议和风险检查。禁止要求或处理 API Key，禁止下单，禁止修改硬风控。请用简体中文回答，明确说明这是研究草案，需要样本外验证。" },
          { role: "user", content: `用户目标：${prompt}\n当前研究上下文：${context}` },
        ],
        maxTokens: 900,
      });
      const content = result.choices?.[0]?.message?.content;
      const text = typeof content === "string" ? content : "QuantPilot 未返回可读文本";
      res.set("Cache-Control", "no-store").json({ text });
    } catch {
      res.status(503).json({ error: "QuantPilot 当前不可用，请稍后重试" });
    }
  });
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
