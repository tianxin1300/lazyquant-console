import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const binanceCredentials = mysqlTable("binance_credentials", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  label: varchar("label", { length: 80 }).notNull(),
  apiKeyCiphertext: text("apiKeyCiphertext").notNull(),
  apiKeyIv: varchar("apiKeyIv", { length: 64 }).notNull(),
  apiKeyAuthTag: varchar("apiKeyAuthTag", { length: 64 }).notNull(),
  secretCiphertext: text("secretCiphertext").notNull(),
  secretIv: varchar("secretIv", { length: 64 }).notNull(),
  secretAuthTag: varchar("secretAuthTag", { length: 64 }).notNull(),
  apiKeyLast4: varchar("apiKeyLast4", { length: 4 }).notNull(),
  permissions: varchar("permissions", { length: 32 }).notNull().default("read_trade"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BinanceCredential = typeof binanceCredentials.$inferSelect;
export type InsertBinanceCredential = typeof binanceCredentials.$inferInsert;
