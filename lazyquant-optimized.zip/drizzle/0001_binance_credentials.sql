CREATE TABLE `binance_credentials` (
  `id` int AUTO_INCREMENT NOT NULL,
  `userId` int NOT NULL,
  `label` varchar(80) NOT NULL,
  `apiKeyCiphertext` text NOT NULL,
  `apiKeyIv` varchar(64) NOT NULL,
  `apiKeyAuthTag` varchar(64) NOT NULL,
  `secretCiphertext` text NOT NULL,
  `secretIv` varchar(64) NOT NULL,
  `secretAuthTag` varchar(64) NOT NULL,
  `apiKeyLast4` varchar(4) NOT NULL,
  `permissions` varchar(32) NOT NULL DEFAULT 'read_trade',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `binance_credentials_id` PRIMARY KEY(`id`)
);
