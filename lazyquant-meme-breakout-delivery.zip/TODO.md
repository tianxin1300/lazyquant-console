# LazyQuant 交付待办

## 控制室首页

- [ ] 首页必须明确显示 `Demo / Dry-run · 不会真实下单`。
- [ ] 首页展示模式、系统心跳、数据延迟、最后对账时间、账户权益、模拟盈亏、回撤和风险等级。
- [ ] 首页展示运行中的策略、模拟持仓、最近成交和最近预警。
- [ ] 首页提供紧急停止动作；触发后状态变为保护模式，阻止新的模拟开仓。

## 专业策略工作台

- [ ] 用户不需要编写代码即可创建或修改策略。
- [ ] 每个策略最多支持 10 个指标实例和 3 个时间周期。
- [ ] 支持 EMA、RSI、MACD、ATR、布林带、成交量均线等指标展示和条件配置。
- [ ] 支持 AND/OR 条件分组，并分别配置入场、出场、止损、止盈。
- [ ] 支持固定止损、固定止盈、ATR 动态止损、移动止盈和最大持仓时长。
- [ ] 策略卡必须展示资金上限、单笔金额、当前状态和版本。

## 风控、预警与退出

- [ ] 支持账户级和策略级资金上限、单日亏损、最大回撤、连续亏损和最大持仓限制。
- [ ] 支持 P0/P1/P2/P3 预警，并展示触发值、阈值、自动动作和人工确认状态。
- [ ] P0/P1 预警必须能暂停新开仓；P0 必须进入保护模式。
- [ ] 预警中心展示行情延迟、WebSocket 断连、REST 失败、订单超时、部分成交和对账差异规则。
- [ ] 退出规则展示优先级：紧急停止、保护性止损、策略止损、回撤保护、止盈、普通出场。
- [ ] 禁止提现、资金划转、杠杆、倍投、自动扩大仓位和真实下单入口。

## 仿真与审计

- [ ] 展示模拟权益曲线，并用事件标记显示成交和风险告警。
- [ ] 展示模拟订单、持仓、成交、手续费估计和滑点估计。
- [ ] 展示审计日志，包含策略版本、风险版本、信号、订单状态和停止原因。
- [ ] 展示 Dry-run 验收进度：连续运行时长、重复订单、状态差异、故障演练和未解决 P0/P1。
- [ ] 移动端窄屏可浏览和执行关键操作。

## Binance API Key 加密存储

- [ ] 交易所连接页面仅显示 Binance，不显示 OKX 或其他交易所入口。
- [ ] 用户可以在应用内输入 Binance API Key 和 Secret Key，并必须确认 Withdraw 权限已关闭。
- [ ] 服务端使用 AES-256-GCM 加密 API Key 和 Secret 后再写入数据库，前端不保存已提交的明文。
- [ ] 保存接口必须要求登录；列表接口只返回连接名称、末 4 位、权限摘要和时间戳。
- [ ] 删除接口只能删除当前用户自己的 Binance 凭证。
- [ ] `BINANCE_API_KEY_ENCRYPTION_KEY` 必须是服务端配置的 base64 32 字节密钥，未配置时禁止保存。
- [ ] 任何日志和审计事件不得包含 API Key、Secret 或加密明文。

## Phase 1 研究引擎：历史 K 线与指标群组

- [x] 增加“研究引擎”入口，明确显示 Binance Spot、历史数据研究模式，不提供下单按钮。
- [x] 通过服务端代理读取 Binance Spot 公共历史 K 线，支持白名单交易对、周期和数量上限；不使用 API Key。
- [x] 前端展示 OHLC K 线、成交量和数据时间范围，并明确按已收盘 K 线计算指标。
- [x] 指标群组 UI 支持启用/停用 KDJ、ATR、OBV、MACD，配置周期、参数和用途（过滤/入场/出场/风控）。
- [x] 指标计算结果可视化，至少展示 KDJ、ATR、OBV、MACD 子图或摘要数值。
- [x] 研究引擎的数据结构可被后续信号生成、回测和 QuantPilot 复用。

## Phase 1 第二批：信号、回测、优化与 QuantPilot

- [x] 指标组支持参数编辑，并加入 BOLL、带阈值 RSI、带阈值 EMA、StochRSI、WR、SUPER。
- [x] Binance K 线图支持 BOLL、EMA、SUPER 叠加及全部启用指标的研究子图。
- [x] 提供可增删、可编辑指标/操作符/阈值/入场出场方向的 AND 信号条件编辑器。
- [x] 提供含手续费假设的基础回测，展示收益、交易数、胜率、最大回撤和 Profit Factor。
- [x] 提供 RSI 阈值网格优化入口，并明确结果仍需样本外验证。
- [x] 提供 QuantPilot 策略助手，输出结构化研究草案，不拥有 API Key 或下单权限。

## 工程交付

- [ ] 提供 `public/manus-routes.json` 并与页面路由同步。
- [ ] 配置 TypeScript 诊断并通过 `pnpm check`。
- [ ] 通过 `pnpm build`。
- [ ] 开发服务在配置端口监听并能打开 Preview。
- [ ] 代码提交到项目的 canonical main checkpoint。

## Binance Spot / USDⓈ-M Futures 适配器

- [x] 提供显式分离的 Spot 与 USDⓈ-M Futures TypeScript 适配器接口；两者拥有独立 REST/WebSocket 基地址、凭证引用、交易规则、限速器、订单状态和账本类型。
- [x] Spot 适配器支持 exchangeInfo、账户快照、订单创建/查询/撤销和 Spot User Data Stream listen key 管理；不得接受 Futures 专用字段。
- [x] USDⓈ-M Futures 适配器支持 exchangeInfo、账户/仓位快照、订单创建/查询/撤销、杠杆读取/设置接口和 Futures User Data Stream listen key 管理；显式处理 positionSide、reduceOnly、closePosition 和 workingType。
- [x] 所有交易方法默认拒绝真实下单；只有明确的 demo/testnet/live 配置和显式 live 确认字符串同时满足时才允许发出交易请求。
- [x] 签名、API Key 和 Secret 仅在服务端适配器内存中使用，不能进入日志、错误消息或前端代码；请求超时、429、418、503 Unknown 必须映射为可判断的适配器错误。
- [x] 适配器构造函数不执行真实网络写操作；所有写操作必须由上层硬风控网关调用并记录 clientOrderId。

## 执行与回测分阶段实施

### Phase A：Hard Risk Gateway 核心

- [x] 定义代码级硬上限，运行时风险配置只能收紧，不能放宽。
- [x] 对 Spot/Futures 订单执行域匹配、意图类型、clientOrderId、信号 ID、K 线闭合、行情新鲜度、账户同步、对账状态、亏损、回撤、连续亏损、敞口、重复信号和未知订单拦截。
- [x] 支持 `READY`、`RUNNING`、`PROTECTIVE_ONLY`、`HALTED`、`RECONCILIATION_REQUIRED` 等状态，并让保护模式阻止新开仓、允许明确的减仓/平仓。
- [x] 通过 Spot/Futures 适配器执行唯一提交入口；适配器返回执行未知时自动转入对账状态并禁止重复提交。

### Phase B：实时 User Data Stream 与账户账本

- [ ] 解码 Spot `executionReport`、`outboundAccountPosition`、`balanceUpdate` 事件。
- [ ] 解码 Futures `ORDER_TRADE_UPDATE`、`ACCOUNT_UPDATE`、`ACCOUNT_CONFIG_UPDATE`、`MARGIN_CALL`、`listenKeyExpired` 事件。
- [ ] 建立按交易域隔离的账户、订单、成交、余额和仓位账本；支持事件去重、顺序检查、重连和快照对账。
- [ ] 账本不一致、事件过期或 listen key 失效时自动通知 Hard Risk Gateway 进入保护/对账状态。

### Phase C：样本外与 Walk-forward 回测

- [ ] 将历史数据按时间切分为训练、验证和样本外测试集，禁止使用未来数据优化当前窗口。
- [ ] 实现滚动训练窗口 → 参数选择 → 下一窗口样本外测试的 Walk-forward 执行器。
- [ ] 回测结果记录每个窗口的参数、交易成本、滑点、交易数量、收益、最大回撤和样本外表现。
- [ ] 明确区分样本内、样本外和 Walk-forward 汇总结果，不把样本内最优参数直接作为实盘配置。

## Meme 永续合约趋势突破回测

- [x] Python 回测引擎实现每日交易池、24h 成交额、上线年龄和 30 天资金费率中位数筛选。
- [x] 实现 15m 收盘突破、20 根高低点、2 倍成交量、已完成 1h EMA20/EMA60 和当前资金费率过滤。
- [x] 实现逐仓 3 倍杠杆上限、1% 单笔风险、ATR(14) 止损、1.5R 半仓止盈和 2×ATR 移动止损。
- [x] 将手续费、滑点和资金费率计入权益、交易日志、期望收益、最大回撤、盈亏比和 Profit Factor。
- [x] 实现日内权益回撤 3% 熔断：清理仓位、阻止当日新开仓，并覆盖合成数据单元测试。
- [x] 明确回测不连接真实交易所；正式结论仍需足够长历史、退市标的和样本外/Walk-forward 数据。
