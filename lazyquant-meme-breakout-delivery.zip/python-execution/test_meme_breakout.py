from __future__ import annotations

import unittest
from datetime import datetime, timedelta, timezone

from lazyquant_execution.meme_breakout import (
    Candle,
    FundingRate,
    MemeBreakoutBacktester,
    StrategyConfig,
    UniverseSnapshot,
)

UTC = timezone.utc
START = datetime(2026, 1, 1, tzinfo=UTC)


def make_candles(count: int = 300, breakout_index: int | None = 250, crash_after: bool = False) -> list[Candle]:
    candles: list[Candle] = []
    previous = 100.0
    for i in range(count):
        close = 100.0 + i * 0.01
        volume = 10.0
        if breakout_index == i:
            close = previous + 0.30
            volume = 30.0
        if crash_after and i > (breakout_index or 0) + 2:
            close = previous * 0.99
        open_price = previous
        high = max(open_price, close) + 0.02
        low = min(open_price, close) - 0.02
        candles.append(Candle(START + timedelta(minutes=15 * (i + 1)), open_price, high, low, close, volume))
        previous = close
    return candles


def make_hourly(count: int = 80) -> list[Candle]:
    candles: list[Candle] = []
    previous = 100.0
    for i in range(count):
        close = 100.0 + i * 0.20
        candles.append(Candle(START + timedelta(hours=i + 1), previous, close + 0.03, previous - 0.03, close, 1000.0))
        previous = close
    return candles


def make_universe(candles: list[Candle], turnover: float = 100_000_000.0) -> dict:
    days = {c.close_time.date() for c in candles}
    return {
        day: UniverseSnapshot(
            day=day,
            turnover_24h_usd=turnover,
            listed_at=START - timedelta(days=90),
            funding_rates_30d=(
                FundingRate(START - timedelta(days=2), 0.0001),
                FundingRate(START - timedelta(days=1), -0.0001),
                FundingRate(START, 0.0001),
            ),
        )
        for day in days
    }


class MemeBreakoutBacktestTests(unittest.TestCase):
    def test_long_breakout_includes_realistic_costs_and_partial_exit(self) -> None:
        candles = make_candles()
        funding = [
            FundingRate(START + timedelta(minutes=15 * 249), 0.0001),
            FundingRate(START + timedelta(minutes=15 * 253), 0.0005),
        ]
        engine = MemeBreakoutBacktester(
            candles_15m={"MEMEUSDT": candles},
            candles_1h={"MEMEUSDT": make_hourly()},
            universe={"MEMEUSDT": make_universe(candles)},
            funding_rates={"MEMEUSDT": funding},
            config=StrategyConfig(fee_rate=0.0004, slippage_bps=3.0),
        )
        result = engine.run()
        self.assertGreaterEqual(result.metrics["trade_count"], 1)
        self.assertGreater(result.metrics["total_fees"], 0)
        self.assertGreater(result.metrics["total_slippage_cost"], 0)
        self.assertGreater(result.metrics["total_funding_cost"], 0)
        self.assertIn(result.trades[0].exit_reason, {"INITIAL_STOP", "TRAILING_STOP", "END_OF_SAMPLE", "DAILY_CIRCUIT"})
        self.assertIn("max_drawdown_pct", result.metrics)
        self.assertIn("expectancy_per_trade", result.metrics)

    def test_low_turnover_universe_blocks_entries(self) -> None:
        candles = make_candles()
        engine = MemeBreakoutBacktester(
            candles_15m={"MEMEUSDT": candles},
            candles_1h={"MEMEUSDT": make_hourly()},
            universe={"MEMEUSDT": make_universe(candles, turnover=49_999_999.0)},
            funding_rates={"MEMEUSDT": [FundingRate(START, 0.0001)]},
        )
        result = engine.run()
        self.assertEqual(result.metrics["trade_count"], 0)
        self.assertTrue(any("没有完成交易" in warning for warning in result.warnings))

    def test_extreme_median_funding_excludes_symbol(self) -> None:
        candles = make_candles()
        universe = make_universe(candles)
        universe = {
            day: UniverseSnapshot(
                day=item.day,
                turnover_24h_usd=item.turnover_24h_usd,
                listed_at=item.listed_at,
                funding_rates_30d=(FundingRate(START - timedelta(days=2), 0.0007), FundingRate(START - timedelta(days=1), -0.0008), FundingRate(START, 0.0007)),
            )
            for day, item in universe.items()
        }
        engine = MemeBreakoutBacktester(
            candles_15m={"MEMEUSDT": candles},
            candles_1h={"MEMEUSDT": make_hourly()},
            universe={"MEMEUSDT": universe},
            funding_rates={"MEMEUSDT": [FundingRate(START, 0.0001)]},
        )
        result = engine.run()
        self.assertEqual(result.metrics["trade_count"], 0)


if __name__ == "__main__":
    unittest.main()
