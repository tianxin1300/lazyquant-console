# LazyQuant 独立执行服务与研究回测模块

该目录包含部署在独立海外服务器上的执行服务初始骨架，以及一个完全只读的 Meme 永续合约趋势突破回测模块。执行骨架只提供数据模型、Hard Risk Gateway 和编排边界，不包含真实交易网络写入；回测模块的所有成交都是假设成交，不会连接交易所、不签名、不下单。

## 执行服务边界

```text
Market Data Adapter
        |
        v
Closed Candle Buffer -> Strategy Runtime -> OrderIntent
                                             |
                                             v
                                    Hard Risk Gateway
                                      /           \
                             Spot Adapter     USD-M Futures Adapter
                                      \           /
                                       User Data Stream
                                              |
                                              v
                                     Domain Ledger / Reconciler
                                              |
                                              v
                                    Audit, Metrics, Alerts
```

策略进程只生成带 `strategy_id`、`strategy_version`、`signal_id` 和 `intent_type` 的订单意图。API key、secret、签名和交易所原始请求不能离开适配器边界。Hard Risk Gateway 是所有开仓、加仓、普通退出、保护性退出和紧急平仓的唯一入口，默认 fail-closed。

## Meme 永续合约回测

入口文件是 `lazyquant_execution/meme_breakout.py`，公共类型包括 `Candle`、`FundingRate`、`UniverseSnapshot`、`StrategyConfig` 和 `MemeBreakoutBacktester`。策略实现了以下规则：每日交易池快照、24h 成交额和上线年龄筛选、过去 30 天资金费率绝对值中位数排除、15m 20 根收盘突破、2 倍成交量确认、已完成 1h EMA20/EMA60 趋势过滤、当前资金费率门槛、ATR(14) 初始止损、按 1% 权益风险计算仓位、3 倍杠杆名义上限、+1.5R 半仓止盈、2×ATR 追踪止损和日内 3% 熔断。

所有信号都在 15m 收盘后生成，订单在下一根 15m K 线开盘价模拟成交。若同一根 K 线同时触及止损和止盈，回测采用止损优先的保守规则。手续费、滑点和资金费率分别记录；资金费率按持仓方向计入现金和交易成本。回测结果提供 `expectancy_per_trade`、`max_drawdown_pct`、`profit_factor`、`payoff_ratio`、胜率、总手续费、滑点和资金费率成本，不把胜率作为唯一目标。

最小调用形式如下，实际运行时应先把交易所导出的 15m/1h OHLCV、逐日交易池快照和资金费率事件解析为这些类型：

```python
from lazyquant_execution.meme_breakout import MemeBreakoutBacktester, StrategyConfig, result_to_dict

engine = MemeBreakoutBacktester(
    candles_15m={"MEMEUSDT": candles_15m},
    candles_1h={"MEMEUSDT": candles_1h},
    universe={"MEMEUSDT": daily_universe_snapshots},
    funding_rates={"MEMEUSDT": funding_events},
    config=StrategyConfig(
        fee_rate=0.0004,
        slippage_bps=3.0,
        max_median_abs_funding_rate=0.0005,
    ),
)
result = engine.run()
print(result_to_dict(result)["metrics"])
```

`test_meme_breakout.py` 提供无网络合成夹具，验证突破成交、下一根开盘执行、交易池淘汰、极端资金费率排除、手续费、滑点和资金费率成本。正式研究时仍需补充足够长的历史数据、退市/下架 Meme 币的 point-in-time 交易池、真实费率等级、盘口滑点和样本外/Walk-forward 报告。

## 服务器部署基线

第一阶段使用单独的服务账户、只读配置文件和受限出站网络。凭证放入外部 Secret 管理，不写入仓库或日志。服务启动顺序固定为：校时、加载交易规则、账户快照、未完成订单、持仓、账本恢复、User Data Stream，再进入 `READY`。任何对账差异、用户流过期、订单未知或时钟漂移都只能进入 `PROTECTIVE_ONLY` 或 `RECONCILIATION_REQUIRED`，不能自动恢复开仓。

## 上线顺序

1. Paper adapter 和回放数据验证。
2. Spot 与 USDⓈ-M Futures Demo/Testnet 分域联调。
3. 断网、429、503 Unknown、重复信号、部分成交和 listen key 过期演练。
4. 小额 canary 需要独立人工审批；Live 不是默认配置。

`risk_gateway.py` 是核心拦截逻辑；`models.py` 保持跨服务的最小订单意图和风险上下文；`engine.py` 只负责编排，不绕过网关。
