from lazyquant_execution import GatewayState, HardRiskGateway, IntentType, MarketType, OrderIntent, RiskContext, RiskRejected


def context(**overrides):
    data = dict(
        now_ms=1_000_000,
        market_data_at_ms=1_000_000,
        account_synced_at_ms=1_000_000,
        candle_closed=True,
        reconciliation_ok=True,
        server_time_offset_ms=0,
        state=GatewayState.RUNNING,
        daily_pnl=0,
        total_pnl=0,
        drawdown_pct=0,
        consecutive_losses=0,
        total_exposure=0,
        reference_price=100,
    )
    data.update(overrides)
    return RiskContext(**data)


def intent(client="order-1", signal="signal-1"):
    return OrderIntent(MarketType.SPOT, "BTCUSDT", "BUY", "MARKET", client, IntentType.OPEN, quantity=1, signal_id=signal, strategy_id="s1", strategy_version="v1")


def test_rejects_stale_data():
    gateway = HardRiskGateway(lambda _: object())
    gateway.mark_ready(); gateway.start()
    try:
        gateway.submit(intent(), context(market_data_at_ms=0))
    except RiskRejected as exc:
        assert "MARKET_DATA_STALE" in exc.decision.reasons
    else:
        raise AssertionError("expected rejection")


def test_deduplicates_signal():
    gateway = HardRiskGateway(lambda _: "ok")
    gateway.mark_ready(); gateway.start()
    assert gateway.submit(intent(), context()) == "ok"
    try:
        gateway.submit(intent(client="order-2"), context())
    except RiskRejected as exc:
        assert "DUPLICATE_SIGNAL" in exc.decision.reasons
    else:
        raise AssertionError("expected duplicate rejection")
