from __future__ import annotations

from collections.abc import Callable, Iterable


class ExecutionEngine:
    """海外服务器上的最小编排层：市场数据、策略、风险网关、适配器和账本均可替换。"""

    def __init__(self, *, market_data: Callable[[], Iterable[object]], signal_source: Callable[[object], object], gateway: object, ledger: object):
        self.market_data = market_data
        self.signal_source = signal_source
        self.gateway = gateway
        self.ledger = ledger

    def on_closed_candle(self, candle: object) -> object:
        signal = self.signal_source(candle)
        return signal

    def health(self) -> dict[str, str]:
        state = getattr(self.gateway, "state", "UNKNOWN")
        return {"service": "lazyquant-execution", "mode": "paper_or_testnet_only", "gateway_state": str(state)}
