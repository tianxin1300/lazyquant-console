from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Mapping


class MarketType(str, Enum):
    SPOT = "SPOT"
    USD_M_FUTURES = "USD_M_FUTURES"


class IntentType(str, Enum):
    OPEN = "OPEN"
    ADD = "ADD"
    CLOSE = "CLOSE"
    REDUCE = "REDUCE"
    EMERGENCY_CLOSE = "EMERGENCY_CLOSE"


class GatewayState(str, Enum):
    SYNCING = "SYNCING"
    READY = "READY"
    RUNNING = "RUNNING"
    PROTECTIVE_ONLY = "PROTECTIVE_ONLY"
    HALTED = "HALTED"
    RECONCILIATION_REQUIRED = "RECONCILIATION_REQUIRED"


@dataclass(frozen=True)
class OrderIntent:
    market_type: MarketType
    symbol: str
    side: str
    order_type: str
    client_order_id: str
    intent_type: IntentType
    quantity: float | None = None
    price: float | None = None
    signal_id: str | None = None
    strategy_id: str | None = None
    strategy_version: str | None = None
    created_at_ms: int | None = None
    reduce_only: bool = False
    close_position: bool = False


@dataclass(frozen=True)
class RiskLimits:
    max_single_entry_notional: float = 500.0
    max_total_exposure: float = 1000.0
    max_symbol_exposure: float = 500.0
    max_strategy_exposure: float = 500.0
    max_daily_loss: float = 50.0
    max_total_loss: float = 100.0
    max_drawdown_pct: float = 5.0
    max_consecutive_losses: int = 3
    max_market_data_staleness_ms: int = 5000
    max_account_sync_age_ms: int = 15000
    max_server_time_offset_ms: int = 1000
    max_order_age_ms: int = 5000


@dataclass(frozen=True)
class RiskContext:
    now_ms: int
    market_data_at_ms: int
    account_synced_at_ms: int
    candle_closed: bool
    reconciliation_ok: bool
    server_time_offset_ms: int
    state: GatewayState
    daily_pnl: float
    total_pnl: float
    drawdown_pct: float
    consecutive_losses: int
    total_exposure: float
    exposure_by_symbol: Mapping[str, float] = field(default_factory=dict)
    exposure_by_strategy: Mapping[str, float] = field(default_factory=dict)
    pending_unknown_order: bool = False
    reference_price: float | None = None


@dataclass(frozen=True)
class RiskDecision:
    allowed: bool
    action: str
    reasons: tuple[str, ...]
    checked_at_ms: int
    market_type: MarketType
    symbol: str
    intent_type: IntentType
    notional: float | None


class RiskRejected(Exception):
    def __init__(self, decision: RiskDecision):
        super().__init__(f"Hard Risk Gateway rejected {decision.symbol}: {', '.join(decision.reasons)}")
        self.decision = decision
