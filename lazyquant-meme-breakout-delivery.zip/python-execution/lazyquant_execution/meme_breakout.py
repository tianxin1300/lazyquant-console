from __future__ import annotations

"""Meme 永续合约趋势突破策略的纯 Python、只读回测引擎。

本模块不连接交易所、不签名、不下单。所有成交都是假设成交，结果必须结合
输入数据清单、成本假设和样本外测试解释。
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from statistics import median
from typing import Iterable, Mapping, Sequence


UTC = timezone.utc


def _utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


@dataclass(frozen=True)
class Candle:
    close_time: datetime
    open_price: float
    high: float
    low: float
    close: float
    volume: float

    def __post_init__(self) -> None:
        if self.open_price <= 0 or self.high <= 0 or self.low <= 0 or self.close <= 0:
            raise ValueError("candle prices must be positive")
        if self.high < max(self.open_price, self.close) or self.low > min(self.open_price, self.close):
            raise ValueError("candle high/low do not contain open/close")
        if self.volume < 0:
            raise ValueError("candle volume cannot be negative")


@dataclass(frozen=True)
class FundingRate:
    timestamp: datetime
    rate: float  # decimal, e.g. 0.0005 means +0.05% per funding event


@dataclass(frozen=True)
class UniverseSnapshot:
    day: date
    turnover_24h_usd: float
    listed_at: datetime
    funding_rates_30d: tuple[FundingRate, ...]

    def eligible(
        self,
        *,
        as_of: datetime,
        min_turnover_usd: float,
        min_listing_age_days: int,
        max_median_abs_funding_rate: float,
    ) -> bool:
        as_of = _utc(as_of)
        listed_at = _utc(self.listed_at)
        if self.turnover_24h_usd <= min_turnover_usd:
            return False
        if as_of - listed_at < timedelta(days=min_listing_age_days):
            return False
        rates = [abs(rate.rate) for rate in self.funding_rates_30d if _utc(rate.timestamp) <= as_of]
        if not rates:
            return False
        return median(rates) <= max_median_abs_funding_rate


@dataclass(frozen=True)
class StrategyConfig:
    initial_capital: float = 10_000.0
    breakout_lookback: int = 20
    volume_multiplier: float = 2.0
    atr_period: int = 14
    initial_stop_atr: float = 1.5
    trailing_stop_atr: float = 2.0
    take_profit_r: float = 1.5
    partial_exit_fraction: float = 0.5
    risk_per_trade: float = 0.01
    max_leverage: float = 3.0
    daily_circuit_drawdown: float = 0.03
    fee_rate: float = 0.0004
    slippage_bps: float = 3.0
    estimated_funding_reserve_per_8h: float = 0.0002
    min_turnover_usd: float = 50_000_000.0
    min_listing_age_days: int = 30
    max_median_abs_funding_rate: float = 0.0005
    ema_fast: int = 20
    ema_slow: int = 60

    def __post_init__(self) -> None:
        if self.initial_capital <= 0:
            raise ValueError("initial_capital must be positive")
        if not 0 < self.risk_per_trade <= 1:
            raise ValueError("risk_per_trade must be in (0, 1]")
        if not 0 < self.max_leverage <= 3:
            raise ValueError("max_leverage must be in (0, 3]")
        if not 0 < self.partial_exit_fraction < 1:
            raise ValueError("partial_exit_fraction must be in (0, 1)")
        if self.fee_rate < 0 or self.slippage_bps < 0 or self.estimated_funding_reserve_per_8h < 0:
            raise ValueError("cost assumptions cannot be negative")


@dataclass(frozen=True)
class Fill:
    timestamp: datetime
    side: str
    quantity: float
    raw_price: float
    fill_price: float
    reason: str
    fee: float
    slippage_cost: float
    funding_cost_to_date: float = 0.0


@dataclass
class Position:
    symbol: str
    side: int  # +1 long, -1 short
    quantity: float
    entry_time: datetime
    entry_price: float
    initial_stop: float
    stop_price: float
    initial_r: float
    highest: float
    lowest: float
    atr: float
    partial_taken: bool = False
    realized_pnl: float = 0.0
    fees: float = 0.0
    slippage_cost: float = 0.0
    funding_cost: float = 0.0
    fills: list[Fill] = field(default_factory=list)
    last_funding_time: datetime | None = None


@dataclass(frozen=True)
class CompletedTrade:
    symbol: str
    side: str
    entry_time: datetime
    exit_time: datetime
    quantity: float
    gross_pnl: float
    net_pnl: float
    fees: float
    slippage_cost: float
    funding_cost: float
    exit_reason: str


@dataclass(frozen=True)
class BacktestResult:
    config: StrategyConfig
    final_equity: float
    total_return_pct: float
    max_drawdown_pct: float
    trades: tuple[CompletedTrade, ...]
    equity_curve: tuple[tuple[datetime, float], ...]
    fills: tuple[Fill, ...]
    metrics: Mapping[str, float]
    warnings: tuple[str, ...]


class MemeBreakoutBacktester:
    """多标的、15m 触发 + 1h 趋势过滤的永续合约历史回测器。"""

    def __init__(
        self,
        *,
        candles_15m: Mapping[str, Sequence[Candle]],
        candles_1h: Mapping[str, Sequence[Candle]],
        universe: Mapping[str, Mapping[date, UniverseSnapshot]],
        funding_rates: Mapping[str, Sequence[FundingRate]] | None = None,
        config: StrategyConfig | None = None,
    ) -> None:
        self.candles_15m = {symbol: tuple(sorted(items, key=lambda c: _utc(c.close_time))) for symbol, items in candles_15m.items()}
        self.candles_1h = {symbol: tuple(sorted(items, key=lambda c: _utc(c.close_time))) for symbol, items in candles_1h.items()}
        self.universe = universe
        self.funding_rates = {symbol: tuple(sorted(items, key=lambda x: _utc(x.timestamp))) for symbol, items in (funding_rates or {}).items()}
        self.config = config or StrategyConfig()
        self._validate_inputs()

    def _validate_inputs(self) -> None:
        if not self.candles_15m:
            raise ValueError("candles_15m cannot be empty")
        for symbol, candles in self.candles_15m.items():
            if len(candles) < self.config.breakout_lookback + self.config.atr_period + 1:
                raise ValueError(f"{symbol}: not enough 15m candles for warm-up")
            if symbol not in self.candles_1h:
                raise ValueError(f"{symbol}: missing 1h candles")
            if any(_utc(a.close_time) >= _utc(b.close_time) for a, b in zip(candles, candles[1:])):
                raise ValueError(f"{symbol}: 15m candles must be strictly ordered")

    @staticmethod
    def _ema(values: Sequence[float], period: int) -> list[float | None]:
        out: list[float | None] = [None] * len(values)
        if len(values) < period:
            return out
        value = sum(values[:period]) / period
        out[period - 1] = value
        alpha = 2 / (period + 1)
        for i in range(period, len(values)):
            value = alpha * values[i] + (1 - alpha) * value
            out[i] = value
        return out

    @staticmethod
    def _atr(candles: Sequence[Candle], period: int) -> list[float | None]:
        tr: list[float] = []
        previous_close: float | None = None
        for candle in candles:
            if previous_close is None:
                tr.append(candle.high - candle.low)
            else:
                tr.append(max(candle.high - candle.low, abs(candle.high - previous_close), abs(candle.low - previous_close)))
            previous_close = candle.close
        out: list[float | None] = [None] * len(candles)
        if len(tr) >= period:
            value = sum(tr[:period]) / period
            out[period - 1] = value
            for i in range(period, len(tr)):
                value = ((value * (period - 1)) + tr[i]) / period
                out[i] = value
        return out

    def _trend_at(self, symbol: str, timestamp: datetime, ema_fast: Sequence[float | None], ema_slow: Sequence[float | None]) -> int:
        candles = self.candles_1h[symbol]
        idx = -1
        for i, candle in enumerate(candles):
            if _utc(candle.close_time) <= _utc(timestamp):
                idx = i
            else:
                break
        if idx < 0 or ema_fast[idx] is None or ema_slow[idx] is None:
            return 0
        if ema_fast[idx] > ema_slow[idx]:
            return 1
        if ema_fast[idx] < ema_slow[idx]:
            return -1
        return 0

    def _funding_at(self, symbol: str, timestamp: datetime) -> float | None:
        candidates = [item.rate for item in self.funding_rates.get(symbol, ()) if _utc(item.timestamp) <= _utc(timestamp)]
        return candidates[-1] if candidates else None

    def run(self) -> BacktestResult:
        cfg = self.config
        cash = cfg.initial_capital
        positions: dict[str, Position] = {}
        pending: dict[str, tuple[datetime, int, float]] = {}
        last_exit_candle: dict[str, datetime] = {}
        daily_blocked: set[date] = set()
        latest_prices: dict[str, float] = {}
        equity_curve: list[tuple[datetime, float]] = []
        fills: list[Fill] = []
        trades: list[CompletedTrade] = []
        warnings: list[str] = []
        state = {symbol: {"atr": self._atr(items, cfg.atr_period)} for symbol, items in self.candles_15m.items()}
        trend = {
            symbol: (
                self._ema([item.close for item in self.candles_1h[symbol]], cfg.ema_fast),
                self._ema([item.close for item in self.candles_1h[symbol]], cfg.ema_slow),
            )
            for symbol in self.candles_1h
        }
        events = sorted(
            ((symbol, index, candle) for symbol, candles in self.candles_15m.items() for index, candle in enumerate(candles)),
            key=lambda item: (_utc(item[2].close_time), item[0]),
        )
        current_day: date | None = None
        day_start_equity = cfg.initial_capital
        total_funding = 0.0
        total_fees = 0.0
        total_slippage = 0.0
        last_event_time: datetime | None = None

        for symbol, index, candle in events:
            timestamp = _utc(candle.close_time)
            current_date = timestamp.date()
            latest_prices[symbol] = candle.close
            if current_day != current_date:
                current_day = current_date
                day_start_equity = self._equity(cash, positions, latest_prices)

            if symbol in positions:
                total_funding += self._apply_funding(positions[symbol], timestamp, latest_prices[symbol])

            position = positions.get(symbol)
            if position:
                before_fill_count = len(position.fills)
                cash, closed_trade, fee, slip = self._manage_position(
                    cash=cash,
                    position=position,
                    candle=candle,
                    atr=state[symbol]["atr"][index],
                    timestamp=timestamp,
                )
                total_fees += fee
                total_slippage += slip
                fills.extend(position.fills[before_fill_count:])
                if closed_trade:
                    trades.append(closed_trade)
                    last_exit_candle[symbol] = timestamp
                    positions.pop(symbol, None)
                    position = None

            equity = self._equity(cash, positions, latest_prices)
            if equity <= day_start_equity * (1 - cfg.daily_circuit_drawdown) and current_date not in daily_blocked:
                daily_blocked.add(current_date)
                for close_symbol in list(positions):
                    close_position = positions[close_symbol]
                    mark = latest_prices.get(close_symbol, close_position.entry_price)
                    before_fill_count = len(close_position.fills)
                    cash, closed_trade, fee, slip = self._close_position(
                        cash, close_position, mark, timestamp, "DAILY_CIRCUIT"
                    )
                    total_fees += fee
                    total_slippage += slip
                    fills.extend(close_position.fills[before_fill_count:])
                    if closed_trade:
                        trades.append(closed_trade)
                    positions.pop(close_symbol, None)
                equity = cash

            if not positions.get(symbol) and symbol not in pending and current_date not in daily_blocked:
                signal = self._signal(symbol, index, candle, trend[symbol], state[symbol]["atr"])
                if signal and last_exit_candle.get(symbol) != timestamp:
                    pending[symbol] = (timestamp, signal, float(state[symbol]["atr"][index]))

            # Pending orders generated on the previous completed candle fill at this candle's open.
            if symbol in pending:
                signal_time, side, atr = pending[symbol]
                if _utc(signal_time) < timestamp and symbol not in positions and current_date not in daily_blocked:
                    pending.pop(symbol, None)
                    entry_price = candle.open_price * (1 + side * cfg.slippage_bps / 10_000)
                    stop_distance = cfg.initial_stop_atr * atr
                    estimated_cost = entry_price * (2 * (cfg.fee_rate + cfg.slippage_bps / 10_000) + cfg.estimated_funding_reserve_per_8h)
                    risk_budget = equity * cfg.risk_per_trade
                    quantity_by_risk = risk_budget / max(stop_distance + estimated_cost, 1e-12)
                    quantity_by_leverage = cfg.max_leverage * equity / entry_price
                    quantity = min(quantity_by_risk, quantity_by_leverage)
                    if quantity > 0:
                        fee = entry_price * quantity * cfg.fee_rate
                        slip = abs(entry_price - candle.open_price) * quantity
                        stop = entry_price - side * stop_distance
                        position = Position(
                            symbol=symbol,
                            side=side,
                            quantity=quantity,
                            entry_time=timestamp,
                            entry_price=entry_price,
                            initial_stop=stop,
                            stop_price=stop,
                            initial_r=stop_distance,
                            highest=candle.high,
                            lowest=candle.low,
                            atr=atr,
                            fees=fee,
                            slippage_cost=slip,
                            last_funding_time=timestamp,
                        )
                        entry_fill = Fill(timestamp, "BUY" if side == 1 else "SELL", quantity, candle.open_price, entry_price, "ENTRY", fee, slip)
                        position.fills.append(entry_fill)
                        fills.append(entry_fill)
                        cash -= fee
                        total_fees += fee
                        total_slippage += slip
                        positions[symbol] = position

            equity_curve.append((timestamp, self._equity(cash, positions, latest_prices)))
            last_event_time = timestamp

        # Conservative end-of-sample liquidation at the last observed close.
        if positions and last_event_time:
            for symbol in list(positions):
                position = positions[symbol]
                before_fill_count = len(position.fills)
                cash, closed_trade, fee, slip = self._close_position(cash, position, latest_prices[symbol], last_event_time, "END_OF_SAMPLE")
                total_fees += fee
                total_slippage += slip
                fills.extend(position.fills[before_fill_count:])
                if closed_trade:
                    trades.append(closed_trade)
                positions.pop(symbol, None)
            equity_curve.append((last_event_time, cash))

        if not equity_curve:
            raise ValueError("no events to backtest")
        final_equity = equity_curve[-1][1]
        max_drawdown = self._max_drawdown(equity_curve)
        net_returns = [trade.net_pnl for trade in trades]
        wins = [value for value in net_returns if value > 0]
        losses = [value for value in net_returns if value < 0]
        profit_factor = sum(wins) / abs(sum(losses)) if losses else (float("inf") if wins else 0.0)
        payoff_ratio = (sum(wins) / len(wins)) / abs(sum(losses) / len(losses)) if wins and losses else 0.0
        metrics = {
            "total_return_pct": (final_equity / cfg.initial_capital - 1) * 100,
            "max_drawdown_pct": max_drawdown,
            "trade_count": float(len(trades)),
            "win_rate_pct": (len(wins) / len(trades) * 100) if trades else 0.0,
            "profit_factor": profit_factor,
            "payoff_ratio": payoff_ratio,
            "expectancy_per_trade": (sum(net_returns) / len(net_returns)) if net_returns else 0.0,
            "total_fees": total_fees,
            "total_slippage_cost": total_slippage,
            "total_funding_cost": total_funding,
            "daily_circuit_days": float(len(daily_blocked)),
        }
        if len(events) < 10_000:
            warnings.append("样本少于 10,000 根 15m K 线，统计结论应视为初步结果。")
        if not trades:
            warnings.append("没有完成交易；请检查交易池快照、1h 趋势数据和 warm-up 长度。")
        warnings.append("本引擎按输入的存活标的运行；若要研究退市 Meme 币，必须提供 point-in-time 标的清单，避免幸存者偏差。")
        return BacktestResult(cfg, final_equity, metrics["total_return_pct"], max_drawdown, tuple(trades), tuple(equity_curve), tuple(fills), metrics, tuple(warnings))

    def _signal(self, symbol: str, index: int, candle: Candle, trend_data: tuple[Sequence[float | None], Sequence[float | None]], atr: Sequence[float | None]) -> int | None:
        cfg = self.config
        if index < cfg.breakout_lookback or atr[index] is None:
            return None
        snapshot = self.universe.get(symbol, {}).get(_utc(candle.close_time).date())
        if snapshot is None or not snapshot.eligible(
            as_of=candle.close_time,
            min_turnover_usd=cfg.min_turnover_usd,
            min_listing_age_days=cfg.min_listing_age_days,
            max_median_abs_funding_rate=cfg.max_median_abs_funding_rate,
        ):
            return None
        previous = self.candles_15m[symbol][index - cfg.breakout_lookback:index]
        average_volume = sum(item.volume for item in previous) / len(previous)
        funding = self._funding_at(symbol, candle.close_time)
        trend_side = self._trend_at(symbol, candle.close_time, *trend_data)
        if funding is None or candle.volume <= average_volume * cfg.volume_multiplier:
            return None
        if candle.close > max(item.high for item in previous) and trend_side == 1 and funding <= 0.001:
            return 1
        if candle.close < min(item.low for item in previous) and trend_side == -1 and funding >= -0.001:
            return -1
        return None

    def _apply_funding(self, position: Position, timestamp: datetime, mark: float) -> float:
        if position.last_funding_time is None:
            position.last_funding_time = timestamp
        total = 0.0
        for item in self.funding_rates.get(position.symbol, ()):
            item_time = _utc(item.timestamp)
            if position.last_funding_time < item_time <= timestamp:
                payment = position.side * mark * position.quantity * item.rate
                position.funding_cost += payment
                position.last_funding_time = item_time
                total += payment
        return total

    def _manage_position(self, *, cash: float, position: Position, candle: Candle, atr: float | None, timestamp: datetime) -> tuple[float, CompletedTrade | None, float, float]:
        if atr is not None:
            position.atr = atr
        stop_hit = candle.low <= position.stop_price if position.side == 1 else candle.high >= position.stop_price
        take_profit = position.entry_price + position.side * position.initial_r * self.config.take_profit_r
        tp_hit = candle.high >= take_profit if position.side == 1 else candle.low <= take_profit
        # Conservative tie-break: if stop and TP are both touched in one bar, stop fires first.
        if stop_hit:
            return self._close_position(cash, position, position.stop_price, timestamp, "INITIAL_STOP" if not position.partial_taken else "TRAILING_STOP")
        if tp_hit and not position.partial_taken:
            quantity = position.quantity * self.config.partial_exit_fraction
            cash, fee, slip = self._partial_close(cash, position, quantity, take_profit, timestamp, "TAKE_PROFIT_1_5R")
            position.partial_taken = True
            breakeven = position.entry_price + position.side * (position.entry_price * (self.config.fee_rate + self.config.slippage_bps / 10_000) + position.entry_price * self.config.fee_rate)
            position.stop_price = max(position.stop_price, breakeven) if position.side == 1 else min(position.stop_price, breakeven)
            return cash, None, fee, slip
        position.highest = max(position.highest, candle.high)
        position.lowest = min(position.lowest, candle.low)
        if position.partial_taken and atr is not None:
            candidate = position.highest - self.config.trailing_stop_atr * atr if position.side == 1 else position.lowest + self.config.trailing_stop_atr * atr
            position.stop_price = max(position.stop_price, candidate) if position.side == 1 else min(position.stop_price, candidate)
        return cash, None, 0.0, 0.0

    def _partial_close(self, cash: float, position: Position, quantity: float, raw_price: float, timestamp: datetime, reason: str) -> tuple[float, float, float]:
        fill_price = raw_price * (1 - position.side * self.config.slippage_bps / 10_000)
        fee = fill_price * quantity * self.config.fee_rate
        slip = abs(fill_price - raw_price) * quantity
        pnl = (fill_price - position.entry_price) * quantity * position.side
        position.realized_pnl += pnl
        position.fees += fee
        position.slippage_cost += slip
        position.quantity -= quantity
        position.fills.append(Fill(timestamp, "SELL" if position.side == 1 else "BUY", quantity, raw_price, fill_price, reason, fee, slip))
        cash += pnl - fee
        return cash, fee, slip

    def _close_position(self, cash: float, position: Position, raw_price: float, timestamp: datetime, reason: str) -> tuple[float, CompletedTrade | None, float, float]:
        quantity = position.quantity
        if quantity <= 0:
            return cash, None, 0.0, 0.0
        fill_price = raw_price * (1 - position.side * self.config.slippage_bps / 10_000)
        fee = fill_price * quantity * self.config.fee_rate
        slip = abs(fill_price - raw_price) * quantity
        gross = position.realized_pnl + (fill_price - position.entry_price) * quantity * position.side
        cash += (fill_price - position.entry_price) * quantity * position.side - fee
        position.fees += fee
        position.slippage_cost += slip
        position.fills.append(Fill(timestamp, "SELL" if position.side == 1 else "BUY", quantity, raw_price, fill_price, reason, fee, slip))
        trade = CompletedTrade(
            position.symbol,
            "LONG" if position.side == 1 else "SHORT",
            position.entry_time,
            timestamp,
            sum(fill.quantity for fill in position.fills if fill.reason == "ENTRY"),
            gross,
            gross - position.fees - position.funding_cost,
            position.fees,
            position.slippage_cost,
            position.funding_cost,
            reason,
        )
        return cash, trade, fee, slip

    @staticmethod
    def _equity(cash: float, positions: Mapping[str, Position], latest_prices: Mapping[str, float]) -> float:
        return cash + sum((latest_prices[symbol] - position.entry_price) * position.quantity * position.side for symbol, position in positions.items())

    @staticmethod
    def _max_drawdown(curve: Sequence[tuple[datetime, float]]) -> float:
        peak = curve[0][1]
        maximum = 0.0
        for _, equity in curve:
            peak = max(peak, equity)
            if peak > 0:
                maximum = max(maximum, (peak - equity) / peak * 100)
        return maximum


def result_to_dict(result: BacktestResult) -> dict[str, object]:
    """把结果转成 JSON 友好结构，便于保存报告和前端展示。"""
    return {
        "metrics": dict(result.metrics),
        "warnings": list(result.warnings),
        "final_equity": result.final_equity,
        "total_return_pct": result.total_return_pct,
        "max_drawdown_pct": result.max_drawdown_pct,
        "trades": [
            {
                "symbol": item.symbol,
                "side": item.side,
                "entry_time": _utc(item.entry_time).isoformat(),
                "exit_time": _utc(item.exit_time).isoformat(),
                "quantity": item.quantity,
                "gross_pnl": item.gross_pnl,
                "net_pnl": item.net_pnl,
                "fees": item.fees,
                "slippage_cost": item.slippage_cost,
                "funding_cost": item.funding_cost,
                "exit_reason": item.exit_reason,
            }
            for item in result.trades
        ],
    }
