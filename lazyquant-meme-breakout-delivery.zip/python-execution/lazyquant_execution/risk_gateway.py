from __future__ import annotations

import re
from collections.abc import Callable

from .models import GatewayState, IntentType, MarketType, OrderIntent, RiskContext, RiskDecision, RiskLimits, RiskRejected


_CLIENT_ORDER_ID = re.compile(r"^[.A-Za-z0-9:/_-]{1,36}$")


class HardRiskGateway:
    """独立执行服务的 fail-closed 网关；该模块不包含交易所网络调用。"""

    def __init__(self, submitter: Callable[[OrderIntent], object], limits: RiskLimits | None = None, audit: Callable[[dict], None] | None = None):
        self._submitter = submitter
        self._limits = limits or RiskLimits()
        self._audit = audit or (lambda _event: None)
        self._state = GatewayState.SYNCING
        self._used_signals: set[str] = set()

    @property
    def state(self) -> GatewayState:
        return self._state

    def mark_ready(self) -> None:
        self._state = GatewayState.READY

    def start(self) -> None:
        if self._state not in {GatewayState.READY, GatewayState.PROTECTIVE_ONLY}:
            raise RuntimeError(f"cannot start gateway from {self._state}")
        self._state = GatewayState.RUNNING

    def enter_protective_only(self, reason: str) -> None:
        self._state = GatewayState.PROTECTIVE_ONLY
        self._audit({"event": "gateway_state_changed", "state": self._state.value, "reason": reason})

    def require_reconciliation(self, reason: str) -> None:
        self._state = GatewayState.RECONCILIATION_REQUIRED
        self._audit({"event": "gateway_state_changed", "state": self._state.value, "reason": reason})

    def evaluate(self, intent: OrderIntent, context: RiskContext) -> RiskDecision:
        reasons: list[str] = []
        is_opening = intent.intent_type in {IntentType.OPEN, IntentType.ADD}
        is_emergency = intent.intent_type is IntentType.EMERGENCY_CLOSE
        notional = self._notional(intent, context.reference_price)

        if intent.market_type not in {MarketType.SPOT, MarketType.USD_M_FUTURES}:
            reasons.append("MARKET_DOMAIN_MISMATCH")
        if not _CLIENT_ORDER_ID.fullmatch(intent.client_order_id):
            reasons.append("INVALID_CLIENT_ORDER_ID")
        if is_opening and not intent.signal_id:
            reasons.append("OPENING_SIGNAL_ID_REQUIRED")
        if is_opening and context.pending_unknown_order:
            reasons.append("PENDING_UNKNOWN_ORDER")
        if is_opening and not context.candle_closed:
            reasons.append("CANDLE_NOT_CLOSED")
        if abs(context.server_time_offset_ms) > self._limits.max_server_time_offset_ms:
            reasons.append("SERVER_TIME_OFFSET_TOO_LARGE")
        if context.now_ms - context.market_data_at_ms > self._limits.max_market_data_staleness_ms and not is_emergency:
            reasons.append("MARKET_DATA_STALE")
        if context.now_ms - context.account_synced_at_ms > self._limits.max_account_sync_age_ms and not is_emergency:
            reasons.append("ACCOUNT_SYNC_STALE")
        if not context.reconciliation_ok and not is_emergency:
            reasons.append("RECONCILIATION_NOT_CONFIRMED")
        if context.state in {GatewayState.HALTED, GatewayState.RECONCILIATION_REQUIRED} and not is_emergency:
            reasons.append(f"GATEWAY_STATE_{context.state.value}")
        if self._state in {GatewayState.HALTED, GatewayState.RECONCILIATION_REQUIRED} and not is_emergency:
            reasons.append(f"LOCAL_GATEWAY_STATE_{self._state.value}")
        if is_opening and (context.state is GatewayState.PROTECTIVE_ONLY or self._state is GatewayState.PROTECTIVE_ONLY):
            reasons.append("PROTECTIVE_ONLY_BLOCKS_OPENING")
        if is_opening and context.daily_pnl <= -self._limits.max_daily_loss:
            reasons.append("MAX_DAILY_LOSS")
        if is_opening and context.total_pnl <= -self._limits.max_total_loss:
            reasons.append("MAX_TOTAL_LOSS")
        if is_opening and context.drawdown_pct >= self._limits.max_drawdown_pct:
            reasons.append("MAX_DRAWDOWN")
        if is_opening and context.consecutive_losses >= self._limits.max_consecutive_losses:
            reasons.append("MAX_CONSECUTIVE_LOSSES")
        if is_opening and notional is not None and notional > self._limits.max_single_entry_notional:
            reasons.append("MAX_SINGLE_ENTRY_NOTIONAL")
        if is_opening and notional is not None and context.total_exposure + notional > self._limits.max_total_exposure:
            reasons.append("MAX_TOTAL_EXPOSURE")
        if is_opening and notional is not None and context.exposure_by_symbol.get(intent.symbol, 0) + notional > self._limits.max_symbol_exposure:
            reasons.append("MAX_SYMBOL_EXPOSURE")
        if is_opening and notional is not None and intent.strategy_id and context.exposure_by_strategy.get(intent.strategy_id, 0) + notional > self._limits.max_strategy_exposure:
            reasons.append("MAX_STRATEGY_EXPOSURE")
        if intent.created_at_ms is not None and context.now_ms - intent.created_at_ms > self._limits.max_order_age_ms and not is_emergency:
            reasons.append("ORDER_INTENT_STALE")

        signal_key = self._signal_key(intent)
        if is_opening and signal_key in self._used_signals:
            reasons.append("DUPLICATE_SIGNAL")
        if intent.market_type is MarketType.USD_M_FUTURES and intent.close_position and intent.quantity is not None:
            reasons.append("CLOSE_POSITION_CANNOT_INCLUDE_QUANTITY")
        if intent.market_type is MarketType.SPOT and (intent.reduce_only or intent.close_position):
            reasons.append("SPOT_REJECTS_FUTURES_FIELDS")

        emergency_allowed_reasons = {"CANDLE_NOT_CLOSED", "MARKET_DATA_STALE", "ACCOUNT_SYNC_STALE", "RECONCILIATION_NOT_CONFIRMED"}
        allowed = not reasons or (is_emergency and set(reasons).issubset(emergency_allowed_reasons))
        action = "ALLOW" if allowed else ("HALT" if is_emergency else ("REJECT" if is_opening else "PROTECTIVE_ONLY"))
        decision = RiskDecision(allowed, action, tuple(reasons), context.now_ms, intent.market_type, intent.symbol, intent.intent_type, notional)
        self._audit({"event": "risk_decision", "allowed": allowed, "action": action, "reasons": reasons, "symbol": intent.symbol, "client_order_id": intent.client_order_id})
        return decision

    def submit(self, intent: OrderIntent, context: RiskContext) -> object:
        decision = self.evaluate(intent, context)
        if not decision.allowed:
            raise RiskRejected(decision)
        key = self._signal_key(intent)
        if key:
            self._used_signals.add(key)
        try:
            result = self._submitter(intent)
        except Exception as exc:
            self.require_reconciliation("ORDER_EXECUTION_UNKNOWN")
            self._audit({"event": "order_unknown", "symbol": intent.symbol, "error_type": type(exc).__name__})
            raise
        self._audit({"event": "order_submitted", "symbol": intent.symbol, "client_order_id": intent.client_order_id})
        return result

    @staticmethod
    def _notional(intent: OrderIntent, reference_price: float | None) -> float | None:
        if intent.quantity is None:
            return None
        price = intent.price or reference_price
        if price is None or price <= 0 or intent.quantity <= 0:
            return None
        return price * intent.quantity

    @staticmethod
    def _signal_key(intent: OrderIntent) -> str | None:
        if not intent.signal_id or not intent.strategy_version:
            return None
        return "|".join((intent.market_type.value, intent.symbol, intent.strategy_id or "unknown", intent.strategy_version, intent.signal_id, intent.intent_type.value))
