import type { Candle } from "../../client/src/lib/indicators";
import { calculateBtcUsdtContractIndicators, type BtcUsdtContractParams } from "../../client/src/lib/indicators";
import { evaluateBtcUsdtContractSignal } from "../../client/src/lib/signalEngine";
import type { FuturesOrderIntent, NormalizedOrder } from "./adapters/types";
import { HardRiskGateway } from "./risk/hardRiskGateway";
import type { RiskContext } from "./risk/types";

export type SignalExecutionLoopOptions = {
  strategyId: string;
  strategyVersion: string;
  symbol: string;
  quantity: string;
  params?: BtcUsdtContractParams;
  onAudit?: (event: { type: "signal" | "submitted" | "rejected"; signalId: string; reason?: string; order?: NormalizedOrder }) => void;
};

/**
 * 只接收已收盘 K 线。循环本身不保存 API key，也不直接调用交易所；所有订单都经过 HardRiskGateway。
 * 默认以 Futures ONE-WAY/BOTH 订单意图表达多空开平，调用者仍需显式提供风险上下文。
 */
export class BtcUsdtSignalExecutionLoop {
  private readonly indicators = new Map<string, ReturnType<typeof calculateBtcUsdtContractIndicators>>();
  private position: "LONG" | "SHORT" | "FLAT" = "FLAT";
  private entryPrice: number | undefined;

  constructor(private readonly gateway: HardRiskGateway, private readonly options: SignalExecutionLoopOptions) {}

  get positionState() { return this.position; }

  async onClosedCandle(candles: Candle[], index: number, context: RiskContext): Promise<NormalizedOrder | undefined> {
    const candle = candles[index];
    if (!candle || candle.closeTime >= (context.now ?? Date.now())) return undefined;
    let indicators = this.indicators.get(this.options.symbol);
    if (!indicators || index === 0) {
      indicators = calculateBtcUsdtContractIndicators(candles, this.options.params);
      this.indicators.set(this.options.symbol, indicators);
    }
    const signalId = `${this.options.strategyId}:${candle.closeTime}`;
    const signal = evaluateBtcUsdtContractSignal(indicators, candles, index, this.entryPrice, this.options.params);
    this.options.onAudit?.({ type: "signal", signalId, reason: signal.reason.join("；") });

    const intent = this.toIntent(signalId, candle.closeTime, signal);
    if (!intent) return undefined;
    try {
      const order = await this.gateway.submit(intent, context);
      if (intent.intentType === "OPEN") {
        this.position = intent.side === "BUY" ? "LONG" : "SHORT";
        this.entryPrice = candle.close;
      } else if (intent.intentType === "CLOSE" || intent.intentType === "EMERGENCY_CLOSE") {
        this.position = "FLAT";
        this.entryPrice = undefined;
      }
      this.options.onAudit?.({ type: "submitted", signalId, order });
      return order;
    } catch (error) {
      this.options.onAudit?.({ type: "rejected", signalId, reason: error instanceof Error ? error.message : "ORDER_REJECTED" });
      throw error;
    }
  }

  private toIntent(signalId: string, candleCloseTime: number, signal: ReturnType<typeof evaluateBtcUsdtContractSignal>): FuturesOrderIntent | undefined {
    if (this.position === "FLAT" && signal.enterLong) return this.baseIntent(signalId, candleCloseTime, "BUY", "OPEN");
    if (this.position === "FLAT" && signal.enterShort) return this.baseIntent(signalId, candleCloseTime, "SELL", "OPEN");
    if (this.position === "LONG" && signal.exitLong) return this.baseIntent(signalId, candleCloseTime, "SELL", "CLOSE");
    if (this.position === "SHORT" && signal.exitShort) return this.baseIntent(signalId, candleCloseTime, "BUY", "CLOSE");
    return undefined;
  }

  private baseIntent(signalId: string, candleCloseTime: number, side: "BUY" | "SELL", intentType: "OPEN" | "CLOSE"): FuturesOrderIntent {
    return {
      marketType: "USD_M_FUTURES",
      symbol: this.options.symbol,
      side,
      type: "MARKET",
      quantity: this.options.quantity,
      positionSide: "BOTH",
      reduceOnly: intentType === "CLOSE",
      clientOrderId: `${this.options.strategyId}-${candleCloseTime}`.slice(0, 36),
      signalId,
      strategyId: this.options.strategyId,
      strategyVersion: this.options.strategyVersion,
      intentType,
      createdAt: candleCloseTime,
    };
  }
}
