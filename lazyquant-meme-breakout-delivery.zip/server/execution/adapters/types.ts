export type MarketType = "SPOT" | "USD_M_FUTURES";
export type ExecutionMode = "paper" | "demo" | "testnet" | "live";
export type OrderSide = "BUY" | "SELL";
export type OrderType = "MARKET" | "LIMIT" | "STOP" | "STOP_MARKET" | "TAKE_PROFIT" | "TAKE_PROFIT_MARKET";
export type OrderStatus = "NEW" | "PARTIALLY_FILLED" | "FILLED" | "CANCELED" | "EXPIRED" | "REJECTED" | "UNKNOWN";
export type PositionSide = "BOTH" | "LONG" | "SHORT";
export type WorkingType = "MARK_PRICE" | "CONTRACT_PRICE";
export type IntentType = "OPEN" | "ADD" | "CLOSE" | "REDUCE" | "EMERGENCY_CLOSE";

export type AdapterConfig = {
  apiKey?: string;
  apiSecret?: string;
  mode: ExecutionMode;
  baseUrl?: string;
  wsBaseUrl?: string;
  timeoutMs?: number;
  recvWindowMs?: number;
  requestWeightLimitPerMinute?: number;
  allowLiveTrading?: boolean;
  liveConfirmation?: string;
};

export type OrderIntentBase = {
  symbol: string;
  side: OrderSide;
  type: OrderType;
  quantity?: string;
  price?: string;
  stopPrice?: string;
  timeInForce?: "GTC" | "IOC" | "FOK" | "GTX" | "GTD";
  clientOrderId: string;
  signalId?: string;
  strategyId?: string;
  strategyVersion?: string;
  intentType?: IntentType;
  createdAt?: number;
};

export type SpotOrderIntent = OrderIntentBase & {
  marketType: "SPOT";
  quoteOrderQty?: string;
  newOrderRespType?: "ACK" | "RESULT" | "FULL";
};

export type FuturesOrderIntent = OrderIntentBase & {
  marketType: "USD_M_FUTURES";
  positionSide?: PositionSide;
  reduceOnly?: boolean;
  closePosition?: boolean;
  workingType?: WorkingType;
  priceProtect?: boolean;
  newOrderRespType?: "ACK" | "RESULT";
};

export type AccountBalance = {
  asset: string;
  free: string;
  locked: string;
  walletBalance?: string;
  availableBalance?: string;
};

export type PositionSnapshot = {
  symbol: string;
  positionAmt: string;
  positionSide: PositionSide;
  entryPrice: string;
  markPrice?: string;
  unrealizedPnl?: string;
  liquidationPrice?: string;
  leverage?: string;
  marginType?: "isolated" | "cross";
};

export type AccountSnapshot = {
  marketType: MarketType;
  fetchedAt: number;
  balances: AccountBalance[];
  positions: PositionSnapshot[];
  canTrade: boolean;
  raw: unknown;
};

export type NormalizedOrder = {
  marketType: MarketType;
  symbol: string;
  orderId?: string;
  clientOrderId: string;
  status: OrderStatus;
  side: OrderSide;
  type: OrderType;
  positionSide?: PositionSide;
  reduceOnly?: boolean;
  closePosition?: boolean;
  origQty?: string;
  executedQty?: string;
  avgPrice?: string;
  price?: string;
  stopPrice?: string;
  updateTime?: number;
  raw: unknown;
};

export type UserDataStream = {
  marketType: MarketType;
  listenKey: string;
  wsUrl: string;
  expiresAt: number;
};

export interface SpotAdapter {
  readonly marketType: "SPOT";
  readonly mode: ExecutionMode;
  getExchangeInfo(symbol?: string): Promise<unknown>;
  getAccountSnapshot(): Promise<AccountSnapshot>;
  createOrder(intent: SpotOrderIntent): Promise<NormalizedOrder>;
  queryOrder(symbol: string, orderId?: string, clientOrderId?: string): Promise<NormalizedOrder>;
  cancelOrder(symbol: string, orderId?: string, clientOrderId?: string): Promise<NormalizedOrder>;
  createUserDataStream(): Promise<UserDataStream>;
  keepAliveUserDataStream(listenKey: string): Promise<void>;
  closeUserDataStream(listenKey: string): Promise<void>;
}

export interface UsdmFuturesAdapter {
  readonly marketType: "USD_M_FUTURES";
  readonly mode: ExecutionMode;
  getExchangeInfo(symbol?: string): Promise<unknown>;
  getAccountSnapshot(): Promise<AccountSnapshot>;
  getPositionRisk(symbol?: string): Promise<PositionSnapshot[]>;
  getLeverage(symbol: string): Promise<number | undefined>;
  createOrder(intent: FuturesOrderIntent): Promise<NormalizedOrder>;
  queryOrder(symbol: string, orderId?: string, clientOrderId?: string): Promise<NormalizedOrder>;
  cancelOrder(symbol: string, orderId?: string, clientOrderId?: string): Promise<NormalizedOrder>;
  setLeverage(symbol: string, leverage: number): Promise<{ symbol: string; leverage: number; maxNotionalValue?: string; raw: unknown }>;
  createUserDataStream(): Promise<UserDataStream>;
  keepAliveUserDataStream(listenKey: string): Promise<void>;
  closeUserDataStream(listenKey: string): Promise<void>;
}

export class AdapterConfigurationError extends Error {
  readonly code = "ADAPTER_CONFIGURATION_ERROR";
}

export class AdapterRequestError extends Error {
  constructor(
    message: string,
    readonly code: string,
    readonly status?: number,
    readonly retryable = false,
    readonly executionUnknown = false,
  ) {
    super(message);
    this.name = "AdapterRequestError";
  }
}
