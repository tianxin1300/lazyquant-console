export const KLINE_SYMBOLS = new Set(["BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT"]);
export const KLINE_INTERVALS = new Set(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"]);
export const KLINE_MAX_LIMIT = 1000;

export type Kline = { openTime: number; closeTime: number; open: number; high: number; low: number; close: number; volume: number };

export class MarketDataError extends Error {
  constructor(message: string, readonly status: number) { super(message); this.name = "MarketDataError"; }
}

const CACHE_TTL_MS = 5_000;
const cache = new Map<string, { at: number; candles: Kline[] }>();
const inflight = new Map<string, Promise<Kline[]>>();

/**
 * 读取 Binance Spot 公共 K 线，并且只返回【已收盘】蜡烛。
 * Binance 的 klines 最后一根通常是仍在形成中的蜡烛；原实现原样返回，违背了"只用已收盘 K 线"的安全约束，
 * 会让指标/回测在未定型的价格上给出信号。这里多取 1 根并按 closeTime 过滤。
 * 另外做 5 秒缓存 + 并发请求合并，避免多用户/连续点击把服务器 IP 打到 Binance 的权重限制（429/418）。
 */
export async function fetchClosedKlines(symbol: string, interval: string, limit: number): Promise<Kline[]> {
  const key = `${symbol}|${interval}|${limit}`;
  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.candles;
  const pending = inflight.get(key);
  if (pending) return pending;

  const task = (async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8_000);
    try {
      const query = `symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit + 1}`;
      let payload: unknown;
      let lastError: unknown;
      for (const baseUrl of ["https://api.binance.com/api/v3/klines", "https://data-api.binance.vision/api/v3/klines"]) {
        try {
          const upstream = await fetch(`${baseUrl}?${query}`, { signal: controller.signal, headers: { accept: "application/json" } });
          if (!upstream.ok) { lastError = new Error(`HTTP ${upstream.status}`); continue; }
          payload = await upstream.json() as unknown;
          break;
        } catch (error) {
          lastError = error;
        }
      }
      if (payload === undefined) throw new MarketDataError(lastError instanceof Error ? `Binance Spot market data unavailable: ${lastError.message}` : "Binance Spot market data unavailable", 502);
      if (!Array.isArray(payload)) throw new MarketDataError("Invalid Binance Spot market data response", 502);
      const now = Date.now();
      const candles: Kline[] = [];
      for (const row of payload) {
        if (!Array.isArray(row) || row.length < 7) throw new MarketDataError("Invalid Binance Spot kline row", 502);
        const candle = { openTime: Number(row[0]), open: Number(row[1]), high: Number(row[2]), low: Number(row[3]), close: Number(row[4]), volume: Number(row[5]), closeTime: Number(row[6]) };
        if (Object.values(candle).some((value) => !Number.isFinite(value))) throw new MarketDataError("Invalid Binance Spot kline value", 502);
        if (candle.closeTime < now) candles.push(candle);
      }
      const result = candles.slice(-limit);
      cache.set(key, { at: Date.now(), candles: result });
      return result;
    } catch (error) {
      if (error instanceof MarketDataError) throw error;
      throw new MarketDataError(error instanceof Error && error.name === "AbortError" ? "Binance Spot request timed out" : "Binance Spot market data unavailable", 502);
    } finally {
      clearTimeout(timeout);
      inflight.delete(key);
    }
  })();
  inflight.set(key, task);
  return task;
}
