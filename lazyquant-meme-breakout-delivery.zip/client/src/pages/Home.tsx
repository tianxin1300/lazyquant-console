import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BellRing,
  Bot,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleGauge,
  ClipboardList,
  Clock3,
  DatabaseBackup,
  Eye,
  Filter,
  Gauge,
  History,
  KeyRound,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  RefreshCcw,
  Search,
  ServerCog,
  Settings2,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  Square,
  TerminalSquare,
  TrendingDown,
  TrendingUp,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import ResearchPage from "@/pages/ResearchPage";
import { compareThreeStageSamples, walkForwardThreeStage, type ThreeStageBacktestResult, type ThreeStageSampleComparison, type WalkForwardResult } from "@/lib/strategyBacktest";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type View = "overview" | "research" | "strategies" | "risk" | "orders" | "logs" | "accounts";
type StrategyStatus = "运行中" | "已暂停" | "保护模式";
type Severity = "P0" | "P1" | "P2" | "P3";

const equityData = [
  { time: "09:00", value: 100000 },
  { time: "10:00", value: 100240 },
  { time: "11:00", value: 100180 },
  { time: "12:00", value: 100520 },
  { time: "13:00", value: 100440 },
  { time: "14:00", value: 100760 },
  { time: "15:00", value: 100610 },
  { time: "16:00", value: 100920 },
  { time: "17:00", value: 100840 },
  { time: "18:00", value: 101180 },
  { time: "19:00", value: 101060 },
  { time: "20:00", value: 101420 },
];

const strategySeed = [
  {
    id: "trend-01",
    name: "趋势跟随 · BTC",
    template: "EMA + RSI 趋势",
    status: "运行中" as StrategyStatus,
    exchange: "Binance Demo",
    pair: "BTC/USDT",
    timeframe: "15m / 1h / 4h",
    indicators: 7,
    risk: "单策略 15%",
    pnl: "+1.42%",
    pnlPositive: true,
    version: "v1.4",
  },
  {
    id: "btc-contract-1m-01",
    name: "三段式趋势 · BTC/USDT",
    template: "KDJ + StochRSI + MACD + ATR",
    status: "已暂停" as StrategyStatus,
    exchange: "Binance USDT-M Futures",
    pair: "BTC/USDT",
    timeframe: "1m",
    indicators: 6,
    risk: "ATR 动态止损 2×",
    pnl: "—",
    pnlPositive: true,
    version: "v1.0",
  },
  {
    id: "grid-02",
    name: "区间网格 · ETH",
    template: "布林带 + ATR 网格",
    status: "运行中" as StrategyStatus,
    exchange: "Binance Demo",
    pair: "ETH/USDT",
    timeframe: "15m / 1h",
    indicators: 5,
    risk: "单策略 10%",
    pnl: "+0.68%",
    pnlPositive: true,
    version: "v0.9",
  },
  {
    id: "mean-03",
    name: "均值回归 · SOL",
    template: "RSI + VWAP 回归",
    status: "保护模式" as StrategyStatus,
    exchange: "Binance Demo",
    pair: "SOL/USDT",
    timeframe: "5m / 1h",
    indicators: 8,
    risk: "P1 已暂停开仓",
    pnl: "-0.34%",
    pnlPositive: false,
    version: "v2.1",
  },
];

const alerts: Array<{
  level: Severity;
  title: string;
  detail: string;
  time: string;
  action: string;
  acknowledged?: boolean;
}> = [
  {
    level: "P1",
    title: "策略回撤接近保护阈值",
    detail: "均值回归 · SOL 当前回撤 5.8%，已停止新开仓",
    time: "20:00:42",
    action: "已暂停策略",
  },
  {
    level: "P2",
    title: "Binance 行情延迟升高",
    detail: "ETH/USDT 延迟 18 秒，低于 P1 停止线 60 秒",
    time: "19:56:18",
    action: "持续监控",
  },
  {
    level: "P3",
    title: "订单重试成功",
    detail: "Binance Demo · BTC/USDT REST 请求第 2 次重试成功",
    time: "19:47:06",
    action: "已恢复",
    acknowledged: true,
  },
];

const orders = [
  { id: "DRY-84021", pair: "BTC/USDT", side: "买入", amount: "0.012 BTC", price: "$67,420", state: "模拟成交", time: "19:42:11", strategy: "趋势跟随" },
  { id: "DRY-84020", pair: "ETH/USDT", side: "卖出", amount: "0.28 ETH", price: "$3,842", state: "模拟成交", time: "19:18:44", strategy: "区间网格" },
  { id: "DRY-84019", pair: "SOL/USDT", side: "卖出", amount: "4.2 SOL", price: "$176.40", state: "已取消", time: "18:55:07", strategy: "均值回归" },
  { id: "DRY-84018", pair: "BTC/USDT", side: "买入", amount: "0.010 BTC", price: "$67,080", state: "模拟成交", time: "18:14:29", strategy: "趋势跟随" },
];

const auditLogs = [
  ["20:00:42", "P1", "风控", "均值回归 · SOL 进入保护模式，停止新开仓"],
  ["19:56:18", "P2", "连接", "Binance ETH/USDT 行情延迟达到 18 秒"],
  ["19:42:11", "INFO", "订单", "趋势跟随 · BTC 触发 EMA20 上穿 EMA60，模拟买入"],
  ["19:18:44", "INFO", "订单", "区间网格 · ETH 触及上轨，模拟卖出并记录手续费"],
  ["18:55:07", "P2", "退出", "均值回归 · SOL 触发 ATR 动态止损，撤销未成交挂单"],
];

const navItems: Array<{ id: View; label: string; icon: typeof CircleGauge; badge?: string }> = [
  { id: "overview", label: "控制室", icon: CircleGauge },
  { id: "research", label: "研究引擎", icon: Activity, badge: "Phase 1" },
  { id: "strategies", label: "策略工作台", icon: SlidersHorizontal, badge: "3" },
  { id: "risk", label: "风控与预警", icon: ShieldAlert, badge: "2" },
  { id: "orders", label: "订单与持仓", icon: ClipboardList },
  { id: "logs", label: "审计日志", icon: History },
  { id: "accounts", label: "交易所连接", icon: KeyRound },
];

function cn(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function StatusDot({ status }: { status: StrategyStatus }) {
  return <span className={cn("status-dot", status === "运行中" ? "status-dot--live" : status === "保护模式" ? "status-dot--danger" : "status-dot--muted")} />;
}

function SeverityBadge({ level }: { level: Severity | "INFO" }) {
  const tone = level === "P0" ? "severity-p0" : level === "P1" ? "severity-p1" : level === "P2" ? "severity-p2" : level === "P3" ? "severity-p3" : "severity-info";
  return <span className={cn("severity-badge", tone)}>{level}</span>;
}

function MetricCard({ label, value, meta, icon: Icon, tone = "teal", trend }: { label: string; value: string; meta: string; icon: typeof Activity; tone?: string; trend?: "up" | "down" }) {
  return (
    <div className="metric-card">
      <div className="metric-card__top">
        <span className="eyebrow">{label}</span>
        <span className={cn("metric-icon", `metric-icon--${tone}`)}><Icon size={17} /></span>
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-meta">
        {trend === "up" ? <ArrowUpRight size={14} className="text-teal" /> : trend === "down" ? <ArrowDownRight size={14} className="text-red" /> : null}
        <span>{meta}</span>
      </div>
    </div>
  );
}

function SectionHeader({ eyebrow, title, action, onAction }: { eyebrow?: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h2>{title}</h2>
      </div>
      {action && <button className="text-action" onClick={onAction}>{action}<ChevronRight size={15} /></button>}
    </div>
  );
}

function RiskGauge() {
  return (
    <div className="risk-gauge">
      <div className="risk-gauge__header">
        <div>
          <span className="eyebrow">账户风险</span>
          <div className="risk-gauge__value">P2 <span>可控</span></div>
        </div>
        <span className="risk-gauge__score">回撤 2.8%</span>
      </div>
      <div className="risk-scale"><span className="risk-scale__marker" style={{ left: "28%" }} /></div>
      <div className="risk-scale__labels"><span>正常</span><span>P2 · 5%</span><span>P1 · 8%</span><span>P0 · 10%</span></div>
      <p className="muted-copy">当前距离 P2 策略回撤阈值仍有 2.2 个百分点。系统持续监控所有策略与连接。</p>
    </div>
  );
}

function AlertRow({ alert }: { alert: (typeof alerts)[number] }) {
  return (
    <div className={cn("alert-row", alert.level === "P1" && "alert-row--hot")}>
      <SeverityBadge level={alert.level} />
      <div className="alert-row__body">
        <div className="alert-row__title">{alert.title}</div>
        <div className="alert-row__detail">{alert.detail}</div>
      </div>
      <div className="alert-row__right"><span>{alert.action}</span><time>{alert.time}</time></div>
    </div>
  );
}

function StrategyRow({ strategy, onToggle }: { strategy: (typeof strategySeed)[number]; onToggle: (id: string) => void }) {
  const isRunning = strategy.status === "运行中";
  return (
    <div className="strategy-row">
      <div className="strategy-row__main">
        <div className="strategy-mark"><Bot size={17} /></div>
        <div>
          <div className="strategy-name"><StatusDot status={strategy.status} />{strategy.name}</div>
          <div className="strategy-sub">{strategy.template} <span>·</span> {strategy.version}</div>
        </div>
      </div>
      <div className="strategy-cell"><strong>{strategy.exchange}</strong><span>{strategy.pair}</span></div>
      <div className="strategy-cell"><strong>{strategy.indicators} 个指标</strong><span>{strategy.timeframe}</span></div>
      <div className="strategy-cell"><strong className={strategy.pnlPositive ? "text-teal" : "text-red"}>{strategy.pnl}</strong><span>{strategy.risk}</span></div>
      <div className="strategy-actions">
        {strategy.status === "保护模式" ? <span className="protected-chip"><ShieldAlert size={13} /> 已保护</span> : <button className={cn("icon-button", isRunning && "icon-button--active")} onClick={() => onToggle(strategy.id)} aria-label={isRunning ? "暂停策略" : "启动策略"}>{isRunning ? <Pause size={15} /> : <Play size={15} />}</button>}
        <button className="icon-button" aria-label="更多操作"><MoreHorizontal size={16} /></button>
      </div>
    </div>
  );
}

function Overview({ strategies, onToggle, onNavigate }: { strategies: typeof strategySeed; onToggle: (id: string) => void; onNavigate: (view: View) => void }) {
  return (
    <>
      <div className="hero-row">
        <div>
          <span className="eyebrow eyebrow--teal">实时控制室 / 2026.10.14</span>
          <h1>模拟运行正常，<em>仍未接入真实资金。</em></h1>
          <p className="hero-copy">3 个策略正在 Demo / Dry-run 中运行。所有信号、成交与风险动作都只记录在仿真账本。</p>
        </div>
        <div className="hero-actions"><span className="mode-pill"><span className="status-dot status-dot--live" />Demo / Dry-run</span><button className="secondary-button" onClick={() => onNavigate("risk")}><ShieldAlert size={15} /> 查看风控</button></div>
      </div>

      <div className="metric-grid">
        <MetricCard label="模拟权益" value="$101,420.38" meta="+$1,420.38 · +1.42%" icon={TrendingUp} trend="up" />
        <MetricCard label="今日模拟盈亏" value="+$486.20" meta="过去 24 小时 · 已计手续费" icon={Activity} tone="blue" trend="up" />
        <MetricCard label="账户最大回撤" value="2.8%" meta="距离 P1 阈值 5.2%" icon={Gauge} tone="amber" />
        <MetricCard label="运行策略" value="2 / 3" meta="1 个策略处于保护模式" icon={Bot} tone="purple" />
      </div>

      <div className="grid-layout grid-layout--main">
        <section className="panel panel--chart">
          <SectionHeader eyebrow="EQUITY CURVE / SIMULATED" title="权益曲线" action="打开回测" onAction={() => onNavigate("strategies")} />
          <div className="chart-legend"><span><i className="legend-dot legend-dot--teal" />模拟权益</span><span><i className="legend-dot legend-dot--amber" />风控事件 3</span><span className="chart-period"><button className="period-button period-button--selected">24H</button><button className="period-button">7D</button><button className="period-button">30D</button></span></div>
          <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={equityData} margin={{ top: 10, right: 12, left: -18, bottom: 0 }}>
            <defs><linearGradient id="equityFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#55e6c1" stopOpacity={0.28} /><stop offset="100%" stopColor="#55e6c1" stopOpacity={0} /></linearGradient></defs>
            <CartesianGrid stroke="#22324a" strokeDasharray="3 5" vertical={false} />
            <XAxis dataKey="time" tick={{ fill: "#71819a", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis domain={[99800, 102000]} tick={{ fill: "#71819a", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(value) => `$${Math.round(value / 1000)}k`} />
            <Tooltip contentStyle={{ background: "#111c2d", border: "1px solid #2c3d58", borderRadius: 8, color: "#eef5ff" }} labelStyle={{ color: "#8fa1bb" }} formatter={(value) => [`$${Number(value).toLocaleString()}`, "模拟权益"]} />
            <ReferenceLine y={100000} stroke="#485872" strokeDasharray="4 4" />
            <Area type="monotone" dataKey="value" stroke="#55e6c1" strokeWidth={2.5} fill="url(#equityFill)" />
          </AreaChart></ResponsiveContainer></div>
          <div className="chart-foot"><span><span className="eyebrow">今日高点</span> <strong>$101,420</strong></span><span><span className="eyebrow">手续费估计</span> <strong>$18.60</strong></span><span><span className="eyebrow">滑点估计</span> <strong>$7.40</strong></span></div>
        </section>
        <section className="panel panel--risk"><SectionHeader eyebrow="RISK ENGINE" title="风险状态" action="规则设置" onAction={() => onNavigate("risk")} /><RiskGauge /><div className="risk-stat-list"><div><span>单日亏损</span><strong>0.48% <small>/ 2.00%</small></strong></div><div><span>总持仓</span><strong>18.4% <small>/ 30.00%</small></strong></div><div><span>数据新鲜度</span><strong className="text-teal">良好</strong></div></div><button className="full-button" onClick={() => onNavigate("risk")}><ShieldAlert size={15} /> 打开风控中心 <ChevronRight size={15} /></button></section>
      </div>

      <div className="grid-layout grid-layout--lower">
        <section className="panel"><SectionHeader eyebrow="RUNNING STRATEGIES" title="运行中的策略" action="管理全部" onAction={() => onNavigate("strategies")} /><div className="strategy-table">{strategies.map((strategy) => <StrategyRow key={strategy.id} strategy={strategy} onToggle={onToggle} />)}</div></section>
        <section className="panel"><SectionHeader eyebrow="ALERT CENTER" title="最新预警" action="查看全部" onAction={() => onNavigate("risk")} /><div className="alert-list">{alerts.map((alert, index) => <AlertRow key={`${alert.level}-${index}`} alert={alert} />)}</div></section>
      </div>

      <div className="grid-layout grid-layout--lower"><section className="panel panel--compact"><SectionHeader eyebrow="RECENT TRADES" title="最近模拟成交" action="订单中心" onAction={() => onNavigate("orders")} /><OrderTable compact /></section><section className="panel panel--compact"><SectionHeader eyebrow="SYSTEM HEARTBEAT" title="系统心跳" action="审计日志" onAction={() => onNavigate("logs")} /><Heartbeat /></section></div>
    </>
  );
}

function OrderTable({ compact = false }: { compact?: boolean }) {
  return <div className="order-table"><div className="order-table__header"><span>订单 / 交易对</span><span>方向</span><span>数量 / 价格</span><span>状态</span><span>时间</span></div>{orders.slice(0, compact ? 3 : orders.length).map((order) => <div className="order-row" key={order.id}><div><strong>{order.id}</strong><span>{order.pair} · {order.strategy}</span></div><span className={order.side === "买入" ? "text-teal" : "text-red"}>{order.side}</span><div><strong>{order.amount}</strong><span>{order.price}</span></div><span className={cn("order-state", order.state === "已取消" ? "order-state--muted" : "order-state--ok")}>{order.state}</span><time>{order.time}</time></div>)}</div>;
}

function Heartbeat() {
  return <div className="heartbeat"><div className="heartbeat-row"><div className="heartbeat-icon heartbeat-icon--ok"><Wifi size={15} /></div><div><strong>行情 WebSocket</strong><span>Binance 双连接正常</span></div><b>38ms</b></div><div className="heartbeat-row"><div className="heartbeat-icon heartbeat-icon--ok"><RefreshCcw size={15} /></div><div><strong>账户对账</strong><span>最近一次完成于 20:00:11</span></div><b>通过</b></div><div className="heartbeat-row"><div className="heartbeat-icon heartbeat-icon--warn"><DatabaseBackup size={15} /></div><div><strong>模拟账本</strong><span>订单和持仓最终一致</span></div><b>0 差异</b></div></div>;
}


function StrategyWorkspace({ strategies, onToggle }: { strategies: typeof strategySeed; onToggle: (id: string) => void }) {
  const [selected, setSelected] = useState(strategies[0].id);
  const active = strategies.find((strategy) => strategy.id === selected) ?? strategies[0];
  return <div className="workspace-grid"><section className="panel strategy-list-panel"><div className="workspace-title"><div><span className="eyebrow">PRO MODE / STRATEGIES</span><h1>策略工作台</h1></div><button className="primary-button"><Plus size={16} /> 新建策略</button></div><p className="section-copy">用图形化条件组合策略。当前版本限制为每个策略 10 个指标、3 个时间周期。</p><div className="strategy-list">{strategies.map((strategy) => <button className={cn("strategy-select", selected === strategy.id && "strategy-select--selected")} key={strategy.id} onClick={() => setSelected(strategy.id)}><div className="strategy-select__icon"><Bot size={17} /></div><div><strong>{strategy.name}</strong><span>{strategy.template} · {strategy.indicators} 个指标</span></div><StatusDot status={strategy.status} /><ChevronRight size={15} /></button>)}</div><button className="template-button"><Sparkles size={15} /> 从模板库开始 <ChevronRight size={15} /></button></section><section className="panel editor-panel"><div className="editor-header"><div><span className="eyebrow">STRATEGY CONFIGURATION</span><h2>{active.name}</h2><span className="status-inline"><StatusDot status={active.status} /> {active.status} · {active.version}</span></div><button className="icon-button"><MoreHorizontal size={17} /></button></div><div className="config-strip"><span><small>交易所</small><strong>{active.exchange}</strong></span><span><small>交易对</small><strong>{active.pair}</strong></span><span><small>周期</small><strong>{active.timeframe}</strong></span><span><small>指标</small><strong>{active.indicators} / 10</strong></span></div><div className="rule-section"><div className="rule-section__title"><span>01 / 大趋势过滤</span><span className="rule-count">2 条规则</span></div><RuleRow left="4h · EMA(50)" operator="大于" right="4h · EMA(200)" /><RuleRow left="1h · ADX(14)" operator="大于" right="20" /></div><div className="rule-section"><div className="rule-section__title"><span>02 / 入场条件 <b className="logic-pill">AND</b></span><span className="rule-count">3 条规则</span></div><RuleRow left="15m · RSI(14)" operator="从下向上突破" right="30" /><RuleRow left="15m · MACD" operator="金叉" right="信号线" /><RuleRow left="15m · Volume" operator="大于" right="SMA(20) × 1.2" /></div><div className="rule-section rule-section--exit"><div className="rule-section__title"><span>03 / 退出规则</span><span className="rule-count">优先级已锁定</span></div><div className="exit-rule"><span className="exit-index">1</span><div><strong>保护性止损</strong><span>ATR(14) × 2.0 · 最高价回撤</span></div><span className="exit-tag exit-tag--red">强制保护</span></div><div className="exit-rule"><span className="exit-index">2</span><div><strong>固定止盈</strong><span>入场价 +4.0% · 分批 50%</span></div><span className="exit-tag exit-tag--teal">止盈</span></div><div className="exit-rule"><span className="exit-index">3</span><div><strong>最大持仓时长</strong><span>48 小时 · 到期平仓</span></div><span className="exit-tag">时间</span></div></div><div className="editor-footer"><span><LockKeyhole size={14} /> 风控参数由账户级规则保护</span><button className="secondary-button" onClick={() => onToggle(active.id)}>{active.status === "运行中" ? <><Pause size={15} /> 暂停策略</> : <><Play size={15} /> 启动策略</>}</button></div></section></div>;
}

function StrategyBacktestPanel() {
  const [candles, setCandles] = useState<Array<{ openTime: number; closeTime: number; open: number; high: number; low: number; close: number; volume: number }>>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [comparison, setComparison] = useState<ThreeStageSampleComparison | null>(null);
  const [walkForward, setWalkForward] = useState<WalkForwardResult | null>(null);
  const loadCandles = async () => {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/binance/klines?symbol=BTCUSDT&interval=1m&limit=1000");
      const payload = await response.json() as { candles?: typeof candles; error?: string };
      if (!response.ok || !payload.candles) throw new Error(payload.error ?? "Binance K线读取失败");
      setCandles(payload.candles); setComparison(null); setWalkForward(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Binance K线读取失败");
    } finally { setLoading(false); }
  };
  const runBacktest = () => { if (!candles.length) return; setComparison(compareThreeStageSamples(candles)); setWalkForward(walkForwardThreeStage(candles)); };
  const metric = (result: ThreeStageBacktestResult) => <div className="backtest-metrics"><div className="backtest-metric"><span>收益</span><strong className={result.returnPct >= 0 ? "text-teal" : "text-red"}>{result.returnPct.toFixed(2)}%</strong></div><div className="backtest-metric"><span>最大回撤</span><strong className="text-amber">{result.maxDrawdown.toFixed(2)}%</strong></div><div className="backtest-metric"><span>交易数</span><strong>{result.trades}</strong></div><div className="backtest-metric"><span>胜率</span><strong>{result.winRate.toFixed(1)}%</strong></div><div className="backtest-metric"><span>Profit Factor</span><strong>{result.profitFactor.toFixed(2)}</strong></div></div>;
  return <section className="panel"><div className="workspace-title"><div><span className="eyebrow">BTC/USDT THREE-STAGE / 1m</span><h2>历史回测与样本外验证</h2></div><span className="mode-pill"><Activity size={14} /> Research only</span></div><p className="section-copy">大趋势过滤 → 入场 AND → ATR 动态保护退出。只使用已收盘 K 线，信号在下一根 K 线开盘成交；默认手续费 0.1%、滑点 2 bps，加载最多 1000 根 K 线覆盖 360 根指标预热窗口。</p><div className="rule-section"><div className="rule-section__title"><span>01 / 大趋势过滤</span><span className="rule-count">AND</span></div><div className="research-note"><span>MACD(15,30,15) DIF &gt; DEA · OBV EMA180 上升 · KDJ(180,360,15) K &gt; D</span></div><div className="rule-section__title"><span>02 / 入场条件</span><span className="rule-count">AND</span></div><div className="research-note"><span>StochRSI(60,180,15,30) K 上穿 D · RSI180 &gt; 50.55 · WR60 上穿 -80</span></div><div className="rule-section__title"><span>03 / 退出规则</span><span className="rule-count">保护优先</span></div><div className="research-note"><span>ATR(60) × 2；支持多头和空头保护性退出，回测结束强制结算未平仓。</span></div></div><div className="backtest-actions"><button className="secondary-button" onClick={() => void loadCandles()} disabled={loading}><RefreshCcw size={15} />{loading ? "读取中…" : "读取 1000 根 BTC 1m K线"}</button><button className="primary-button" onClick={runBacktest} disabled={!candles.length}><Activity size={15} />运行三段式回测</button><span className="research-data-status"><span className="status-dot status-dot--live" />{candles.length ? `${candles.length} 根已收盘 K 线` : "尚未读取历史数据"}</span></div>{error && <div className="form-error"><AlertTriangle size={15} />{error}</div>}{comparison && <div className="grid-layout grid-layout--lower"><section className="panel panel--compact"><SectionHeader eyebrow="IN-SAMPLE" title="样本内 / 前 70%" />{metric(comparison.inSample)}</section><section className="panel panel--compact"><SectionHeader eyebrow="OUT-OF-SAMPLE" title="样本外 / 后 30%" />{metric(comparison.outOfSample)}</section></div>}{walkForward && <section className="panel panel--compact"><SectionHeader eyebrow="WALK-FORWARD" title={`滚动向前验证 · ${walkForward.windows.length} 个窗口`} />{metric(walkForward.aggregate)}{walkForward.windows.length ? <div className="research-note"><CheckCircle2 size={14} /><span>每个窗口只在训练区间选择 RSI 阈值 / ATR 倍数，再冻结参数测试下一窗口；样本外累计结果不等于实盘承诺。</span></div> : <div className="form-error"><AlertTriangle size={14} />{walkForward.warnings.join("；")}</div>}</section>}</section>;
}

function RuleRow({ left, operator, right }: { left: string; operator: string; right: string }) {
  return <div className="rule-row"><span>{left}</span><b>{operator}</b><span>{right}</span><button className="remove-rule" aria-label="删除规则"><X size={14} /></button></div>;
}

function RiskCenter({ emergency, onEmergency }: { emergency: boolean; onEmergency: () => void }) {
  const rules = [
    ["P0", "账户最大回撤", "10.00%", "停止全部策略开仓 · 保留保护性止损"],
    ["P1", "策略最大回撤", "8.00%", "停止相关策略 · 取消非保护性挂单"],
    ["P2", "单日亏损预警", "1.00%", "暂停加仓 · 下笔模拟金额减半"],
    ["P2", "行情延迟", "15 秒", "停止对应交易对新开仓"],
    ["P3", "订单重试", "3 次", "记录日志 · 不改变策略状态"],
  ];
  return <div className="risk-page"><div className="workspace-title"><div><span className="eyebrow">RISK ENGINE / GUARDRAILS</span><h1>风控与预警</h1></div><button className="danger-button" onClick={onEmergency}><Square size={15} fill="currentColor" /> {emergency ? "保护模式已开启" : "紧急停止"}</button></div>{emergency && <div className="emergency-banner"><ShieldAlert size={19} /><div><strong>全局保护模式已开启</strong><span>所有策略已停止新开仓。恢复前需要人工确认并完成账户、订单和持仓对账。</span></div><span className="emergency-status">等待确认</span></div>}<div className="risk-overview-grid"><div className="panel"><SectionHeader eyebrow="ACCOUNT GUARDRAIL" title="账户级保护" /><div className="large-risk-readout"><div><span className="eyebrow">当前风险等级</span><strong>P2 <small>可控</small></strong></div><div className="large-risk-percent">2.8%<span>最大回撤</span></div></div><RiskGauge /></div><div className="panel"><SectionHeader eyebrow="AUTOMATION POLICY" title="自动动作" /><div className="policy-list"><div><CheckCircle2 size={16} /><span>P0/P1 自动暂停新开仓</span><b>已启用</b></div><div><CheckCircle2 size={16} /><span>恢复需要人工确认</span><b>已启用</b></div><div><CheckCircle2 size={16} /><span>异常时保留保护性止损</span><b>已启用</b></div><div><LockKeyhole size={16} /><span>提现 / 资金划转 / 杠杆</span><b>已禁用</b></div></div></div></div><section className="panel"><SectionHeader eyebrow="THRESHOLD MATRIX" title="预警阈值与自动动作" action="编辑规则" /><div className="threshold-table"><div className="threshold-row threshold-row--head"><span>级别</span><span>触发规则</span><span>阈值</span><span>系统动作</span><span>状态</span></div>{rules.map(([level, name, threshold, action]) => <div className="threshold-row" key={`${level}-${name}`}><SeverityBadge level={level as Severity} /><strong>{name}</strong><span className="mono-text">{threshold}</span><span>{action}</span><span className="enabled-chip"><Check size={13} /> 已启用</span></div>)}</div></section><section className="panel"><SectionHeader eyebrow="RECENT EVENTS" title="预警历史" action="清空筛选" /><div className="alert-list alert-list--wide">{alerts.map((alert, index) => <AlertRow key={`${alert.level}-${index}`} alert={alert} />)}</div></section></div>;
}

function OrdersPage() {
  const [filter, setFilter] = useState("全部");
  const visibleOrders = useMemo(() => filter === "全部" ? orders : orders.filter((order) => order.state === filter), [filter]);
  return <div className="page-stack"><div className="workspace-title"><div><span className="eyebrow">SIMULATED LEDGER / RECONCILIATION</span><h1>订单与持仓</h1></div><div className="hero-actions"><span className="mode-pill"><DatabaseBackup size={14} /> 模拟账本一致</span><button className="secondary-button"><RefreshCcw size={15} /> 立即对账</button></div></div><div className="subnav-pills">{["全部", "模拟成交", "已取消"].map((item) => <button key={item} className={filter === item ? "subnav-pill subnav-pill--selected" : "subnav-pill"} onClick={() => setFilter(item)}>{item}</button>)}</div><section className="panel"><OrderTable compact={false} /></section><div className="grid-layout grid-layout--lower"><section className="panel"><SectionHeader eyebrow="OPEN POSITIONS" title="当前模拟持仓" /><div className="positions"><div className="position-row"><div><strong>BTC/USDT</strong><span>趋势跟随 · Binance Demo</span></div><strong className="text-teal">+2.14%</strong><div><span>数量</span><b>0.012 BTC</b></div><div><span>止损</span><b>$65,812</b></div></div><div className="position-row"><div><strong>ETH/USDT</strong><span>区间网格 · Binance Demo</span></div><strong className="text-teal">+0.82%</strong><div><span>数量</span><b>0.28 ETH</b></div><div><span>止损</span><b>$3,712</b></div></div></div></section><section className="panel"><SectionHeader eyebrow="RECONCILIATION" title="对账状态" /><Heartbeat /></section></div></div>;
}

function LogsPage() {
  return <div className="page-stack"><div className="workspace-title"><div><span className="eyebrow">AUDIT TRAIL / READ ONLY</span><h1>审计日志</h1></div><div className="log-filter"><Search size={15} /><input placeholder="搜索事件、策略或订单" /><button><Filter size={14} /> 筛选</button></div></div><section className="panel"><div className="log-table"><div className="log-row log-row--head"><span>时间</span><span>级别</span><span>模块</span><span>事件</span><span>版本</span></div>{auditLogs.map(([time, level, module, event]) => <div className="log-row" key={`${time}-${event}`}><time>{time}</time><SeverityBadge level={level as Severity | "INFO"} /><span className="log-module">{module}</span><strong>{event}</strong><span className="mono-text">risk-v1.2</span></div>)}</div></section><div className="log-note"><Eye size={16} /><span>审计日志为只读记录。敏感信息（API Secret、Passphrase 和完整 API Key）不会写入日志。</span></div></div>;
}

function AccountsPage() {
  const [showForm, setShowForm] = useState(false);
  const [label, setLabel] = useState("Binance Demo");
  const [apiKey, setApiKey] = useState("");
  const [secret, setSecret] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [saved, setSaved] = useState(false);
  const saveCredential = trpc.binanceCredentials.save.useMutation({
    onSuccess: () => { setSaved(true); setShowForm(false); setApiKey(""); setSecret(""); setConfirmed(false); },
  });
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!confirmed) return;
    saveCredential.mutate({ label, apiKey, secret, confirmNoWithdraw: true });
  };
  return <div className="page-stack"><div className="workspace-title"><div><span className="eyebrow">EXCHANGE CONNECTIVITY / BINANCE ONLY</span><h1>交易所连接</h1></div><button className="secondary-button" onClick={() => setShowForm(true)}><Plus size={15} /> 添加 Binance Demo 连接</button></div><div className="sandbox-warning"><LockKeyhole size={18} /><div><strong>仅支持 Binance，当前为 Demo / Dry-run</strong><span>API Key 通过 HTTPS 发送到服务端后使用 AES-256-GCM 加密保存。Withdraw 权限必须关闭，前端只显示末 4 位。</span></div></div>{saved && <div className="saved-banner"><CheckCircle2 size={17} /><span>Binance 凭证已加密保存。系统不会显示或记录 Secret 明文。</span><button onClick={() => setSaved(false)}><X size={14} /></button></div>}<div className="account-grid"><ExchangeCard name="Binance" accent="yellow" status="运行中" latency="38ms" markets="Spot · Demo" lastSync="20:00:11" /></div><section className="panel"><SectionHeader eyebrow="ENCRYPTED CREDENTIAL VAULT" title="API Key 安全边界" /><div className="security-grid"><div><LockKeyhole size={16} /><strong>AES-256-GCM 加密</strong><span>API Key 与 Secret 分开加密</span></div><div><ServerCog size={16} /><strong>服务端保存</strong><span>前端不接触已保存 Secret</span></div><div><ShieldAlert size={16} /><strong>仅 Read + Trade</strong><span>Withdraw 权限拒绝保存</span></div><div><Eye size={16} /><strong>只显示末 4 位</strong><span>日志不记录完整密钥</span></div></div></section>{showForm && <div className="credential-modal" role="dialog" aria-modal="true"><div className="credential-modal__backdrop" onClick={() => setShowForm(false)} /><form className="credential-modal__card" onSubmit={submit}><div className="credential-modal__header"><div><span className="eyebrow">BINANCE / ENCRYPTED VAULT</span><h2>保存 API 凭证</h2></div><button type="button" className="icon-button" onClick={() => setShowForm(false)}><X size={17} /></button></div><p className="section-copy">凭证只用于 Binance API 访问。请在 Binance 创建 API Key 时关闭 Withdraw，并绑定服务器 IP。</p><label>连接名称<input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Binance Demo" /></label><label>API Key<input value={apiKey} onChange={(e) => setApiKey(e.target.value)} autoComplete="off" required /></label><label>Secret Key<input value={secret} onChange={(e) => setSecret(e.target.value)} type="password" autoComplete="new-password" required /></label><label className="confirm-check"><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} required /><span>我确认该 Binance API Key 已关闭 Withdraw 权限。</span></label>{saveCredential.error && <div className="form-error"><AlertTriangle size={15} /> 保存失败：请确认已登录、数据库和加密密钥已配置。</div>}<div className="credential-modal__footer"><span><LockKeyhole size={14} /> 服务端加密后才会落库</span><button type="submit" className="primary-button" disabled={saveCredential.isPending || !confirmed}>{saveCredential.isPending ? "加密保存中…" : "加密保存"}</button></div></form></div>}</div>;
}
function ExchangeCard({ name, accent, status, latency, markets, lastSync }: { name: string; accent: string; status: string; latency: string; markets: string; lastSync: string }) {
  return <div className="exchange-card"><div className={cn("exchange-logo", `exchange-logo--${accent}`)}>{name === "Binance" ? "B" : "O"}</div><div className="exchange-card__body"><div className="exchange-card__title"><div><strong>{name}</strong><span className="status-inline"><StatusDot status="运行中" /> {status}</span></div><button className="icon-button"><Settings2 size={16} /></button></div><div className="exchange-card__meta"><span>{markets}</span><span><Wifi size={13} /> {latency}</span><span>同步 {lastSync}</span></div><div className="exchange-progress"><span /><span /><span /><span /><span /><span /></div><div className="exchange-card__foot"><span>行情、账户、订单流均正常</span><span className="text-teal">Demo 环境</span></div></div></div>;
}

export default function Home() {
  const [activeView, setActiveView] = useState<View>("overview");
  const [strategies, setStrategies] = useState(strategySeed);
  const [emergency, setEmergency] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  const toggleStrategy = (id: string) => {
    setStrategies((current) => current.map((strategy) => strategy.id === id && strategy.status !== "保护模式" ? { ...strategy, status: strategy.status === "运行中" ? "已暂停" : "运行中" } : strategy));
  };

  const handleEmergency = () => {
    setEmergency(true);
    setStrategies((current) => current.map((strategy) => strategy.status === "运行中" ? { ...strategy, status: "保护模式" } : strategy));
  };

  const currentTitle = navItems.find((item) => item.id === activeView)?.label ?? "控制室";

  return <div className="app-shell">
    <header className="mobile-topbar"><button className="icon-button" onClick={() => setMobileNav(!mobileNav)} aria-label="打开导航"><Menu size={19} /></button><div className="brand-mark"><span>LQ</span><div><strong>LAZYQUANT</strong><small>PRO CONTROL</small></div></div><span className="mobile-live-dot" /></header>
    <aside className={cn("sidebar", mobileNav && "sidebar--open")}>
      <div className="brand-mark brand-mark--desktop"><span>LQ</span><div><strong>LAZYQUANT</strong><small>PRO CONTROL</small></div></div>
      <div className="sidebar-mode"><span className="status-dot status-dot--live" /><div><span>运行模式</span><strong>Demo / Dry-run</strong></div><ChevronDown size={14} /></div>
      <nav className="main-nav">{navItems.map(({ id, label, icon: Icon, badge }) => <button key={id} className={cn("nav-item", activeView === id && "nav-item--active")} onClick={() => { setActiveView(id); setMobileNav(false); }}><Icon size={17} /><span>{label}</span>{badge && <b>{badge}</b>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="system-card"><div className="system-card__top"><span className="eyebrow">SYSTEM</span><span className="pulse-ring"><span /></span></div><strong>系统运行正常</strong><span>心跳 38ms · 上次对账 20:00</span></div><button className="nav-item"><Settings2 size={17} /><span>偏好设置</span></button><button className="user-row"><span className="avatar">L</span><span><strong>本地工作区</strong><small>仅自己可见</small></span><MoreHorizontal size={16} /></button></div>
    </aside>
    <main className="main-content">
      <div className="topbar"><div className="breadcrumbs"><span>LAZYQUANT</span><ChevronRight size={14} /><strong>{currentTitle}</strong></div><div className="topbar-actions"><span className="topbar-status"><span className="status-dot status-dot--live" />全部系统正常</span><button className="notification-button" onClick={() => setActiveView("risk")}><BellRing size={17} /><span>2</span></button><button className="avatar avatar--top">L</button></div></div>
      {activeView === "overview" && <Overview strategies={strategies} onToggle={toggleStrategy} onNavigate={setActiveView} />}
      {activeView === "research" && <ResearchPage />}
      {activeView === "strategies" && <><StrategyWorkspace strategies={strategies} onToggle={toggleStrategy} /><StrategyBacktestPanel /></>}
      {activeView === "risk" && <RiskCenter emergency={emergency} onEmergency={handleEmergency} />}
      {activeView === "orders" && <OrdersPage />}
      {activeView === "logs" && <LogsPage />}
      {activeView === "accounts" && <AccountsPage />}
      <footer className="app-footer"><span><LockKeyhole size={13} /> 私有工作区 · Demo 数据仅供测试</span><span>版本 0.1.0 · 2026.10.14</span></footer>
    </main>
  </div>;
}
