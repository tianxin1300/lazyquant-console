export type Candle = {
  openTime: number;
  closeTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type IndicatorKind = "KDJ" | "ATR" | "OBV" | "MACD" | "BOLL" | "RSI" | "EMA" | "StochRSI" | "WR" | "SUPER";
export type IndicatorPurpose = "过滤" | "入场" | "出场" | "风控";
export type IndicatorGroup = { id: string; kind: IndicatorKind; enabled: boolean; timeframe: string; purpose: IndicatorPurpose; params: Record<string, number> };

type Series = Array<number | null>;

/* ----------------------------------------------------------------------------
 * 基础滚动工具：全部 O(n)，并且能正确处理含 null 的输入序列。
 * ------------------------------------------------------------------------- */

/** 简单移动平均。窗口内只要有 null（指标尚未就绪）就输出 null，不会把 null 当 0 参与计算。 */
function smaSeries(values: Series, period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  if (!Number.isInteger(period) || period <= 0) return out;
  let sum = 0;
  let nulls = 0;
  for (let i = 0; i < values.length; i++) {
    const incoming = values[i];
    if (incoming === null) nulls++; else sum += incoming;
    if (i >= period) {
      const outgoing = values[i - period];
      if (outgoing === null) nulls--; else sum -= outgoing;
    }
    if (i + 1 >= period && nulls === 0) out[i] = sum / period;
  }
  return out;
}

/**
 * 指数移动平均，以首个完整窗口的 SMA 作为种子（与 TradingView / TA-Lib 一致）。
 * 输入允许有"前导 null"（例如对 MACD 的 DIF 再做 EMA），种子从第一个非 null 值开始计。
 */
function ema(values: Series, period: number): Series {
  const out: Series = new Array(values.length).fill(null);
  if (!Number.isInteger(period) || period <= 0) return out;
  const first = values.findIndex((value) => value !== null);
  if (first < 0) return out;
  const seedAt = first + period - 1;
  if (seedAt >= values.length) return out;
  const multiplier = 2 / (period + 1);
  let seed = 0;
  for (let i = first; i <= seedAt; i++) {
    const value = values[i];
    if (value === null) return out; // 非前导 null：数据不连续，拒绝给出误导性结果
    seed += value;
  }
  let previous = seed / period;
  out[seedAt] = previous;
  for (let i = seedAt + 1; i < values.length; i++) {
    const value = values[i];
    if (value === null) return out;
    previous = (value - previous) * multiplier + previous;
    out[i] = previous;
  }
  return out;
}

function highest(candles: Candle[], from: number, to: number) { let value = -Infinity; for (let i = from; i <= to; i++) if (candles[i].high > value) value = candles[i].high; return value; }
function lowest(candles: Candle[], from: number, to: number) { let value = Infinity; for (let i = from; i <= to; i++) if (candles[i].low < value) value = candles[i].low; return value; }

function trueRanges(candles: Candle[]) {
  return candles.map((candle, index) => index === 0
    ? candle.high - candle.low
    : Math.max(candle.high - candle.low, Math.abs(candle.high - candles[index - 1].close), Math.abs(candle.low - candles[index - 1].close)));
}

function obvValues(candles: Candle[]) {
  let obv = 0;
  return candles.map((candle, index) => {
    if (index > 0) {
      const previous = candles[index - 1].close;
      if (candle.close > previous) obv += candle.volume;
      else if (candle.close < previous) obv -= candle.volume;
    }
    return obv;
  });
}

/* ----------------------------------------------------------------------------
 * 指标
 * ------------------------------------------------------------------------- */

export function calculateKdj(candles: Candle[], period = 9, kPeriod = 3, dPeriod = 3) {
  let previousK = 50;
  let previousD = 50;
  return candles.map((candle, index) => {
    if (index + 1 < period) return { k: null, d: null, j: null };
    const high = highest(candles, index - period + 1, index);
    const low = lowest(candles, index - period + 1, index);
    const rsv = high === low ? 50 : ((candle.close - low) / (high - low)) * 100;
    const k = (previousK * (kPeriod - 1) + rsv) / kPeriod;
    const d = (previousD * (dPeriod - 1) + k) / dPeriod;
    previousK = k;
    previousD = d;
    return { k, d, j: 3 * k - 2 * d };
  });
}

export function calculateAtr(candles: Candle[], period = 14) {
  return smaSeries(trueRanges(candles), period).map((value) => ({ value }));
}

export function calculateObv(candles: Candle[], signalPeriod = 20) {
  const values = obvValues(candles);
  const signal = smaSeries(values, signalPeriod);
  return values.map((value, index) => ({ value, signal: signal[index] }));
}

export function calculateMacd(candles: Candle[], fast = 12, slow = 26, signalPeriod = 9) {
  const closes = candles.map((candle) => candle.close);
  const fastEma = ema(closes, fast);
  const slowEma = ema(closes, slow);
  const dif: Series = closes.map((_close, index) => {
    const f = fastEma[index]; const s = slowEma[index];
    return f !== null && s !== null ? f - s : null;
  });
  // 修复：DEA 必须只对"已就绪"的 DIF 做 EMA。原实现把 null 当 0 喂进 EMA，早期 DEA 会被严重拉偏（实测最大误差 ≈0.42）。
  const dea = ema(dif, signalPeriod);
  return dif.map((value, index) => {
    const signal = dea[index];
    return { dif: value, dea: signal, histogram: value !== null && signal !== null ? value - signal : null };
  });
}

export function calculateBoll(candles: Candle[], period = 20, multiplier = 2) {
  const closes = candles.map((candle) => candle.close); // 原实现在每个 index 里重复构造一次 closes，O(n²) 内存分配
  const middles = smaSeries(closes, period);
  return closes.map((_close, index) => {
    const middle = middles[index];
    if (middle === null) return { middle: null, upper: null, lower: null };
    let variance = 0;
    for (let i = index - period + 1; i <= index; i++) variance += (closes[i] - middle) ** 2;
    const deviation = Math.sqrt(variance / period);
    return { middle, upper: middle + multiplier * deviation, lower: middle - multiplier * deviation };
  });
}

/** Wilder RSI。无亏损时返回 100（原实现因 rs=100 恒返回 ≈99.01）。 */
export function calculateRsi(candles: Candle[], period = 14) {
  const out: Series = new Array(candles.length).fill(null);
  if (!Number.isInteger(period) || period <= 0 || candles.length <= period) return out.map((value) => ({ value }));
  let averageGain = 0;
  let averageLoss = 0;
  for (let i = 1; i <= period; i++) {
    const change = candles[i].close - candles[i - 1].close;
    if (change > 0) averageGain += change; else averageLoss -= change;
  }
  averageGain /= period;
  averageLoss /= period;
  const toRsi = () => averageLoss === 0 ? (averageGain === 0 ? 50 : 100) : 100 - 100 / (1 + averageGain / averageLoss);
  out[period] = toRsi();
  for (let i = period + 1; i < candles.length; i++) {
    const change = candles[i].close - candles[i - 1].close;
    averageGain = (averageGain * (period - 1) + Math.max(change, 0)) / period;
    averageLoss = (averageLoss * (period - 1) + Math.max(-change, 0)) / period;
    out[i] = toRsi();
  }
  return out.map((value) => ({ value }));
}

export function calculateEma(candles: Candle[], period = 20) {
  return ema(candles.map((candle) => candle.close), period).map((value) => ({ value }));
}

/**
 * StochRSI。修复：
 * 1) %K/%D 平滑只作用于已就绪的值（原实现把 null 当 0 参与均值）；
 * 2) %D 是 %K 的平滑（原实现是对 raw 再平滑一次，与通用定义不符）。
 */
export function calculateStochRsi(candles: Candle[], rsiPeriod = 14, stochPeriod = 14, kPeriod = 3, dPeriod = 3) {
  const rsi = calculateRsi(candles, rsiPeriod).map((point) => point.value);
  const raw: Series = rsi.map((value, index) => {
    if (value === null || index + 1 < stochPeriod) return null;
    let min = Infinity; let max = -Infinity;
    for (let i = index - stochPeriod + 1; i <= index; i++) {
      const item = rsi[i];
      if (item === null) return null;
      if (item < min) min = item;
      if (item > max) max = item;
    }
    return max === min ? 50 : ((value - min) / (max - min)) * 100;
  });
  const k = smaSeries(raw, kPeriod);
  const d = smaSeries(k, dPeriod);
  return raw.map((_value, index) => ({ k: k[index], d: d[index] }));
}

export function calculateWr(candles: Candle[], period = 14) {
  return candles.map((candle, index) => {
    if (index + 1 < period) return { value: null };
    const high = highest(candles, index - period + 1, index);
    const low = lowest(candles, index - period + 1, index);
    return { value: high === low ? -50 : ((high - candle.close) / (high - low)) * -100 };
  });
}

/**
 * Supertrend。原实现没有"棘轮"（上轨只降不升、下轨只升不降）也没有用上一根收盘价判断翻转，
 * 实测在 500 根 K 线上从不翻转、上升趋势线还会下降。这里按标准算法重写。
 * direction: 1 = 上升趋势（线在价格下方），-1 = 下降趋势。
 */
export function calculateSuper(candles: Candle[], period = 10, multiplier = 3) {
  const atr = calculateAtr(candles, period).map((point) => point.value);
  let direction = 1;
  let finalUpper = 0;
  let finalLower = 0;
  let started = false;
  return candles.map((candle, index) => {
    const range = atr[index];
    if (range === null) return { value: null, direction: null };
    const basis = (candle.high + candle.low) / 2;
    const basicUpper = basis + multiplier * range;
    const basicLower = basis - multiplier * range;
    if (!started) {
      finalUpper = basicUpper; finalLower = basicLower; started = true;
    } else {
      const previousClose = candles[index - 1].close;
      finalUpper = basicUpper < finalUpper || previousClose > finalUpper ? basicUpper : finalUpper;
      finalLower = basicLower > finalLower || previousClose < finalLower ? basicLower : finalLower;
      if (direction === -1 && candle.close > finalUpper) direction = 1;
      else if (direction === 1 && candle.close < finalLower) direction = -1;
    }
    return { value: direction === 1 ? finalLower : finalUpper, direction };
  });
}

/** 三段式策略指标参数；回测可复制并调整 RSI 阈值和 ATR 倍数。 */
export type BtcUsdtContractParams = {
  kdj: { period: number; kPeriod: number; dPeriod: number };
  stochRsi: { rsiPeriod: number; stochPeriod: number; kPeriod: number; dPeriod: number };
  macd: { fast: number; slow: number; signalPeriod: number };
  wr: { period: number };
  obvEmaPeriod: number;
  rsi: { period: number; threshold: number };
  atr: { period: number; multiplier: number };
};

export const BTC_USDT_CONTRACT_INDICATOR_PRESET: BtcUsdtContractParams = {
  kdj: { period: 180, kPeriod: 360, dPeriod: 15 },
  stochRsi: { rsiPeriod: 60, stochPeriod: 180, kPeriod: 15, dPeriod: 30 },
  macd: { fast: 15, slow: 30, signalPeriod: 15 },
  wr: { period: 60 },
  obvEmaPeriod: 180,
  rsi: { period: 180, threshold: 50.55 },
  atr: { period: 60, multiplier: 2 },
} as const;

export function calculateObvEma(candles: Candle[], period = BTC_USDT_CONTRACT_INDICATOR_PRESET.obvEmaPeriod) {
  const values = obvValues(candles);
  return ema(values, period).map((value, index) => ({ value, obv: values[index] }));
}

export function calculateBtcUsdtContractIndicators(candles: Candle[], preset: BtcUsdtContractParams = BTC_USDT_CONTRACT_INDICATOR_PRESET) {
  return {
    kdj: calculateKdj(candles, preset.kdj.period, preset.kdj.kPeriod, preset.kdj.dPeriod),
    stochRsi: calculateStochRsi(candles, preset.stochRsi.rsiPeriod, preset.stochRsi.stochPeriod, preset.stochRsi.kPeriod, preset.stochRsi.dPeriod),
    macd: calculateMacd(candles, preset.macd.fast, preset.macd.slow, preset.macd.signalPeriod),
    wr: calculateWr(candles, preset.wr.period),
    obvEma: calculateObvEma(candles, preset.obvEmaPeriod),
    rsi: calculateRsi(candles, preset.rsi.period),
    atr: calculateAtr(candles, preset.atr.period),
  };
}
