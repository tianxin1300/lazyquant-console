import { BTC_USDT_CONTRACT_INDICATOR_PRESET as PRESET, calculateBtcUsdtContractIndicators, type BtcUsdtContractParams, type Candle } from "./indicators";

export type { BtcUsdtContractParams } from "./indicators";

export type BtcUsdtContractStrategy = {
  id: "btc-usdt-contract-1m";
  name: string;
  market: "Binance USDT-M Futures";
  symbol: "BTC/USDT";
  timeframe: "1m";
  stages: {
    trendFilter: string[];
    entryAnd: string[];
    atrExit: { atrPeriod: number; multiplier: number; direction: "long" | "short" | "both" };
  };
};

export const BTC_USDT_CONTRACT_1M_STRATEGY: BtcUsdtContractStrategy = {
  id: "btc-usdt-contract-1m",
  name: "BTC/USDT 合约 · 1min 三段式",
  market: "Binance USDT-M Futures",
  symbol: "BTC/USDT",
  timeframe: "1m",
  stages: {
    trendFilter: ["MACD(15,30,15) DIF > DEA", "OBV EMA180 上升", "KDJ(180,360,15) K > D"],
    entryAnd: ["StochRSI(60,180,15,30) K 上穿 D", "RSI180 > 50.55", "WR60 上穿 -80"],
    atrExit: { atrPeriod: 60, multiplier: 2, direction: "both" },
  },
};

export type BtcSignal = {
  trendPass: boolean;
  entryPass: boolean;
  enterLong: boolean;
  enterShort: boolean;
  exitLong: boolean;
  exitShort: boolean;
  atrStop: number | null;
  shortAtrStop: number | null;
  reason: string[];
};

function crossedAbove(current: number | null, previous: number | null, threshold: number) {
  return current !== null && previous !== null && previous <= threshold && current > threshold;
}

function crossedBelow(current: number | null, previous: number | null, threshold: number) {
  return current !== null && previous !== null && previous >= threshold && current < threshold;
}

function crossedAboveSeries(current: number | null, previous: number | null, currentOther: number | null, previousOther: number | null) {
  return current !== null && previous !== null && currentOther !== null && previousOther !== null && previous <= previousOther && current > currentOther;
}

function crossedBelowSeries(current: number | null, previous: number | null, currentOther: number | null, previousOther: number | null) {
  return current !== null && previous !== null && currentOther !== null && previousOther !== null && previous >= previousOther && current < currentOther;
}

export type BtcIndicators = ReturnType<typeof calculateBtcUsdtContractIndicators>;

/** 在预先算好的指标上评估第 index 根已收盘 K 线。 */
export function evaluateBtcUsdtContractSignal(
  indicators: BtcIndicators | undefined,
  candles: Candle[],
  index: number,
  positionEntryPrice?: number,
  params: BtcUsdtContractParams = PRESET,
): BtcSignal {
  const candle = candles[index];
  if (!candle) throw new RangeError(`Candle index out of range: ${index}`);
  const computed = indicators ?? calculateBtcUsdtContractIndicators(candles, params);
  const previous = Math.max(0, index - 1);
  const kdj = computed.kdj[index]; const previousKdj = computed.kdj[previous];
  const stoch = computed.stochRsi[index]; const previousStoch = computed.stochRsi[previous];
  const macd = computed.macd[index]; const previousMacd = computed.macd[previous];
  const wr = computed.wr[index]?.value ?? null; const previousWr = computed.wr[previous]?.value ?? null;
  const rsi = computed.rsi[index]?.value ?? null;
  const obv = computed.obvEma[index]?.obv ?? null; const previousObv = computed.obvEma[previous]?.obv ?? null;
  const atr = computed.atr[index]?.value ?? null;
  const { threshold } = params.rsi;
  const { period: atrPeriod, multiplier: atrMultiplier } = params.atr;

  const macdLong = macd?.dif != null && macd?.dea != null && macd.dif > macd.dea;
  const macdShort = macd?.dif != null && macd?.dea != null && macd.dif < macd.dea;
  const obvLong = obv !== null && previousObv !== null && obv > previousObv;
  const obvShort = obv !== null && previousObv !== null && obv < previousObv;
  const kdjLong = kdj?.k != null && kdj?.d != null && kdj.k > kdj.d;
  const kdjShort = kdj?.k != null && kdj?.d != null && kdj.k < kdj.d;
  const trendLong = macdLong && obvLong && kdjLong;
  const trendShort = macdShort && obvShort && kdjShort;
  const entryLong = stoch?.k != null && stoch?.d != null && stoch.k > stoch.d
    && rsi !== null && rsi > threshold
    && wr !== null && wr > -80;
  const entryShort = stoch?.k != null && stoch?.d != null && stoch.k < stoch.d
    && rsi !== null && rsi < 100 - threshold
    && wr !== null && wr < -20;
  const exitLong = atr !== null && positionEntryPrice !== undefined && candle.close <= positionEntryPrice - atr * atrMultiplier;
  const exitShort = atr !== null && positionEntryPrice !== undefined && candle.close >= positionEntryPrice + atr * atrMultiplier;
  const reason = [
    trendLong ? "多头大趋势过滤通过" : trendShort ? "空头大趋势过滤通过" : "大趋势过滤未通过",
    entryLong ? "多头入场 AND 条件通过" : entryShort ? "空头入场 AND 条件通过" : "入场条件未齐全",
    atr !== null ? `ATR${atrPeriod}=${atr.toFixed(2)}，动态止损倍数=${atrMultiplier}` : "ATR 未就绪",
  ];
  return {
    trendPass: trendLong || trendShort,
    entryPass: entryLong || entryShort,
    enterLong: trendLong && entryLong,
    enterShort: trendShort && entryShort,
    exitLong,
    exitShort,
    atrStop: atr === null ? null : candle.close - atr * atrMultiplier,
    shortAtrStop: atr === null ? null : candle.close + atr * atrMultiplier,
    reason,
  };
}

export function calculateBtcUsdtContractSignal(candles: Candle[], index: number, positionEntryPrice?: number, indicators = calculateBtcUsdtContractIndicators(candles), params: BtcUsdtContractParams = PRESET) {
  return evaluateBtcUsdtContractSignal(indicators, candles, index, positionEntryPrice, params);
}

export function generateBtcUsdtContractSignals(candles: Candle[], params: BtcUsdtContractParams = PRESET) {
  const indicators = calculateBtcUsdtContractIndicators(candles, params);
  return candles.map((_candle, index) => evaluateBtcUsdtContractSignal(indicators, candles, index, undefined, params));
}
