import { calculateBtcUsdtContractIndicators, type Candle } from "./indicators";
import { evaluateBtcUsdtContractSignal, type BtcUsdtContractParams } from "./signalEngine";

export type ThreeStageBacktestOptions = {
  initialCash?: number;
  feeRate?: number;
  slippageBps?: number;
  startIndex?: number;
  endIndex?: number;
  closeOpenAtEnd?: boolean;
  params?: BtcUsdtContractParams;
};

export type ThreeStageTrade = {
  direction: "LONG" | "SHORT";
  entryIndex: number;
  entryTime: number;
  entryPrice: number;
  exitIndex: number;
  exitTime: number;
  exitPrice: number;
  quantity: number;
  grossPnl: number;
  fees: number;
  netPnl: number;
  exitReason: string;
};

export type ThreeStageBacktestResult = {
  strategy: "BTC_USDT_THREE_STAGE";
  initialCash: number;
  finalEquity: number;
  returnPct: number;
  trades: number;
  winRate: number;
  maxDrawdown: number;
  profitFactor: number;
  equity: number[];
  tradeLog: ThreeStageTrade[];
  warnings: string[];
  startIndex: number;
  endIndex: number;
};

export type ThreeStageSampleComparison = {
  splitIndex: number;
  splitRatio: number;
  inSample: ThreeStageBacktestResult;
  outOfSample: ThreeStageBacktestResult;
};

export type WalkForwardWindow = {
  index: number;
  trainStart: number;
  trainEnd: number;
  testStart: number;
  testEnd: number;
  selectedParams: BtcUsdtContractParams;
  train: ThreeStageBacktestResult;
  outOfSample: ThreeStageBacktestResult;
};

export type WalkForwardResult = {
  windows: WalkForwardWindow[];
  aggregate: ThreeStageBacktestResult;
  warnings: string[];
};

export const DEFAULT_THREE_STAGE_PARAMS: BtcUsdtContractParams = {
  kdj: { period: 180, kPeriod: 360, dPeriod: 15 },
  stochRsi: { rsiPeriod: 60, stochPeriod: 180, kPeriod: 15, dPeriod: 30 },
  macd: { fast: 15, slow: 30, signalPeriod: 15 },
  wr: { period: 60 },
  obvEmaPeriod: 180,
  rsi: { period: 180, threshold: 50.55 },
  atr: { period: 60, multiplier: 2 },
};

function mergeParams(base: BtcUsdtContractParams, patch: Partial<BtcUsdtContractParams>): BtcUsdtContractParams {
  return {
    ...base,
    ...patch,
    kdj: { ...base.kdj, ...patch.kdj },
    stochRsi: { ...base.stochRsi, ...patch.stochRsi },
    macd: { ...base.macd, ...patch.macd },
    wr: { ...base.wr, ...patch.wr },
    rsi: { ...base.rsi, ...patch.rsi },
    atr: { ...base.atr, ...patch.atr },
  };
}

function entryFill(open: number, direction: "LONG" | "SHORT", slippageBps: number) {
  const factor = slippageBps / 10_000;
  return direction === "LONG" ? open * (1 + factor) : open * (1 - factor);
}

function exitFill(price: number, direction: "LONG" | "SHORT", slippageBps: number) {
  const factor = slippageBps / 10_000;
  return direction === "LONG" ? price * (1 - factor) : price * (1 + factor);
}

function aggregateTrades(results: ThreeStageBacktestResult[], initialCash: number): ThreeStageBacktestResult {
  const totalTrades = results.reduce((sum, result) => sum + result.trades, 0);
  const wins = results.reduce((sum, result) => sum + result.tradeLog.filter((trade) => trade.netPnl >= 0).length, 0);
  const grossWin = results.reduce((sum, result) => sum + result.tradeLog.filter((trade) => trade.netPnl > 0).reduce((s, trade) => s + trade.netPnl, 0), 0);
  const grossLoss = results.reduce((sum, result) => sum + result.tradeLog.filter((trade) => trade.netPnl < 0).reduce((s, trade) => s + Math.abs(trade.netPnl), 0), 0);
  const compoundedFinal = results.reduce((equity, result) => equity * (1 + result.returnPct / 100), initialCash);
  return {
    strategy: "BTC_USDT_THREE_STAGE",
    initialCash,
    finalEquity: compoundedFinal,
    returnPct: (compoundedFinal / initialCash - 1) * 100,
    trades: totalTrades,
    winRate: totalTrades ? wins / totalTrades * 100 : 0,
    maxDrawdown: results.reduce((max, result) => Math.max(max, result.maxDrawdown), 0),
    profitFactor: grossLoss ? grossWin / grossLoss : grossWin ? 99 : 0,
    equity: results.flatMap((result) => result.equity),
    tradeLog: results.flatMap((result) => result.tradeLog),
    warnings: results.flatMap((result) => result.warnings),
    startIndex: results[0]?.startIndex ?? 0,
    endIndex: results.at(-1)?.endIndex ?? 0,
  };
}

/**
 * 三段式策略回测：趋势过滤 AND 入场条件 AND ATR 动态保护退出。
 * 信号只在收盘蜡烛确认，成交排队到下一根蜡烛开盘，避免同蜡烛前视偏差。
 */
export function backtestBtcUsdtThreeStage(candles: Candle[], options: ThreeStageBacktestOptions = {}): ThreeStageBacktestResult {
  const initialCash = options.initialCash ?? 10_000;
  const feeRate = options.feeRate ?? 0.001;
  const slippageBps = options.slippageBps ?? 2;
  const startIndex = Math.max(0, Math.min(options.startIndex ?? 0, candles.length));
  const endIndex = Math.max(startIndex, Math.min(options.endIndex ?? candles.length, candles.length));
  const closeOpenAtEnd = options.closeOpenAtEnd ?? true;
  const params = options.params ?? DEFAULT_THREE_STAGE_PARAMS;
  const indicators = calculateBtcUsdtContractIndicators(candles, params);
  const warnings: string[] = [];
  if (endIndex - startIndex < 2) warnings.push("回测区间至少需要两根 K 线");
  if (candles.length < 360) warnings.push("样本少于三段式策略的最长指标预热窗口 360 根，早期信号可能为空");

  type Position = { direction: "LONG" | "SHORT"; entryIndex: number; entryPrice: number; quantity: number; entryFee: number };
  type Pending = { direction: "LONG" | "SHORT"; reason: string };
  let position: Position | undefined;
  let pending: Pending | undefined;
  let realized = 0;
  let equity: number[] = [];
  const tradeLog: ThreeStageTrade[] = [];
  let peak = initialCash;
  let maxDrawdown = 0;

  const markEquity = (close: number) => {
    if (!position) return initialCash + realized;
    const unrealized = position.direction === "LONG"
      ? (close - position.entryPrice) * position.quantity
      : (position.entryPrice - close) * position.quantity;
    return initialCash + realized + unrealized;
  };

  const closePosition = (index: number, rawPrice: number, reason: string) => {
    if (!position) return;
    const price = exitFill(rawPrice, position.direction, slippageBps);
    const grossPnl = position.direction === "LONG"
      ? (price - position.entryPrice) * position.quantity
      : (position.entryPrice - price) * position.quantity;
    const exitFee = price * position.quantity * feeRate;
    const fees = position.entryFee + exitFee;
    const netPnl = grossPnl - fees;
    realized += grossPnl - exitFee;
    tradeLog.push({
      direction: position.direction,
      entryIndex: position.entryIndex,
      entryTime: candles[position.entryIndex].closeTime,
      entryPrice: position.entryPrice,
      exitIndex: index,
      exitTime: candles[index].closeTime,
      exitPrice: price,
      quantity: position.quantity,
      grossPnl,
      fees,
      netPnl,
      exitReason: reason,
    });
    position = undefined;
  };

  for (let index = startIndex; index < endIndex; index++) {
    const candle = candles[index];
    if (pending && !position) {
      const price = entryFill(candle.open, pending.direction, slippageBps);
      const quantity = initialCash / price;
      const entryFee = initialCash * feeRate;
      realized -= entryFee;
      position = { direction: pending.direction, entryIndex: index, entryPrice: price, quantity, entryFee };
      pending = undefined;
    }

    const marked = markEquity(candle.close);
    equity.push(marked);
    peak = Math.max(peak, marked);
    maxDrawdown = Math.max(maxDrawdown, peak > 0 ? (peak - marked) / peak * 100 : 0);

    const last = index === endIndex - 1;
    if (last) {
      if (position && closeOpenAtEnd) closePosition(index, candle.close, "END_OF_SAMPLE");
      continue;
    }

    const signal = evaluateBtcUsdtContractSignal(
      indicators,
      candles,
      index,
      position?.entryPrice,
      params,
    );
    if (position?.direction === "LONG" && signal.exitLong) {
      pending = { direction: "LONG", reason: "ATR_STOP" };
      closePosition(index + 1, candles[index + 1].open, "ATR_STOP");
      pending = undefined;
    } else if (position?.direction === "SHORT" && signal.exitShort) {
      pending = { direction: "SHORT", reason: "ATR_STOP" };
      closePosition(index + 1, candles[index + 1].open, "ATR_STOP");
      pending = undefined;
    } else if (!position && signal.enterLong) {
      pending = { direction: "LONG", reason: "THREE_STAGE_ENTRY" };
    } else if (!position && signal.enterShort) {
      pending = { direction: "SHORT", reason: "THREE_STAGE_ENTRY" };
    }
  }

  const wins = tradeLog.filter((trade) => trade.netPnl >= 0).length;
  const grossWin = tradeLog.filter((trade) => trade.netPnl > 0).reduce((sum, trade) => sum + trade.netPnl, 0);
  const grossLoss = tradeLog.filter((trade) => trade.netPnl < 0).reduce((sum, trade) => sum + Math.abs(trade.netPnl), 0);
  const finalEquity = initialCash + realized;
  return {
    strategy: "BTC_USDT_THREE_STAGE",
    initialCash,
    finalEquity,
    returnPct: (finalEquity / initialCash - 1) * 100,
    trades: tradeLog.length,
    winRate: tradeLog.length ? wins / tradeLog.length * 100 : 0,
    maxDrawdown,
    profitFactor: grossLoss ? grossWin / grossLoss : grossWin ? 99 : 0,
    equity,
    tradeLog,
    warnings,
    startIndex,
    endIndex,
  };
}

export function compareThreeStageSamples(candles: Candle[], splitRatio = 0.7, options: ThreeStageBacktestOptions = {}): ThreeStageSampleComparison {
  const splitIndex = Math.max(1, Math.min(candles.length - 1, Math.floor(candles.length * splitRatio)));
  return {
    splitIndex,
    splitRatio,
    inSample: backtestBtcUsdtThreeStage(candles, { ...options, startIndex: 0, endIndex: splitIndex }),
    outOfSample: backtestBtcUsdtThreeStage(candles, { ...options, startIndex: splitIndex, endIndex: candles.length }),
  };
}

function candidateParams(base: BtcUsdtContractParams): BtcUsdtContractParams[] {
  const thresholds = [49, 50.55, 52];
  const multipliers = [1.5, 2, 2.5];
  return thresholds.flatMap((threshold) => multipliers.map((multiplier) => mergeParams(base, { rsi: { period: base.rsi.period, threshold }, atr: { period: base.atr.period, multiplier } })));
}

function chooseParams(candles: Candle[], startIndex: number, endIndex: number, options: ThreeStageBacktestOptions): { params: BtcUsdtContractParams; result: ThreeStageBacktestResult } {
  const base = options.params ?? DEFAULT_THREE_STAGE_PARAMS;
  return candidateParams(base)
    .map((params) => ({ params, result: backtestBtcUsdtThreeStage(candles, { ...options, params, startIndex, endIndex }) }))
    .sort((a, b) => (b.result.returnPct - b.result.maxDrawdown * 0.5) - (a.result.returnPct - a.result.maxDrawdown * 0.5))[0];
}

/**
 * 滚动向前验证：每个窗口只在训练区间选择 RSI/ATR 参数，随后冻结参数，在下一窗口样本外测试。
 */
export function walkForwardThreeStage(candles: Candle[], options: ThreeStageBacktestOptions & { trainSize?: number; testSize?: number; step?: number } = {}): WalkForwardResult {
  const trainSize = options.trainSize ?? Math.max(360, Math.floor(candles.length * 0.5));
  const testSize = options.testSize ?? Math.max(60, Math.floor(candles.length * 0.2));
  const step = options.step ?? testSize;
  const windows: WalkForwardWindow[] = [];
  const warnings: string[] = [];
  for (let trainStart = 0, index = 0; trainStart + trainSize + 1 < candles.length; trainStart += step, index++) {
    const trainEnd = Math.min(candles.length, trainStart + trainSize);
    const testStart = trainEnd;
    const testEnd = Math.min(candles.length, testStart + testSize);
    if (testEnd - testStart < 2) break;
    const chosen = chooseParams(candles, trainStart, trainEnd, options);
    const outOfSample = backtestBtcUsdtThreeStage(candles, { ...options, params: chosen.params, startIndex: testStart, endIndex: testEnd });
    windows.push({ index, trainStart, trainEnd, testStart, testEnd, selectedParams: chosen.params, train: chosen.result, outOfSample });
    if (testEnd === candles.length) break;
  }
  if (!windows.length) warnings.push("样本不足，无法形成至少一个训练窗口和样本外窗口");
  return { windows, aggregate: aggregateTrades(windows.map((window) => window.outOfSample), options.initialCash ?? 10_000), warnings };
}
