# 独立海外服务器版 Python 执行引擎与 Hard Risk Gateway

## 评审结论

执行服务采用“策略只产出订单意图、网关唯一拦截、域适配器隔离、User Data Stream 主同步、REST 周期性对账”的结构。Spot 与 USDⓈ-M Futures 不共享适配器、凭证、账户账本、仓位模型、订单状态机或风险额度。

## 核心组件

- `MarketDataBuffer`：只发布已闭合 K 线，并记录行情时间和服务器时钟偏移。
- `StrategyRuntime`：消费已确认行情，输出结构化 `OrderIntent`，不能持有 API Secret。
- `HardRiskGateway`：执行域检查、意图检查、行情/账户新鲜度、对账状态、损失/回撤、敞口、重复信号和订单时效拦截。
- `SpotAdapter`：Spot REST 与 Spot User Data Stream，余额中心模型。
- `UsdMFuturesAdapter`：Futures REST 与 Futures User Data Stream，仓位中心模型。
- `DomainLedger`：分别维护余额、订单、成交和仓位，并在乱序、重复、过期、未知订单时要求对账。
- `AuditSink`：只输出结构化审计字段，不输出 key、secret、签名和完整请求参数。

## 状态机

`SYNCING → READY → RUNNING`。数据断流、账本差异、未知订单、listen key 过期或硬损失触发 `PROTECTIVE_ONLY` 或 `RECONCILIATION_REQUIRED`。恢复必须人工确认并完成新的快照对账。

## 风险拦截顺序

`EMERGENCY_CLOSE > REDUCE/CLOSE > HARD_STOP > DRAWDOWN_STOP > STRATEGY_EXIT > NORMAL_ENTRY`。紧急减风险动作可绕过行情陈旧等非致命开仓条件，但不能绕过适配器域检查、幂等、审计和结果确认。

## 部署边界

初始部署只支持 paper、demo 或 testnet。生产服务器使用独立账户、外部 Secret 管理和最小出站权限；真实交易开关必须同时经过部署配置、命令行显式开关和人工审批。
