import { calculateBtcUsdtContractIndicators, type Candle } from "./indicators";

export type BtcUsdtContractStrategy = {
  id: "btc-usdt-contract-1m";
  name: string;
  market: "Binance USDT-M Futures";
  symbol: "BTC/USDT";
  timeframe: "1m";
  stages: {
    trendFilter: string[];
    entryAnd: string[];
    atrExit: { atrPeriod: number; multiplier: number; direction: "long" | "short" | "both" };
  };
};

/** 策略工作台逻辑定义。页面渲染层保持不动，本导出供后续策略数据接入使用。 */
export const BTC_USDT_CONTRACT_1M_STRATEGY: BtcUsdtContractStrategy = {
  id: "btc-usdt-contract-1m",
  name: "BTC/USDT 合约 · 1min 三段式",
  market: "Binance USDT-M Futures",
  symbol: "BTC/USDT",
  timeframe: "1m",
  stages: {
    trendFilter: ["MACD(15,30,15) DIF > DEA", "OBV EMA180 上升", "KDJ(180,360,15) K > D"],
    entryAnd: ["StochRSI(60,180,15,30) K 上穿 D", "RSI180 > 50.55", "WR60 上穿 -80"],
    atrExit: { atrPeriod: 60, multiplier: 2, direction: "both" },
  },
};

export type BtcSignal = {
  trendPass: boolean;
  entryPass: boolean;
  enterLong: boolean;
  exitLong: boolean;
  atrStop: number | null;
  reason: string[];
};

function crossedAbove(current: number | null, previous: number | null, threshold: number) {
  return current !== null && previous !== null && previous <= threshold && current > threshold;
}

function crossedAboveSeries(current: number | null, previous: number | null, currentOther: number | null, previousOther: number | null) {
  return current !== null && previous !== null && currentOther !== null && previousOther !== null && previous <= previousOther && current > currentOther;
}

/** 只使用已收盘 K 线计算三段式信号；调用方传入的 index 应指向已收盘蜡烛。 */
export function calculateBtcUsdtContractSignal(candles: Candle[], index: number, positionEntryPrice?: number) {
  const indicators = calculateBtcUsdtContractIndicators(candles);
  const previous = Math.max(0, index - 1);
  const kdj = indicators.kdj[index]; const previousKdj = indicators.kdj[previous];
  const stoch = indicators.stochRsi[index]; const previousStoch = indicators.stochRsi[previous];
  const macd = indicators.macd[index]; const previousMacd = indicators.macd[previous];
  const wr = indicators.wr[index]?.value ?? null; const previousWr = indicators.wr[previous]?.value ?? null;
  const rsi = indicators.rsi[index]?.value ?? null;
  const obv = indicators.obvEma[index]?.obv ?? null; const previousObv = indicators.obvEma[previous]?.obv ?? null;
  const atr = indicators.atr[index]?.value ?? null;
  const trendPass = macd?.dif !== null && macd?.dea !== null && macd!.dif! > macd!.dea! && obv !== null && previousObv !== null && obv > previousObv && kdj?.k !== null && kdj?.d !== null && kdj!.k! > kdj!.d!;
  const entryPass = crossedAboveSeries(stoch?.k ?? null, previousStoch?.k ?? null, stoch?.d ?? null, previousStoch?.d ?? null) && rsi !== null && rsi > 50.55 && crossedAbove(wr, previousWr, -80);
  const exitLong = atr !== null && positionEntryPrice !== undefined && candles[index].close <= positionEntryPrice - atr * 2;
  const reason = [trendPass ? "大趋势过滤通过" : "大趋势过滤未通过", entryPass ? "入场 AND 条件通过" : "入场条件未齐全", atr !== null ? `ATR${60}=${atr.toFixed(2)}，动态止损倍数=2` : "ATR 未就绪"];
  return { trendPass, entryPass, enterLong: trendPass && entryPass, exitLong, atrStop: atr === null ? null : candles[index].close - atr * 2, reason };
}

export function generateBtcUsdtContractSignals(candles: Candle[]) {
  return candles.map((_candle, index) => calculateBtcUsdtContractSignal(candles, index));
}
