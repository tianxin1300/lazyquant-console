export type Candle = {
  openTime: number;
  closeTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type IndicatorKind = "KDJ" | "ATR" | "OBV" | "MACD" | "BOLL" | "RSI" | "EMA" | "StochRSI" | "WR" | "SUPER";
export type IndicatorPurpose = "过滤" | "入场" | "出场" | "风控";
export type IndicatorGroup = { id: string; kind: IndicatorKind; enabled: boolean; timeframe: string; purpose: IndicatorPurpose; params: Record<string, number> };

function sma(values: number[], period: number, index: number) {
  if (period <= 0 || index + 1 < period) return null;
  const window = values.slice(index - period + 1, index + 1);
  return window.reduce((sum, value) => sum + value, 0) / period;
}

function ema(values: number[], period: number) {
  const result: Array<number | null> = [];
  const multiplier = 2 / (period + 1);
  let previous: number | null = null;
  values.forEach((value, index) => {
    if (index + 1 < period) return result.push(null);
    if (previous === null) previous = values.slice(index - period + 1, index + 1).reduce((sum, item) => sum + item, 0) / period;
    else previous = (value - previous) * multiplier + previous;
    result.push(previous);
  });
  return result;
}

export function calculateKdj(candles: Candle[], period = 9, kPeriod = 3, dPeriod = 3) {
  let previousK = 50; let previousD = 50;
  return candles.map((candle, index) => {
    if (index + 1 < period) return { k: null, d: null, j: null };
    const window = candles.slice(index - period + 1, index + 1);
    const high = Math.max(...window.map((item) => item.high)); const low = Math.min(...window.map((item) => item.low));
    const rsv = high === low ? 50 : ((candle.close - low) / (high - low)) * 100;
    const k = (previousK * (kPeriod - 1) + rsv) / kPeriod; const d = (previousD * (dPeriod - 1) + k) / dPeriod;
    previousK = k; previousD = d; return { k, d, j: 3 * k - 2 * d };
  });
}

export function calculateAtr(candles: Candle[], period = 14) {
  const trueRanges = candles.map((candle, index) => index === 0 ? candle.high - candle.low : Math.max(candle.high - candle.low, Math.abs(candle.high - candles[index - 1].close), Math.abs(candle.low - candles[index - 1].close)));
  return candles.map((_candle, index) => ({ value: sma(trueRanges, period, index) }));
}

export function calculateObv(candles: Candle[], signalPeriod = 20) {
  let obv = 0;
  const values = candles.map((candle, index) => { if (index > 0) obv += candle.close > candles[index - 1].close ? candle.volume : candle.close < candles[index - 1].close ? -candle.volume : 0; return obv; });
  return candles.map((_candle, index) => ({ value: values[index], signal: sma(values, signalPeriod, index) }));
}

export function calculateMacd(candles: Candle[], fast = 12, slow = 26, signalPeriod = 9) {
  const closes = candles.map((candle) => candle.close); const fastEma = ema(closes, fast); const slowEma = ema(closes, slow);
  const dif = closes.map((_close, index) => fastEma[index] !== null && slowEma[index] !== null ? fastEma[index]! - slowEma[index]! : null);
  const signal = ema(dif.map((value) => value ?? 0), signalPeriod);
  return candles.map((_candle, index) => ({ dif: dif[index], dea: dif[index] !== null ? signal[index] : null, histogram: dif[index] !== null && signal[index] !== null ? dif[index]! - signal[index]! : null }));
}

export function calculateBoll(candles: Candle[], period = 20, multiplier = 2) {
  return candles.map((_candle, index) => { const values = candles.map((item) => item.close); const middle = sma(values, period, index); if (middle === null) return { middle: null, upper: null, lower: null }; const variance = values.slice(index - period + 1, index + 1).reduce((sum, value) => sum + (value - middle) ** 2, 0) / period; const deviation = Math.sqrt(variance); return { middle, upper: middle + multiplier * deviation, lower: middle - multiplier * deviation }; });
}

export function calculateRsi(candles: Candle[], period = 14) {
  const result: Array<number | null> = []; let gains = 0; let losses = 0;
  candles.forEach((candle, index) => { if (index === 0) return result.push(null); const change = candle.close - candles[index - 1].close; gains += Math.max(change, 0); losses += Math.max(-change, 0); if (index < period) return result.push(null); if (index > period) { const previousChange = candles[index - period].close - candles[index - period - 1].close; gains = (gains * (period - 1) + Math.max(change, 0)) / period; losses = (losses * (period - 1) + Math.max(-change, 0)) / period; void previousChange; } const rs = losses === 0 ? 100 : gains / losses; result.push(100 - 100 / (1 + rs)); });
  return result.map((value) => ({ value }));
}

export function calculateEma(candles: Candle[], period = 20) { return ema(candles.map((candle) => candle.close), period).map((value) => ({ value })); }

export function calculateStochRsi(candles: Candle[], rsiPeriod = 14, stochPeriod = 14, kPeriod = 3, dPeriod = 3) {
  const rsi = calculateRsi(candles, rsiPeriod).map((point) => point.value); const raw = rsi.map((value, index) => { if (value === null || index + 1 < stochPeriod) return null; const window = rsi.slice(index - stochPeriod + 1, index + 1).filter((item): item is number => item !== null); const min = Math.min(...window); const max = Math.max(...window); return max === min ? 50 : ((value - min) / (max - min)) * 100; });
  return raw.map((_value, index) => ({ k: raw[index] === null ? null : sma(raw.map((item) => item ?? 0), kPeriod, index), d: raw[index] === null ? null : sma(raw.map((item) => item ?? 0), dPeriod, index) }));
}

export function calculateWr(candles: Candle[], period = 14) { return candles.map((candle, index) => { if (index + 1 < period) return { value: null }; const window = candles.slice(index - period + 1, index + 1); const high = Math.max(...window.map((item) => item.high)); const low = Math.min(...window.map((item) => item.low)); return { value: high === low ? -50 : ((high - candle.close) / (high - low)) * -100 }; }); }

export function calculateSuper(candles: Candle[], period = 10, multiplier = 3) {
  const atr = calculateAtr(candles, period).map((point) => point.value); let direction = 1;
  return candles.map((candle, index) => { const value = atr[index]; if (value === null) return { value: null, direction: null }; const basis = (candle.high + candle.low) / 2; const band = basis + (direction === 1 ? -1 : 1) * multiplier * value; if (direction === 1 && candle.close < band) direction = -1; else if (direction === -1 && candle.close > band) direction = 1; return { value: band, direction }; });
}

/** 增量策略预设：不改变原有默认指标参数。 */
export const BTC_USDT_CONTRACT_INDICATOR_PRESET = {
  kdj: { period: 180, kPeriod: 360, dPeriod: 15 },
  stochRsi: { rsiPeriod: 60, stochPeriod: 180, kPeriod: 15, dPeriod: 30 },
  macd: { fast: 15, slow: 30, signalPeriod: 15 },
  wr: { period: 60 },
  obvEmaPeriod: 180,
  rsi: { period: 180, threshold: 50.55 },
} as const;

export function calculateObvEma(candles: Candle[], period = BTC_USDT_CONTRACT_INDICATOR_PRESET.obvEmaPeriod) {
  let obv = 0;
  const values = candles.map((candle, index) => { if (index > 0) obv += candle.close > candles[index - 1].close ? candle.volume : candle.close < candles[index - 1].close ? -candle.volume : 0; return obv; });
  return ema(values, period).map((value, index) => ({ value, obv: values[index] }));
}

export function calculateBtcUsdtContractIndicators(candles: Candle[]) {
  const preset = BTC_USDT_CONTRACT_INDICATOR_PRESET;
  return {
    kdj: calculateKdj(candles, preset.kdj.period, preset.kdj.kPeriod, preset.kdj.dPeriod),
    stochRsi: calculateStochRsi(candles, preset.stochRsi.rsiPeriod, preset.stochRsi.stochPeriod, preset.stochRsi.kPeriod, preset.stochRsi.dPeriod),
    macd: calculateMacd(candles, preset.macd.fast, preset.macd.slow, preset.macd.signalPeriod),
    wr: calculateWr(candles, preset.wr.period),
    obvEma: calculateObvEma(candles, preset.obvEmaPeriod),
    rsi: calculateRsi(candles, preset.rsi.period),
    atr: calculateAtr(candles, 60),
  };
}
