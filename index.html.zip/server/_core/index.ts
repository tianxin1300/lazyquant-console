import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { invokeLLM } from "./llm";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/binance/klines", async (req, res) => {
    const symbol = String(req.query.symbol ?? "BTCUSDT").toUpperCase();
    const interval = String(req.query.interval ?? "1h");
    const allowedIntervals = new Set(["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"]);
    const parsedLimit = Number(req.query.limit ?? 180);
    const limit = Number.isInteger(parsedLimit) ? Math.min(Math.max(parsedLimit, 50), 500) : 180;

    if (!/^[A-Z0-9]{5,20}$/.test(symbol) || !allowedIntervals.has(interval)) {
      return res.status(400).json({ error: "Unsupported Binance Spot symbol or interval" });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const upstream = await fetch(`https://api.binance.com/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${encodeURIComponent(interval)}&limit=${limit}`, {
        signal: controller.signal,
        headers: { accept: "application/json" },
      });
      if (!upstream.ok) {
        return res.status(502).json({ error: "Binance Spot market data request failed", status: upstream.status });
      }
      const payload = await upstream.json() as unknown;
      if (!Array.isArray(payload)) return res.status(502).json({ error: "Invalid Binance Spot market data response" });
      const candles = payload.map((row) => {
        if (!Array.isArray(row) || row.length < 7) throw new Error("Invalid kline row");
        return {
          openTime: Number(row[0]),
          open: Number(row[1]),
          high: Number(row[2]),
          low: Number(row[3]),
          close: Number(row[4]),
          volume: Number(row[5]),
          closeTime: Number(row[6]),
        };
      });
      res.set("Cache-Control", "no-store").json({ source: "binance-spot-public", symbol, interval, candles });
    } catch (error) {
      const message = error instanceof Error && error.name === "AbortError" ? "Binance Spot request timed out" : "Binance Spot market data unavailable";
      res.status(502).json({ error: message });
    } finally {
      clearTimeout(timeout);
    }
  });
  app.post("/api/quantpilot", async (req, res) => {
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.slice(0, 4000) : "";
    const context = typeof req.body?.context === "string" ? req.body.context.slice(0, 8000) : "";
    if (!prompt) return res.status(400).json({ error: "QuantPilot prompt is required" });
    try {
      const result = await invokeLLM({
        messages: [
          { role: "system", content: "你是 QuantPilot，一个只做研究的 Binance Spot 量化策略助手。只能生成结构化研究草案、信号条件、回测建议和风险检查。禁止要求或处理 API Key，禁止下单，禁止修改硬风控。请用简体中文回答，明确说明这是研究草案，需要样本外验证。" },
          { role: "user", content: `用户目标：${prompt}\n当前研究上下文：${context}` },
        ],
        maxTokens: 900,
      });
      const content = result.choices?.[0]?.message?.content;
      const text = typeof content === "string" ? content : "QuantPilot 未返回可读文本";
      res.set("Cache-Control", "no-store").json({ text });
    } catch {
      res.status(503).json({ error: "QuantPilot 当前不可用，请稍后重试" });
    }
  });
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
