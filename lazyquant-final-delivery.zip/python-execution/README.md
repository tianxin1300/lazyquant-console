# LazyQuant 独立执行服务初始架构

该目录是部署在独立海外服务器上的执行服务初始骨架。当前代码只提供数据模型、Hard Risk Gateway 和编排边界，不包含 Binance 网络客户端，也不允许在没有人工审批的情况下连接真实资金。

## 组件边界

```text
Market Data Adapter
        |
        v
Closed Candle Buffer -> Strategy Runtime -> OrderIntent
                                             |
                                             v
                                    Hard Risk Gateway
                                      /           \
                             Spot Adapter     USD-M Futures Adapter
                                      \           /
                                       User Data Stream
                                              |
                                              v
                                     Domain Ledger / Reconciler
                                              |
                                              v
                                    Audit, Metrics, Alerts
```

策略进程只生成带 `strategy_id`、`strategy_version`、`signal_id` 和 `intent_type` 的订单意图。API key、secret、签名和交易所原始请求不能离开适配器边界。Hard Risk Gateway 是所有开仓、加仓、普通退出、保护性退出和紧急平仓的唯一入口，默认 fail-closed。

## 服务器部署基线

第一阶段使用单独的服务账户、只读配置文件和受限出站网络。凭证放入外部 Secret 管理，不写入仓库或日志。服务启动顺序固定为：校时、加载交易规则、账户快照、未完成订单、持仓、账本恢复、User Data Stream，再进入 `READY`。任何对账差异、用户流过期、订单未知或时钟漂移都只能进入 `PROTECTIVE_ONLY` 或 `RECONCILIATION_REQUIRED`，不能自动恢复开仓。

## 上线顺序

1. Paper adapter 和回放数据验证。
2. Spot 与 USDⓈ-M Futures Demo/Testnet 分域联调。
3. 断网、429、503 Unknown、重复信号、部分成交和 listen key 过期演练。
4. 小额 canary 需要独立人工审批；Live 不是默认配置。

`risk_gateway.py` 是核心拦截逻辑；`models.py` 保持跨服务的最小订单意图和风险上下文；`engine.py` 只负责编排，不绕过网关。
